// يتحقق من حساب مدير التطبيق في قاعدة البيانات، وينشئه إذا لم يكن موجوداً
// التشغيل (في مجلد oracle-backend):  node check_admin.js
const fs = require('fs');
const path = require('path');
const oracledb = require('oracledb');

// يأخذ نفس بيانات الاتصال المكتوبة في server.js
const src = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
const match = src.match(/const dbConfig = (\{[\s\S]*?\});/);
if (!match) {
  console.error('❌ لم أجد dbConfig داخل server.js');
  process.exit(1);
}
const dbConfig = eval('(' + match[1] + ')');

(async () => {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

    let r = await conn.execute(`SELECT user_id, email FROM rd_users WHERE user_type = 'ADMIN'`);
    if (r.rows.length === 0) {
      await conn.execute(
        `INSERT INTO rd_users (full_name, email, password, user_type)
         VALUES ('إدارة راحة ضيف', 'admin@rahatdayf.sa', LOWER(RAWTOHEX(STANDARD_HASH('1234','SHA256'))), 'ADMIN')`
      );
      await conn.commit();
      console.log('✅ تم إنشاء حساب مدير التطبيق');
      r = await conn.execute(`SELECT user_id, email FROM rd_users WHERE user_type = 'ADMIN'`);
    }
    console.log('حسابات مدير التطبيق الموجودة (كلمة المرور 1234):');
    for (const row of r.rows) console.log('  •', row.EMAIL);
  } catch (e) {
    console.error('❌ خطأ:', e.message);
  } finally {
    if (conn) await conn.close();
  }
})();