// فحص تسجيل الدخول خطوة بخطوة
// التشغيل (في مجلد oracle-backend):  node diag_login.js admin@rahatdayf.sa 1234
const fs = require('fs');
const path = require('path');
const oracledb = require('oracledb');

const email = process.argv[2] || 'admin@rahatdayf.sa';
const password = process.argv[3] || '1234';

const src = fs.readFileSync(path.join(__dirname, 'server.js'), 'utf8');
const dbConfig = eval('(' + src.match(/const dbConfig = (\{[\s\S]*?\});/)[1] + ')');
const usesNewLogin = src.includes('LOWER(TRIM(email))');

(async () => {
  let conn;
  try {
    conn = await oracledb.getConnection(dbConfig);
    oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
    console.log('1) server.js الجديد مثبت؟', usesNewLogin ? '✅ نعم' : '❌ لا — استبدلي server.js بالنسخة الجديدة');
    console.log('   قاعدة البيانات:', dbConfig.user, '@', dbConfig.connectString);

    const u = (await conn.execute(
      `SELECT user_id, user_type, '[' || email || ']' AS em, LENGTH(email) AS el, password AS pw, LENGTH(password) AS pl,
              LOWER(RAWTOHEX(STANDARD_HASH(:p, 'SHA256'))) AS calc
         FROM rd_users WHERE LOWER(TRIM(email)) = LOWER(TRIM(:e))`, { e: email, p: password })).rows;

    if (!u.length) {
      console.log('2) ❌ لا يوجد حساب بهذا البريد:', email);
      const all = (await conn.execute(`SELECT user_type, email FROM rd_users ORDER BY user_type`)).rows;
      console.log('   الحسابات الموجودة:');
      all.forEach((x) => console.log('    ', x.USER_TYPE, x.EMAIL));
      return;
    }
    const x = u[0];
    console.log('2) ✅ الحساب موجود:', x.EM, '| الصفة:', x.USER_TYPE);
    console.log('3) كلمة المرور المحفوظة:', String(x.PW).slice(0, 16) + '...', '(الطول', x.PL + ')');
    console.log('   المتوقعة لـ', password + ':', String(x.CALC).slice(0, 16) + '...');
    console.log('   تطابق؟', x.PW === x.CALC || x.PW === password ? '✅ نعم' : '❌ لا — شغّلي node reset_passwords.js');
  } catch (e) {
    console.error('❌ خطأ:', e.message);
  } finally {
    if (conn) await conn.close();
  }
})();