// =============================================================================
// سيرفر راحة ضيف — Express + Oracle (مطابق لدوال api_service.dart)
// التثبيت:  npm i express cors oracledb
// التشغيل:  DB_USER=... DB_PASSWORD=... DB_CONNECT=localhost:1521/XEPDB1 node server.js
// =============================================================================
const express = require('express');
const cors = require('cors');
const oracledb = require('oracledb');

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = false;

const dbConfig = {
  user: "AHDABN8_SCHEMA_F8U32",
  password: "S17ZG$6U18UMUS6V7TV6lO18K5S1JM",
  connectString: "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcps)(HOST=db.freesql.com)(PORT=2484))(CONNECT_DATA=(SERVICE_NAME=26ai_un3c1)))"
};
const PORT = process.env.PORT || 3000;

const app = express();
app.use(cors());
app.use(express.json());

// ---------- أدوات ----------
const lower = (row) => Object.fromEntries(Object.entries(row).map(([k, v]) => [k.toLowerCase(), v]));
const rows = (r) => (r.rows || []).map(lower);
const round2 = (n) => Math.round(Number(n) * 100) / 100;
const fail = (status, message) => Object.assign(new Error(message), { status });
const OUT_NUM = { dir: oracledb.BIND_OUT, type: oracledb.NUMBER };
const randCode = (prefix) => `${prefix}-${Math.floor(10000 + Math.random() * 90000)}`;

async function withConn(fn) {
  const conn = await oracledb.getConnection();
  try {
    return await fn(conn);
  } catch (e) {
    try { await conn.rollback(); } catch (_) {}
    throw e;
  } finally {
    await conn.close();
  }
}

const route = (fn) => async (req, res) => {
  try {
    await fn(req, res);
  } catch (e) {
    console.error(e);
    const appErr = e.errorNum >= 20000 && e.errorNum < 21000;
    const status = e.status || (e.errorNum === 1 ? 409 : appErr ? 400 : 500);
    const message = e.status
      ? e.message
      : e.errorNum === 1
        ? 'القيمة مسجلة مسبقاً (اسم المحطة أو البريد مكرر)'
        : appErr
          ? e.message.replace(/^ORA-\d+:\s*/, '').split('\n')[0]
          : 'خطأ في السيرفر';
    res.status(status).json({ error: message });
  }
};

const splitServices = (r) => ({ ...r, services: r.services ? String(r.services).split('|') : [] });

const STATION_SQL = `
SELECT s.rest_stop_id, s.name, s.app_title, s.city, s.highway_name, s.address_label, s.description,
       s.latitude, s.longitude, s.bus_capacity, s.waiting_capacity, s.open_time, s.contact_phone,
       s.congestion_level, s.occupancy_percentage, s.vacant_spots, s.distance_km, s.image_asset,
       s.status, s.plan_code, s.billing_cycle, s.commercial_reg, s.owner_id, s.created_at,
       p.plan_name, p.plan_rank,
       NVL((SELECT ROUND(AVG(r.rating),1) FROM rd_reviews r WHERE r.rest_stop_id = s.rest_stop_id), s.avg_rating) AS rating,
       (SELECT COUNT(*) FROM rd_reviews r WHERE r.rest_stop_id = s.rest_stop_id) AS reviews_count,
       (SELECT LISTAGG(sv.service_name, '|') WITHIN GROUP (ORDER BY sv.service_id)
          FROM rd_rest_stop_services ss JOIN rd_services sv ON sv.service_id = ss.service_id
         WHERE ss.rest_stop_id = s.rest_stop_id) AS services,
       (SELECT COUNT(*) FROM rd_bookings b WHERE b.rest_stop_id = s.rest_stop_id
           AND b.status = 'confirmed' AND b.booking_date >= TRUNC(SYSDATE)) AS active_bookings
  FROM rd_rest_stops s LEFT JOIN rd_plans p ON p.plan_code = s.plan_code
 WHERE s.is_visible = 1`;

// ---------- الدخول ----------
app.post('/api/login', route(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) throw fail(400, 'أدخل البريد وكلمة المرور');
  console.log('🔑 محاولة دخول:', JSON.stringify(email), '| طول كلمة المرور:', String(password).length);
  const user = await withConn(async (conn) => {
    // البريد بدون حساسية لحالة الأحرف أو المسافات، وكلمة المرور مشفرة SHA256 أو نصية
    const r = rows(await conn.execute(
      `SELECT MIN(user_id) AS id FROM rd_users
        WHERE LOWER(TRIM(email)) = LOWER(TRIM(:e))
          AND (password = LOWER(RAWTOHEX(STANDARD_HASH(:p, 'SHA256'))) OR password = :p2)`,
      { e: String(email), p: String(password), p2: String(password) }))[0];
    if (!r || r.id == null) throw fail(401, 'البريد الإلكتروني أو كلمة المرور غير صحيحة');
    return loadUser(conn, r.id);
  });
  res.json({ user });
}));

async function loadUser(conn, id) {
  const u = rows(await conn.execute(
    `SELECT u.user_id, u.full_name, u.email, u.phone, u.user_type, u.rating, u.loyalty_points, u.wallet_balance,
            u.total_earnings, u.subscription_status, u.subscription_expires_at, u.created_at,
            cp.manager_name, cp.license_no
       FROM rd_users u LEFT JOIN rd_campaign_profiles cp ON cp.user_id = u.user_id
      WHERE u.user_id = :id`, { id }))[0];
  if (!u) throw fail(404, 'المستخدم غير موجود');
  return u;
}

// ---------- المحطات ----------
app.get('/api/stations', route(async (req, res) => {
  const binds = {};
  let sql = STATION_SQL;
  if (req.query.city) { sql += ' AND s.city = :city'; binds.city = req.query.city; }
  sql += ' ORDER BY CASE s.status WHEN \'PENDING\' THEN 1 ELSE 0 END, p.plan_rank, s.occupancy_percentage';
  const data = await withConn(async (conn) => rows(await conn.execute(sql, binds)).map(splitServices));
  res.json({ stations: data });
}));

app.get('/api/stations/:id', route(async (req, res) => {
  const id = Number(req.params.id);
  const data = await withConn(async (conn) => {
    const station = rows(await conn.execute(STATION_SQL + ' AND s.rest_stop_id = :id', { id })).map(splitServices)[0];
    if (!station) throw fail(404, 'المحطة غير موجودة');
    const booking_types = rows(await conn.execute(
      `SELECT booking_type_id, name, price FROM rd_v_station_services WHERE rest_stop_id = :id ORDER BY price`, { id }));
    const reviews = rows(await conn.execute(
      `SELECT reviewer_name, rating, comment_text, created_at FROM rd_reviews
        WHERE rest_stop_id = :id ORDER BY created_at DESC FETCH FIRST 10 ROWS ONLY`, { id }));
    return { station, services: station.services, booking_types, reviews };
  });
  res.json(data);
}));

app.post('/api/stations', route(async (req, res) => {
  const b = req.body || {};
  if (!b.name || String(b.name).trim().length < 3) throw fail(400, 'اسم المحطة مطلوب');
  if (!b.city) throw fail(400, 'المدينة مطلوبة');
  if (b.commercial_reg && !/^\d{10}$/.test(String(b.commercial_reg))) throw fail(400, 'السجل التجاري يجب أن يكون 10 أرقام');
  if (b.contact_phone && !/^05\d{8}$/.test(String(b.contact_phone))) throw fail(400, 'رقم الجوال غير صحيح');
  const plan = ['basic', 'plus', 'gold'].includes(b.plan_code) ? b.plan_code : 'basic';
  const cycle = b.billing_cycle === 'MONTHLY' ? 'MONTHLY' : 'YEARLY';
  const busCap = Math.max(1, parseInt(b.bus_capacity || 1, 10));

  const id = await withConn(async (conn) => {
    const r = await conn.execute(
      `INSERT INTO rd_rest_stops (owner_id, name, app_title, city, highway_name, address_label, description,
            latitude, longitude, bus_capacity, waiting_capacity, open_time, contact_phone, commercial_reg,
            occupancy_percentage, congestion_level, vacant_spots, vacant_percentage, status, is_visible, plan_code, billing_cycle)
       VALUES (:owner, :name, :name2, :city, :hw, :addr, :descr, :lat, :lng, :bus, :wait, :open, :phone, :cr,
            0, 'LOW', :bus2, 100, 'PENDING', 1, :plan, :cycle)
       RETURNING rest_stop_id INTO :id`,
      {
        owner: b.owner_id || null, name: String(b.name).trim(), name2: String(b.name).trim(), city: b.city,
        hw: b.highway_name || null, addr: b.address_label || null, descr: b.description || null,
        lat: b.latitude ?? null, lng: b.longitude ?? null, bus: busCap, bus2: busCap,
        wait: parseInt(b.waiting_capacity || 0, 10), open: String(b.open_time || '24/7').slice(0, 10),
        phone: b.contact_phone || null, cr: b.commercial_reg || null, plan, cycle, id: OUT_NUM,
      });
    const newId = r.outBinds.id[0];
    for (const svc of Array.isArray(b.services) ? b.services : []) {
      await conn.execute(
        `INSERT INTO rd_rest_stop_services (rest_stop_id, service_id)
         SELECT :sid, service_id FROM rd_services WHERE service_name = :n`, { sid: newId, n: svc });
    }
    if (b.owner_id) {
      await conn.execute(
        `UPDATE rd_users SET stations_count = (SELECT COUNT(*) FROM rd_rest_stops WHERE owner_id = :o) WHERE user_id = :o2`,
        { o: b.owner_id, o2: b.owner_id });
    }
    await conn.commit();
    return newId;
  });
  res.status(201).json({ rest_stop_id: id, status: 'PENDING' });
}));

app.patch('/api/stations/:id/approve', route(async (req, res) => {
  await withConn(async (conn) => {
    const r = await conn.execute(`UPDATE rd_rest_stops SET status = 'APPROVED', subscribed_at = SYSTIMESTAMP WHERE rest_stop_id = :id`,
      { id: Number(req.params.id) });
    if (!r.rowsAffected) throw fail(404, 'المحطة غير موجودة');
    await conn.commit();
  });
  res.json({ ok: true });
}));

app.get('/api/services', route(async (req, res) => {
  const data = await withConn(async (conn) => rows(await conn.execute(
    `SELECT service_id, service_name, description FROM rd_services ORDER BY service_id`)));
  res.json({ services: data });
}));

app.get('/api/plans', route(async (req, res) => {
  const data = await withConn(async (conn) => rows(await conn.execute(
    `SELECT plan_code, plan_name, plan_rank, monthly_price, yearly_price, features FROM rd_plans ORDER BY plan_rank DESC`)));
  res.json({ plans: data });
}));

// ---------- الحجوزات ----------
app.post('/api/bookings', route(async (req, res) => {
  const b = req.body || {};
  const busCount = Math.max(1, parseInt(b.bus_count || 1, 10));
  const people = Math.max(1, parseInt(b.people_count || 1, 10));
  if (!b.rest_stop_id || !b.booking_type_id) throw fail(400, 'اختر المحطة ونوع الحجز');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.booking_date || '')) throw fail(400, 'تاريخ الحجز غير صحيح');
  if (!/^\d{2}:\d{2}$/.test(b.arrival_time || '')) throw fail(400, 'وقت الوصول غير صحيح');

  const result = await withConn(async (conn) => {
    const st = rows(await conn.execute(
      `SELECT owner_id, vacant_spots, bus_capacity, status, name FROM rd_rest_stops
        WHERE rest_stop_id = :id AND is_visible = 1 FOR UPDATE`, { id: b.rest_stop_id }))[0];
    if (!st) throw fail(404, 'المحطة غير موجودة');
    if (st.status === 'PENDING') throw fail(400, 'المحطة قيد مراجعة الإدارة ولا تستقبل حجوزات بعد');

    const bt = rows(await conn.execute(
      `SELECT price, name FROM rd_v_station_services WHERE rest_stop_id = :s AND booking_type_id = :t`,
      { s: b.rest_stop_id, t: b.booking_type_id }))[0];
    if (!bt) throw fail(400, 'هذه الخدمة غير متاحة في هذه المحطة');

    const isParking = String(bt.name).includes('موقف');
    if (isParking && st.vacant_spots != null && busCount > st.vacant_spots) {
      throw fail(409, `لا يتوفر حالياً إلا ${st.vacant_spots} موقف شاغر`);
    }

    const pct = rows(await conn.execute(`SELECT fn_setting('BOOKING_COMMISSION_PCT') AS pct FROM dual`))[0].pct || 15;
    const total = round2(bt.price * busCount);
    const fee = round2(total * pct / 100);
    const net = round2(total - fee);

    let user = null;
    if (b.user_id) {
      user = rows(await conn.execute(
        `SELECT user_id, user_type, wallet_balance FROM rd_users WHERE user_id = :u FOR UPDATE`, { u: b.user_id }))[0];
      if (!user) throw fail(404, 'المستخدم غير موجود');
      if (user.user_type === 'CAMPAIGN' && Number(user.wallet_balance) < total) {
        throw fail(400, `رصيد محفظة الحملة (${user.wallet_balance} ر.س) لا يكفي لإجمالي ${total} ر.س`);
      }
    }

    const code = randCode('RD');
    const qr = `${code}-${Date.now().toString(36).toUpperCase()}`;
    const bay = isParking
      ? `P-${String(Math.max(1, (st.bus_capacity || 0) - (st.vacant_spots || 0) + 1)).padStart(2, '0')}`
      : null;

    const ins = await conn.execute(
      `INSERT INTO rd_bookings (driver_id, rest_stop_id, booking_date, arrival_time, expected_arrival, bus_count, people_count,
            status, booking_code, booking_type_id, qr_code_token, total_amount, platform_fee, net_owner_amount, notes, bus_stop_bay)
       VALUES (:u, :s, TO_DATE(:d, 'YYYY-MM-DD'), :t, TO_TIMESTAMP(:d2 || ' ' || :t2, 'YYYY-MM-DD HH24:MI'), :bc, :pc,
            'confirmed', :code, :bt, :qr, :total, :fee, :net, :notes, :bay)
       RETURNING booking_id INTO :id`,
      {
        u: b.user_id || null, s: b.rest_stop_id, d: b.booking_date, t: b.arrival_time, d2: b.booking_date, t2: b.arrival_time,
        bc: busCount, pc: people, code, bt: b.booking_type_id, qr, total, fee, net,
        notes: b.notes ? String(b.notes).slice(0, 1000) : null, bay, id: OUT_NUM,
      });
    const bookingId = ins.outBinds.id[0];

    await conn.execute(
      `INSERT INTO rd_transactions (booking_id, campaign_owner_id, rest_stop_owner_id, total_amount,
            platform_percentage, platform_profit, owner_payout, transaction_type)
       VALUES (:b, :u, :o, :total, :pct, :fee, :net, 'BOOKING')`,
      { b: bookingId, u: b.user_id || null, o: st.owner_id, total, pct, fee, net });

    if (user && user.user_type === 'CAMPAIGN' && total > 0) {
      await conn.execute(`UPDATE rd_users SET wallet_balance = wallet_balance - :t WHERE user_id = :u`, { t: total, u: user.user_id });
      await conn.execute(`INSERT INTO rd_wallet_ledger (user_id, amount, reason, ref_code) VALUES (:u, :a, :r, :c)`,
        { u: user.user_id, a: -total, r: `حجز ${bt.name} × ${busCount} — ${st.name}`, c: code });
    }
    if (st.owner_id && net > 0) {
      await conn.execute(`UPDATE rd_users SET wallet_balance = wallet_balance + :n, total_earnings = total_earnings + :n2 WHERE user_id = :o`,
        { n: net, n2: net, o: st.owner_id });
      await conn.execute(`INSERT INTO rd_wallet_ledger (user_id, amount, reason, ref_code) VALUES (:u, :a, :r, :c)`,
        { u: st.owner_id, a: net, r: `إيراد حجز ${bt.name} (85%)`, c: code });
    }
    if (isParking && st.vacant_spots != null) {
      await conn.execute(
        `UPDATE rd_rest_stops
            SET vacant_spots = GREATEST(vacant_spots - :bc, 0),
                occupancy_percentage = CASE WHEN bus_capacity > 0
                  THEN LEAST(100, ROUND((bus_capacity - GREATEST(vacant_spots - :bc2, 0)) * 100 / bus_capacity, 2))
                  ELSE occupancy_percentage END
          WHERE rest_stop_id = :s`, { bc: busCount, bc2: busCount, s: b.rest_stop_id });
    }
    let points = 0;
    if (user) {
      points = 50;
      await conn.execute(`UPDATE rd_users SET loyalty_points = loyalty_points + 50, trips_count = trips_count + 1 WHERE user_id = :u`,
        { u: user.user_id });
      await conn.execute(`INSERT INTO rd_loyalty_rewards (user_id, action_type, points, reward_description) VALUES (:u, 'BOOKING', 50, :d)`,
        { u: user.user_id, d: `تأكيد حجز ${code}` });
    }
    await conn.commit();
    return { booking_id: bookingId, booking_code: code, qr_code_token: qr, bus_stop_bay: bay,
      total_amount: total, platform_fee: fee, net_owner_amount: net, loyalty_points_earned: points };
  });
  res.status(201).json(result);
}));

app.get('/api/bookings', route(async (req, res) => {
  const where = [];
  const binds = {};
  if (req.query.user_id) { where.push('b.driver_id = :u'); binds.u = Number(req.query.user_id); }
  if (req.query.rest_stop_id) { where.push('b.rest_stop_id = :s'); binds.s = Number(req.query.rest_stop_id); }
  const data = await withConn(async (conn) => rows(await conn.execute(
    `SELECT b.booking_id, b.booking_code, b.booking_date, b.arrival_time, b.expected_arrival, b.bus_count, b.people_count,
            b.status, b.notes, b.bus_stop_bay, b.qr_code_token, b.total_amount, b.platform_fee, b.net_owner_amount,
            b.created_at, b.rest_stop_id, s.app_title, s.name AS station_name, s.city, s.address_label, s.highway_name,
            bt.type_name, u.full_name AS customer_name
       FROM rd_bookings b
       JOIN rd_rest_stops s ON s.rest_stop_id = b.rest_stop_id
       LEFT JOIN rd_booking_types bt ON bt.booking_type_id = b.booking_type_id
       LEFT JOIN rd_users u ON u.user_id = b.driver_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY b.booking_date DESC, b.created_at DESC`, binds)));
  res.json({ bookings: data });
}));

app.patch('/api/bookings/:id/cancel', route(async (req, res) => {
  await withConn(async (conn) => {
    const bk = rows(await conn.execute(
      `SELECT b.*, s.owner_id, bt.type_name, u.user_type
         FROM rd_bookings b JOIN rd_rest_stops s ON s.rest_stop_id = b.rest_stop_id
         LEFT JOIN rd_booking_types bt ON bt.booking_type_id = b.booking_type_id
         LEFT JOIN rd_users u ON u.user_id = b.driver_id
        WHERE b.booking_id = :id FOR UPDATE OF b.status`, { id: Number(req.params.id) }))[0];
    if (!bk) throw fail(404, 'الحجز غير موجود');
    if (req.body?.user_id && bk.driver_id !== req.body.user_id) throw fail(403, 'لا تملك صلاحية إلغاء هذا الحجز');
    if (!['pending', 'confirmed'].includes(bk.status)) throw fail(400, 'لا يمكن إلغاء حجز مكتمل أو ملغى');

    await conn.execute(`UPDATE rd_bookings SET status = 'cancelled' WHERE booking_id = :id`, { id: bk.booking_id });
    if (String(bk.type_name || '').includes('موقف')) {
      await conn.execute(
        `UPDATE rd_rest_stops SET vacant_spots = LEAST(NVL(NULLIF(bus_capacity,0), vacant_spots + :bc), vacant_spots + :bc2),
                occupancy_percentage = CASE WHEN bus_capacity > 0
                  THEN GREATEST(0, ROUND((bus_capacity - LEAST(bus_capacity, vacant_spots + :bc3)) * 100 / bus_capacity, 2))
                  ELSE occupancy_percentage END
          WHERE rest_stop_id = :s AND vacant_spots IS NOT NULL`,
        { bc: bk.bus_count, bc2: bk.bus_count, bc3: bk.bus_count, s: bk.rest_stop_id });
    }
    if (Number(bk.total_amount) > 0) {
      if (bk.user_type === 'CAMPAIGN') {
        await conn.execute(`UPDATE rd_users SET wallet_balance = wallet_balance + :t WHERE user_id = :u`, { t: bk.total_amount, u: bk.driver_id });
        await conn.execute(`INSERT INTO rd_wallet_ledger (user_id, amount, reason, ref_code) VALUES (:u, :a, 'استرداد حجز ملغى', :c)`,
          { u: bk.driver_id, a: bk.total_amount, c: bk.booking_code });
      }
      if (bk.owner_id) {
        await conn.execute(`UPDATE rd_users SET wallet_balance = wallet_balance - :n, total_earnings = total_earnings - :n2 WHERE user_id = :o`,
          { n: bk.net_owner_amount, n2: bk.net_owner_amount, o: bk.owner_id });
        await conn.execute(`INSERT INTO rd_wallet_ledger (user_id, amount, reason, ref_code) VALUES (:u, :a, 'عكس إيراد حجز ملغى', :c)`,
          { u: bk.owner_id, a: -bk.net_owner_amount, c: bk.booking_code });
      }
    }
    await conn.commit();
  });
  res.json({ ok: true });
}));

// ---------- المستخدم ----------
app.get('/api/users/:id', route(async (req, res) => {
  const id = Number(req.params.id);
  const data = await withConn(async (conn) => {
    const user = await loadUser(conn, id);
    const stats = rows(await conn.execute(
      `SELECT COUNT(CASE WHEN status = 'completed' THEN 1 END) AS completed_trips,
              COUNT(CASE WHEN status = 'confirmed' AND booking_date >= TRUNC(SYSDATE) THEN 1 END) AS upcoming,
              COUNT(DISTINCT CASE WHEN status <> 'cancelled' THEN rest_stop_id END) AS stations_booked
         FROM rd_bookings WHERE driver_id = :id`, { id }))[0];
    const stations = rows(await conn.execute(
      `SELECT s.rest_stop_id, s.name, s.app_title, s.city, s.status, s.commercial_reg, s.plan_code, s.billing_cycle,
              p.plan_name, p.features,
              CASE s.billing_cycle WHEN 'YEARLY' THEN ADD_MONTHS(s.subscribed_at, 12) ELSE ADD_MONTHS(s.subscribed_at, 1) END AS renews_at
         FROM rd_rest_stops s LEFT JOIN rd_plans p ON p.plan_code = s.plan_code
        WHERE s.owner_id = :id ORDER BY s.created_at`, { id }));
    return { user, stats, stations };
  });
  res.json(data);
}));

// ---------- لوحة صاحب المحطة ----------
app.get('/api/owners/:id/dashboard', route(async (req, res) => {
  const id = Number(req.params.id);
  const data = await withConn(async (conn) => {
    const user = await loadUser(conn, id);
    const stations = rows(await conn.execute(
      `SELECT s.rest_stop_id, s.name, s.app_title, s.status, s.bus_capacity, s.vacant_spots, s.occupancy_percentage,
              s.plan_code, s.billing_cycle, p.plan_name,
              CASE s.billing_cycle WHEN 'YEARLY' THEN ADD_MONTHS(s.subscribed_at, 12) ELSE ADD_MONTHS(s.subscribed_at, 1) END AS renews_at
         FROM rd_rest_stops s LEFT JOIN rd_plans p ON p.plan_code = s.plan_code
        WHERE s.owner_id = :id ORDER BY s.created_at`, { id }));
    const totals = rows(await conn.execute(
      `SELECT NVL(SUM(total_amount),0) AS sales, NVL(SUM(owner_payout),0) AS payout, NVL(SUM(platform_profit),0) AS fee,
              COUNT(*) AS tx_count, COUNT(CASE WHEN TRUNC(created_at) = TRUNC(SYSDATE) THEN 1 END) AS today_count
         FROM rd_transactions WHERE rest_stop_owner_id = :id`, { id }))[0];
    const orders = rows(await conn.execute(
      `SELECT o.order_id, o.order_code, o.meal_name, o.quantity, o.total, o.status, o.created_at,
              s.app_title, s.name AS station_name, u.full_name AS campaign_name
         FROM rd_meal_orders o JOIN rd_rest_stops s ON s.rest_stop_id = o.rest_stop_id
         JOIN rd_users u ON u.user_id = o.campaign_id
        WHERE s.owner_id = :id
        ORDER BY CASE o.status WHEN 'PAID' THEN 0 WHEN 'PREPARING' THEN 1 ELSE 2 END, o.created_at DESC
        FETCH FIRST 10 ROWS ONLY`, { id }));
    const ledger = rows(await conn.execute(
      `SELECT amount, reason, ref_code, created_at FROM rd_wallet_ledger WHERE user_id = :id
        ORDER BY created_at DESC FETCH FIRST 10 ROWS ONLY`, { id }));
    const upcoming = rows(await conn.execute(
      `SELECT COUNT(*) AS count, NVL(SUM(b.bus_count),0) AS buses
         FROM rd_bookings b JOIN rd_rest_stops s ON s.rest_stop_id = b.rest_stop_id
        WHERE s.owner_id = :id AND b.status = 'confirmed' AND b.booking_date >= TRUNC(SYSDATE)`, { id }))[0];
    const pend = rows(await conn.execute(
      `SELECT NVL(SUM(p.amount),0) AS pending FROM rd_payouts p JOIN rd_rest_stops s ON s.rest_stop_id = p.rest_stop_id
        WHERE s.owner_id = :id AND p.status = 'PENDING'`, { id }))[0];
    return { user, stations, totals, orders, ledger, upcoming, pending_payouts: pend.pending };
  });
  res.json(data);
}));

app.get('/api/meals', route(async (req, res) => {
  const data = await withConn(async (conn) => rows(await conn.execute(
    `SELECT m.meal_id, m.meal_name, m.price, m.stock_qty, v.allergens
       FROM rd_meals m JOIN rd_v_meals v ON v.meal_id = m.meal_id
      WHERE m.is_active = 1 ORDER BY m.meal_id`)));
  res.json({ meals: data });
}));

app.patch('/api/meal-orders/:id/status', route(async (req, res) => {
  const next = req.body?.status;
  const allowed = { PAID: 'PREPARING', PREPARING: 'DELIVERED' };
  await withConn(async (conn) => {
    const o = rows(await conn.execute(
      `SELECT o.order_id, o.order_code, o.status, o.total, s.owner_id
         FROM rd_meal_orders o JOIN rd_rest_stops s ON s.rest_stop_id = o.rest_stop_id
        WHERE o.order_id = :id FOR UPDATE OF o.status`, { id: Number(req.params.id) }))[0];
    if (!o) throw fail(404, 'الطلب غير موجود');
    if (allowed[o.status] !== next) throw fail(400, `لا يمكن نقل الطلب من ${o.status} إلى ${next}`);
    await conn.execute(`UPDATE rd_meal_orders SET status = :st WHERE order_id = :id`, { st: next, id: o.order_id });

    if (next === 'DELIVERED' && o.owner_id) {
      const credited = rows(await conn.execute(
        `SELECT COUNT(*) AS c FROM rd_wallet_ledger WHERE user_id = :u AND ref_code = :c AND amount > 0`,
        { u: o.owner_id, c: o.order_code }))[0].c;
      if (!credited) {
        const tx = rows(await conn.execute(`SELECT owner_payout FROM rd_transactions WHERE order_id = :id`, { id: o.order_id }))[0];
        const payout = tx ? Number(tx.owner_payout) : round2(o.total * 0.85);
        await conn.execute(`UPDATE rd_users SET wallet_balance = wallet_balance + :p, total_earnings = total_earnings + :p2 WHERE user_id = :u`,
          { p: payout, p2: payout, u: o.owner_id });
        await conn.execute(`INSERT INTO rd_wallet_ledger (user_id, amount, reason, ref_code) VALUES (:u, :a, 'إيداع مبيعات وجبات', :c)`,
          { u: o.owner_id, a: payout, c: o.order_code });
      }
    }
    await conn.commit();
  });
  res.json({ ok: true });
}));

app.post('/api/payouts', route(async (req, res) => {
  const { rest_stop_id, user_id } = req.body || {};
  const amount = round2(req.body?.amount);
  if (!(amount >= 100)) throw fail(400, 'الحد الأدنى للتحويل 100 ر.س');
  const code = await withConn(async (conn) => {
    const st = rows(await conn.execute(`SELECT owner_id FROM rd_rest_stops WHERE rest_stop_id = :s`, { s: rest_stop_id }))[0];
    if (!st || st.owner_id !== user_id) throw fail(403, 'لا تملك صلاحية على هذه المحطة');
    const w = rows(await conn.execute(`SELECT wallet_balance FROM rd_users WHERE user_id = :u FOR UPDATE`, { u: user_id }))[0];
    const pend = rows(await conn.execute(
      `SELECT NVL(SUM(p.amount),0) AS pending FROM rd_payouts p JOIN rd_rest_stops s ON s.rest_stop_id = p.rest_stop_id
        WHERE s.owner_id = :u AND p.status = 'PENDING'`, { u: user_id }))[0].pending;
    const available = Number(w.wallet_balance) - Number(pend);
    if (amount > available) throw fail(400, `الرصيد المتاح ${round2(available)} ر.س فقط`);
    const c = randCode('P');
    await conn.execute(`INSERT INTO rd_payouts (payout_code, rest_stop_id, amount, status) VALUES (:c, :s, :a, 'PENDING')`,
      { c, s: rest_stop_id, a: amount });
    await conn.commit();
    return c;
  });
  res.status(201).json({ payout_code: code });
}));

// ---------- الإدارة ----------
app.get('/api/admin/overview', route(async (req, res) => {
  const data = await withConn(async (conn) => {
    const ov = rows(await conn.execute(`SELECT * FROM rd_v_admin_overview`))[0];
    const cnt = rows(await conn.execute(`SELECT COUNT(*) AS stations_count FROM rd_rest_stops`))[0];
    const pending_stations = rows(await conn.execute(
      `SELECT rest_stop_id, name, city, commercial_reg, created_at FROM rd_rest_stops WHERE status = 'PENDING' ORDER BY created_at DESC`));
    return { ...ov, ...cnt, pending_stations };
  });
  res.json(data);
}));

// ---------- المكافآت ----------
app.get('/api/rewards', route(async (req, res) => {
  const data = await withConn(async (conn) => rows(await conn.execute(
    `SELECT reward_id, title, cost_points FROM rd_rewards ORDER BY cost_points`)));
  res.json({ rewards: data });
}));

app.post('/api/rewards/redeem', route(async (req, res) => {
  const { user_id, reward_id } = req.body || {};
  if (!user_id || !reward_id) throw fail(400, 'بيانات ناقصة');
  const code = await withConn(async (conn) => {
    const r = await conn.execute(`BEGIN sp_redeem_reward(:u, :r, :code); END;`,
      { u: user_id, r: reward_id, code: { dir: oracledb.BIND_OUT, type: oracledb.STRING, maxSize: 20 } });
    return r.outBinds.code;
  });
  res.json({ voucher_code: code });
}));

// ---------- الحسابات التجريبية: تُنشأ أو يُعاد ضبط كلمة مرورها إلى 1234 عند كل تشغيل ----------
const DEMO_ACCOUNTS = [
  ['ADMIN', 'مدير التطبيق', 'إدارة راحة ضيف', 'admin@rahatdayf.sa'],
  ['CAMPAIGN', 'صاحب الحملة', 'حملة أنوار المشاعر لخدمات المعتمرين وحجاج بيت الله', 'campaign@anwar.sa'],
  ['OWNER', 'صاحب المحطة', 'تركي العتيبي', 'owner@nakheel.sa'],
  ['USER', 'ضيف الرحمن', 'ضيف راحة', 'guest@mail.com'],
];

async function ensureDemoAccounts() {
  const conn = await oracledb.getConnection();
  try {
    for (const [type, , name, email] of DEMO_ACCOUNTS) {
      await conn.execute(
        `MERGE INTO rd_users u
         USING (SELECT :e AS email FROM dual) s
            ON (LOWER(TRIM(u.email)) = s.email)
          WHEN MATCHED THEN UPDATE SET
               u.password = LOWER(RAWTOHEX(STANDARD_HASH('1234', 'SHA256'))),
               u.user_type = :t
          WHEN NOT MATCHED THEN INSERT (full_name, email, password, user_type)
               VALUES (:n, :e2, LOWER(RAWTOHEX(STANDARD_HASH('1234', 'SHA256'))), :t2)`,
        { e: email, t: type, n: name, e2: email, t2: type });
    }
    await conn.commit();
    console.log('🔐 حسابات الدخول (كلمة المرور لكلها 1234):');
    for (const [, title, , email] of DEMO_ACCOUNTS) console.log(`   ${title}:  ${email}`);
  } catch (e) {
    console.error('⚠️ تعذر تجهيز الحسابات التجريبية:', e.message);
  } finally {
    await conn.close();
  }
}

// ---------- التشغيل ----------
oracledb.createPool({ ...dbConfig, poolMin: 1, poolMax: 8 })
  .then(ensureDemoAccounts)
  .then(() => app.listen(PORT, '0.0.0.0', () => console.log(`✅ Raha Dheef API on http://0.0.0.0:${PORT}/api`)))
  .catch((e) => { console.error('❌ تعذر الاتصال بقاعدة البيانات:', e.message); process.exit(1); });