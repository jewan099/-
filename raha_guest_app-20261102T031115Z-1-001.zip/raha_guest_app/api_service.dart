import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// ⚠️ غيّري هذا العنوان حسب مكان تشغيل سيرفر Node.js:
/// - محاكي أندرويد والسيرفر على نفس الجهاز:  http://10.0.2.2:3000/api
/// - محاكي iOS / ويب على نفس الجهاز:           http://localhost:3000/api
/// - جهاز حقيقي أو السيرفر على جهاز صديقتك:    http://<IP جهاز السيرفر>:3000/api
const String kApiBaseUrl = 'http://172.20.10.3:3000/api';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

// ==================== أدوات تحويل آمنة ====================
num toNum(dynamic v, [num fallback = 0]) {
  if (v == null) return fallback;
  if (v is num) return v;
  return num.tryParse(v.toString()) ?? fallback;
}

int toInt(dynamic v, [int fallback = 0]) => toNum(v, fallback).round();
double toDouble(dynamic v, [double fallback = 0]) => toNum(v, fallback).toDouble();
String toStr(dynamic v, [String fallback = '']) =>
    (v == null || v.toString().trim().isEmpty || v.toString() == 'null') ? fallback : v.toString();
DateTime? toDate(dynamic v) => v == null ? null : DateTime.tryParse(v.toString())?.toLocal();

Map<String, dynamic> asMap(dynamic d) => d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};

List<Map<String, dynamic>> asList(dynamic data, [String? key]) {
  final raw = data is List ? data : (data is Map && key != null && data[key] is List ? data[key] as List : const []);
  return [for (final e in raw) if (e is Map) Map<String, dynamic>.from(e)];
}

String isoDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

// ==================== جلسة المستخدم الحالي ====================
class Session {
  static Map<String, dynamic>? user;
  static int? get userId => user == null ? null : toInt(user!['user_id']);
  static String get userType => toStr(user?['user_type'], 'USER');
  static String get displayName =>
      toStr(user?['manager_name'], toStr(user?['full_name'], 'ضيف الرحمن'));
  static bool get canBook => userType == 'CAMPAIGN' || userType == 'USER';
  static void clear() => user = null;
}

// ==================== خدمة الاتصال بالسيرفر ====================
class ApiService {
  /// نموذج تقاسم الإيرادات المعتمد في المنصة
  static const double ownerShare = 0.85;
  static const double platformShare = 0.15;

  /// ضريبة القيمة المضافة في المملكة
  static const double vatRate = 0.15;

  /// السعة القياسية لحافلة نقل ضيوف الرحمن (49 راكب + السائق)
  static const int seatsPerBus = 49;

  static const Duration _timeout = Duration(seconds: 15);
  static const Map<String, String> _headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
  };

  static dynamic _normalize(dynamic v) {
    if (v is Map) {
      return <String, dynamic>{
        for (final e in v.entries) e.key.toString().toLowerCase(): _normalize(e.value),
      };
    }
    if (v is List) return v.map(_normalize).toList();
    return v;
  }

  static Future<dynamic> _request(String method, String path,
      {Map<String, dynamic>? body, Map<String, String>? query}) async {
    final q = <String, String>{};
    query?.forEach((k, v) {
      if (v.isNotEmpty) q[k] = v;
    });
    final uri = Uri.parse('$kApiBaseUrl$path').replace(queryParameters: q.isEmpty ? null : q);

    http.Response res;
    try {
      switch (method) {
        case 'GET':
          res = await http.get(uri, headers: _headers).timeout(_timeout);
          break;
        case 'POST':
          res = await http.post(uri, headers: _headers, body: jsonEncode(body ?? {})).timeout(_timeout);
          break;
        case 'PATCH':
          res = await http.patch(uri, headers: _headers, body: jsonEncode(body ?? {})).timeout(_timeout);
          break;
        default:
          throw ApiException('طريقة طلب غير مدعومة');
      }
    } on TimeoutException {
      throw ApiException('انتهت مهلة الاتصال بالسيرفر');
    } catch (e) {
      if (e is ApiException) rethrow;
      // نعرض العنوان وسبب الخطأ الفعلي لتسهيل معرفة المشكلة
      throw ApiException('تعذّر الاتصال بالسيرفر ($uri)\n${e.toString().split('\n').first}');
    }

    dynamic data;
    try {
      data = res.body.isEmpty ? null : jsonDecode(utf8.decode(res.bodyBytes));
    } catch (_) {
      data = null;
    }
    data = _normalize(data);

    if (res.statusCode >= 400) {
      final msg = data is Map ? toStr(data['error'], toStr(data['message'])) : '';
      throw ApiException(msg.isEmpty ? 'خطأ من السيرفر (${res.statusCode})' : msg);
    }
    return data;
  }

  // ---------- الدخول ----------
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final d = asMap(await _request('POST', '/login', body: {'email': email.trim(), 'password': password}));
    final user = asMap(d['user'] ?? d);
    Session.user = user;
    return user;
  }

  // ---------- المحطات ----------
  static Future<List<Map<String, dynamic>>> fetchStations({String? city}) async =>
      asList(await _request('GET', '/stations', query: {if (city != null) 'city': city}), 'stations');

  /// يعيد: {station, services, booking_types, reviews}
  static Future<Map<String, dynamic>> fetchStationDetails(int id) async =>
      asMap(await _request('GET', '/stations/$id'));

  /// يعيد رقم المحطة الجديدة
  static Future<int> addStation(Map<String, dynamic> data) async {
    final d = asMap(await _request('POST', '/stations', body: data));
    return toInt(d['rest_stop_id']);
  }

  static Future<void> approveStation(int id) async => _request('PATCH', '/stations/$id/approve');

  /// كل الخدمات من جدول rd_services
  static Future<List<Map<String, dynamic>>> fetchServices() async =>
      asList(await _request('GET', '/services'), 'services');

  static Future<List<Map<String, dynamic>>> fetchPlans() async =>
      asList(await _request('GET', '/plans'), 'plans');

  // ---------- الحجوزات ----------
  static Future<Map<String, dynamic>> addBooking({
    required int restStopId,
    required int bookingTypeId,
    required DateTime date,
    required String arrivalTime,
    int busCount = 1,
    int peopleCount = 1,
    String? notes,
  }) async =>
      asMap(await _request('POST', '/bookings', body: {
        'user_id': Session.userId,
        'rest_stop_id': restStopId,
        'booking_type_id': bookingTypeId,
        'booking_date': isoDate(date),
        'arrival_time': arrivalTime,
        'bus_count': busCount,
        'people_count': peopleCount,
        'notes': notes,
      }));

  static Future<List<Map<String, dynamic>>> fetchBookings({int? userId, int? restStopId}) async =>
      asList(
          await _request('GET', '/bookings', query: {
            if (userId != null) 'user_id': '$userId',
            if (restStopId != null) 'rest_stop_id': '$restStopId',
          }),
          'bookings');

  static Future<void> cancelBooking(int bookingId) async =>
      _request('PATCH', '/bookings/$bookingId/cancel', body: {'user_id': Session.userId});

  // ---------- المستخدم ----------
  /// يعيد: {user, stats, stations}
  static Future<Map<String, dynamic>> getUserProfile(int userId) async =>
      asMap(await _request('GET', '/users/$userId'));

  // ---------- لوحة صاحب المحطة ----------
  /// يعيد: {user, totals, stations, orders, ledger, pending_payouts, upcoming}
  static Future<Map<String, dynamic>> getOwnerDashboard(int userId) async =>
      asMap(await _request('GET', '/owners/$userId/dashboard'));

  /// متوافقة مع الكود القديم في MainNavigationScreen
  static Future<Map<String, dynamic>> getDashboardStats() async {
    final id = Session.userId;
    if (id == null) return {};
    try {
      return await getOwnerDashboard(id);
    } catch (_) {
      return {};
    }
  }

  static Future<Map<String, dynamic>> getAdminOverview() async =>
      asMap(await _request('GET', '/admin/overview'));

  static Future<List<Map<String, dynamic>>> fetchMeals() async =>
      asList(await _request('GET', '/meals'), 'meals');

  static Future<void> updateMealOrderStatus(int orderId, String status) async =>
      _request('PATCH', '/meal-orders/$orderId/status', body: {'status': status});

  static Future<String> requestPayout(int restStopId, double amount) async {
    final d = asMap(await _request('POST', '/payouts',
        body: {'rest_stop_id': restStopId, 'user_id': Session.userId, 'amount': amount}));
    return toStr(d['payout_code']);
  }

  // ---------- النقاط والمكافآت ----------
  static Future<List<Map<String, dynamic>>> fetchRewards() async =>
      asList(await _request('GET', '/rewards'), 'rewards');

  static Future<String> redeemReward(int rewardId) async {
    final d = asMap(await _request('POST', '/rewards/redeem',
        body: {'user_id': Session.userId, 'reward_id': rewardId}));
    return toStr(d['voucher_code']);
  }
}