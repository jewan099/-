import 'dart:async';
import 'package:flutter/material.dart';
import 'api_service.dart';



void main() {
  runApp(const RahaDheefApp());
}

class RahaDheefApp extends StatelessWidget {
  const RahaDheefApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'راحة ضيف',
      debugShowCheckedModeBanner: false,
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child!,
        );
      },
      theme: ThemeData(
        fontFamily: 'IBM Plex Sans Arabic',
        scaffoldBackgroundColor: const Color(0xFFFCF9F8),
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF0E4436),
          onPrimary: Colors.white,
          secondary: Color(0xFF765A00),
          surface: Color(0xFFFCF9F8),
          onSurface: Color(0xFF1B1C1C),
        ),
      ),
      home: const LoginScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;
  Map<String, dynamic>? statsData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final data = await ApiService.getDashboardStats();
    setState(() {
      statsData = data;
      isLoading = false;
    });
  }

  void _showToast(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Color(0xFFEFC043), size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF0E4436),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.only(top: 50, left: 16, right: 16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _navigateToTab(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      AddStationScreen(
      onShowToast: _showToast,
      onNavigateBack: () => _navigateToTab(0), // أو رقم التاب المناسب للرجوع (مثلاً 0 للرئيسية)
      ),
      HomeScreen(
        onShowToast: _showToast,
        onNavigateToDetails: () => _navigateToTab(1),
        onNavigateToBookings: () => _navigateToTab(2),
      ),
      StationDetailsScreen(
        onShowToast: _showToast,
        onNavigateBack: () => _navigateToTab(0),
        onNavigateToBookings: () => _navigateToTab(2),
      ),
      MyBookingsScreen(
        onShowToast: _showToast,
        onNavigateToDetails: () => _navigateToTab(1),
      ),
      AddStationScreen( // أصبحت بنفس نمط استقبال الدوال
        onShowToast: _showToast,
        onNavigateBack: () => _navigateToTab(3),
      ),
      StationDashboardScreen(
        onShowToast: _showToast,
        onNavigateToAddStation: () => _navigateToTab(5),
      ),
      MyAccountScreen( // شاشة الحساب الشخصي (الملف الشخصي)
        onShowToast: _showToast,
        onNavigateToAddStation: () => _navigateToTab(5),
      ),
    ];

    return Scaffold(
      body: pages[_selectedIndex >= pages.length ? 0 : _selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex >= pages.length ? 0 : _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        selectedItemColor: const Color(0xFF0E4436),
        unselectedItemColor: const Color(0xFF404945),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
        unselectedLabelStyle: const TextStyle(fontSize: 11),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.explore),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_bus_outlined),
            label: 'المحطات',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.book_online_outlined),
            label: 'حجوزاتي',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_business_outlined),
            label: 'إضافة محطة',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance_wallet_outlined),
            label: 'إدارة المحطة',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle_outlined),
            label: 'حسابي',
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// 1. شريط تنقل صاحب الحملة
// ============================================================================
class CampaignNavigationScreen extends StatefulWidget {
  const CampaignNavigationScreen({super.key});

  @override
  State<CampaignNavigationScreen> createState() => _CampaignNavigationScreenState();
}

class _CampaignNavigationScreenState extends State<CampaignNavigationScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => setState(() => _selectedIndex = 1), onNavigateToBookings: () => setState(() => _selectedIndex = 2)),
      StationDetailsScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateBack: () => setState(() => _selectedIndex = 0), onNavigateToBookings: () => setState(() => _selectedIndex = 2)),
      MyBookingsScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => setState(() => _selectedIndex = 1)),
      MyAccountScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToAddStation: () {}),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF0E4436),
        unselectedItemColor: const Color(0xFF707975),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.directions_bus_outlined), label: 'المحطات'),
          BottomNavigationBarItem(icon: Icon(Icons.book_online_outlined), label: 'حجوزاتي'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

// ============================================================================
// 2. شريط تنقل صاحب المحطة
// ============================================================================
class StationOwnerNavigationScreen extends StatefulWidget {
  const StationOwnerNavigationScreen({super.key});

  @override
  State<StationOwnerNavigationScreen> createState() => _StationOwnerNavigationScreenState();
}

class _StationOwnerNavigationScreenState extends State<StationOwnerNavigationScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => openDetailsRoute(context), onNavigateToBookings: () => showAppToast(context, 'الحجز متاح لأصحاب الحملات وضيوف الرحمن')),
      AddStationScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateBack: () => setState(() => _selectedIndex = 0)),
      StationDashboardScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToAddStation: () => setState(() => _selectedIndex = 1)),
      MyAccountScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToAddStation: () => setState(() => _selectedIndex = 1)),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF0E4436),
        unselectedItemColor: const Color(0xFF707975),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.add_business_outlined), label: 'إضافة محطة'),
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_outlined), label: 'إدارة المحطة'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

// ============================================================================
// 3. شريط تنقل مدير التطبيق
// ============================================================================
class AdminNavigationScreen extends StatefulWidget {
  const AdminNavigationScreen({super.key});

  @override
  State<AdminNavigationScreen> createState() => _AdminNavigationScreenState();
}

class _AdminNavigationScreenState extends State<AdminNavigationScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => openDetailsRoute(context), onNavigateToBookings: () => showAppToast(context, 'الحجز متاح لأصحاب الحملات وضيوف الرحمن')),
      StationDashboardScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToAddStation: () => setState(() => _selectedIndex = 2)),
      AddStationScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateBack: () => setState(() => _selectedIndex = 0)),
      MyAccountScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToAddStation: () => setState(() => _selectedIndex = 2)),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF0E4436),
        unselectedItemColor: const Color(0xFF707975),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.admin_panel_settings_outlined), label: 'الإدارة'),
          BottomNavigationBarItem(icon: Icon(Icons.add_business_outlined), label: 'إضافة محطة'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

// ============================================================================
// 4. شريط تنقل ضيف الرحمن
// ============================================================================
class GuestNavigationScreen extends StatefulWidget {
  const GuestNavigationScreen({super.key});

  @override
  State<GuestNavigationScreen> createState() => _GuestNavigationScreenState();
}

class _GuestNavigationScreenState extends State<GuestNavigationScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => setState(() => _selectedIndex = 1), onNavigateToBookings: () => setState(() => _selectedIndex = 2)),
      StationDetailsScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateBack: () => setState(() => _selectedIndex = 0), onNavigateToBookings: () => setState(() => _selectedIndex = 2)),
      MyBookingsScreen(onShowToast: (msg) => showAppToast(context, msg), onNavigateToDetails: () => setState(() => _selectedIndex = 1)),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF0E4436),
        unselectedItemColor: const Color(0xFF707975),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.directions_bus_outlined), label: 'المحطات'),
          BottomNavigationBarItem(icon: Icon(Icons.book_online_outlined), label: 'حجوزاتي'),
        ],
      ),
    );
  }
}


// ==================== تسجيل الدخول ====================
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

int? lastSelectedRoleIndex; 
class _LoginScreenState extends State<LoginScreen> {
  int? _selectedRoleIndex = lastSelectedRoleIndex;
  bool _obscurePassword = true;
  bool _rememberDevice = true;
  bool _loading = false;
  final TextEditingController _idCtrl = TextEditingController();
  final TextEditingController _passCtrl = TextEditingController();

  static const List<String> _roleTypes = ['CAMPAIGN', 'OWNER', 'ADMIN', 'USER'];

  @override
  void dispose() {
    _idCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  /// التحقق من الحساب في قاعدة البيانات (fn_login) والتأكد أن صفته تطابق الفئة المختارة
  Future<bool> _authenticate() async {
    final idx = _selectedRoleIndex;
    if (idx == null) {
      showAppToast(context, 'اختر الفئة المصرح بها أولاً', error: true);
      return false;
    }
    if (_idCtrl.text.trim().isEmpty || _passCtrl.text.isEmpty) {
      showAppToast(context, 'أدخل البريد الإلكتروني وكلمة المرور', error: true);
      return false;
    }
    setState(() => _loading = true);
    try {
      final user = await ApiService.login(_idCtrl.text, _passCtrl.text);
      if (toStr(user['user_type']) != _roleTypes[idx]) {
        Session.clear();
        throw ApiException('هذا الحساب غير مسجّل بصفة "${_roles[idx]['title']}" — اختر الفئة الصحيحة');
      }
      return true;
    } catch (e) {
      if (mounted) showAppToast(context, e.toString(), error: true);
      return false;
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  final List<Map<String, dynamic>> _roles = [
    {
      'title': 'صاحب الحملة',
      'sub': 'إدارة القوافل والتفويج',
      'icon': Icons.directions_bus_outlined,
      'activeIcon': Icons.directions_bus,
      'desc': 'تصاريح تفويج الحافلات، تتبع القوافل وإدارة الرحلات الميدانية',
      'label': 'رقم ترخيص الحملة أو البريد الإلكتروني',
      'placeholder': 'رقم ترخيص الحملة أو البريد الإلكتروني',
    },
    {
      'title': 'صاحب المحطة',
      'sub': 'الاستراحات و الطعام',
      'icon': Icons.storefront_outlined,
      'activeIcon': Icons.storefront,
      'desc': 'إدارة استراحات الطرق، تتبع الإعاشة وتأكيد وصول الحافلات',
      'label': 'رقم السجل التجاري / محطة الوقود',
      'placeholder': 'رقم السجل التجاري / محطة الوقود',
    },
    {
      'title': 'مدير التطبيق',
      'sub': 'الإشراف والرقابة',
      'icon': Icons.admin_panel_settings_outlined,
      'activeIcon': Icons.admin_panel_settings,
      'desc': 'الإشراف العام، مراقبة مؤشرات الأداء والأمان التشغيلي',
      'label': 'الرمز الوظيفي أو البريد الإداري',
      'placeholder': 'الرمز الوظيفي أو البريد الإداري الرسمي',
    },
    {
      'title': 'ضيف الرحمن',
      'sub': 'الحجز والخدمات',
      'icon': Icons.mosque_outlined,
      'activeIcon': Icons.mosque,
      'desc': 'استعراض مسار الرحلة، المحطات المعتمدة، وطلب الخدمات المباشرة',
      'label': 'رقم الهوية / الإقامة أو البريد',
      'placeholder': 'رقم الهوية / الإقامة أو رقم الجوال',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final currentRole = _roles[_selectedRoleIndex ?? 3]; // جعلناها فارغة لكي لا تختار "ضيف الرحمن" تلقائياً];

    return Scaffold(
      backgroundColor: const Color(0xFFFCF9F8),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // 1. Top Utility Bar
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEAE7E7),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Color(0xFF366758),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'بوابة الدخول الموحدة',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF404945),
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton.icon(
                    style: TextButton.styleFrom(
                      backgroundColor: const Color(0xFFB9EEDA).withOpacity(0.4),
                      foregroundColor: const Color(0xFF0E4436),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    onPressed: () {},
                    icon: const Icon(Icons.support_agent, size: 18),
                    label: const Text(
                      'المساعدة',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // 2. Branding & Official Header
              Stack(
                alignment: Alignment.bottomCenter,
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 104,
                    height: 104,
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Image.asset(
                        'assets/images/logo.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: -10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF0E4436),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.verified, size: 12, color: Colors.white),
                          SizedBox(width: 4),
                          Text(
                            'المنصة الرسمية',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                'تسجيل الدخول',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF0E4436),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'اختر صفتك وسجّل بياناتك للوصول لمنصتك المتكاملة لتنظيم وتسهيل استراحات ضيوف الرحمن وخدمات النقل',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF404945),
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),

              // 3. Main Card Container
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Role Selector Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.badge_outlined, size: 20, color: Color(0xFF0E4436)),
                            SizedBox(width: 8),
                            Text(
                              'اختر الفئة المصرح بها',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1B1C1C),
                              ),
                            ),
                          ],
                        ),
                        const Text(
                          'مطلوب خطوة 1',
                          style: TextStyle(fontSize: 11, color: Color(0xFF707975)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Grid of 4 Roles
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        childAspectRatio: 1.25,
                      ),
                      itemCount: _roles.length,
                      itemBuilder: (context, index) {
                        final role = _roles[index];
                        final isSelected = _selectedRoleIndex == index;

                        return InkWell(
                          onTap: () {
                            setState(() {
                              _selectedRoleIndex = index;lastSelectedRoleIndex = index;
                            });
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF2A5C4D)
                                  : const Color(0xFFF6F3F2),
                              borderRadius: BorderRadius.circular(16),
                              border: isSelected
                                  ? Border.all(color: const Color(0xFFFECE50), width: 2)
                                  : null,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Icon(
                                      isSelected ? role['activeIcon'] : role['icon'],
                                      size: 26,
                                      color: isSelected
                                          ? const Color(0xFFFECE50)
                                          : const Color(0xFF366758),
                                    ),
                                    if (isSelected)
                                      Container(
                                        width: 16,
                                        height: 16,
                                        decoration: const BoxDecoration(
                                          color: Color(0xFFFECE50),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Center(
                                          child: Text(
                                            '✓',
                                            style: TextStyle(
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF735800),
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      role['title'],
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                        color: isSelected ? Colors.white : const Color(0xFF1B1C1C),
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      role['sub'],
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: isSelected
                                            ? Colors.white.withOpacity(0.9)
                                            : const Color(0xFF404945),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 12),

                    // Selected Role Banner Info
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFB9EEDA).withOpacity(0.3),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2A5C4D),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              currentRole['activeIcon'],
                              size: 16,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    const Text(
                                      'تسجيل الدخول بصفتك: ',
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF0E4436),
                                      ),
                                    ),
                                    Text(
                                      currentRole['title'],
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF1B1C1C),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  currentRole['desc'],
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Color(0xFF404945),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Input Fields Form
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              currentRole['label'],
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1B1C1C),
                              ),
                            ),
                            const Text(
                              'اسم المستخدم',
                              style: TextStyle(fontSize: 11, color: Color(0xFF707975)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _idCtrl,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            hintText: currentRole['placeholder'],
                            hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF707975)),
                            prefixIcon: const Icon(Icons.alternate_email, color: Color(0xFF707975), size: 20),
                            filled: true,
                            fillColor: const Color(0xFFF6F3F2),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Password Field
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'كلمة المرور',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1B1C1C),
                              ),
                            ),
                            TextButton(
                              style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: Size.zero),
                              onPressed: () {},
                              child: const Text(
                                'نسيت كلمة المرور؟',
                                style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _passCtrl,
                          obscureText: _obscurePassword,
                          decoration: InputDecoration(
                            hintText: '••••••••••••',
                            hintStyle: const TextStyle(fontSize: 14, color: Color(0xFF707975)),
                            prefixIcon: const Icon(Icons.lock_outline, color: Color(0xFF707975), size: 20),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                                color: const Color(0xFF707975),
                                size: 20,
                              ),
                              onPressed: () {
                                setState(() {
                                  _obscurePassword = !_obscurePassword;
                                });
                              },
                            ),
                            filled: true,
                            fillColor: const Color(0xFFF6F3F2),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                        const SizedBox(height: 12),

                        // Remember Device & Status
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Checkbox(
                                  value: _rememberDevice,
                                  onChanged: (val) {
                                    setState(() {
                                      _rememberDevice = val ?? true;
                                    });
                                  },
                                  activeColor: const Color(0xFF0E4436),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                                ),
                                const Text(
                                  'تذكّر هذا الجهاز',
                                  style: TextStyle(fontSize: 12, color: Color(0xFF1B1C1C)),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFF366758).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Row(
                                children: [
                                  Icon(Icons.lock, size: 12, color: Color(0xFF366758)),
                                  SizedBox(width: 4),
                                  Text(
                                    'جلسة موثقة',
                                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: Color(0xFF366758)),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Submit Button
                                                // Submit Button
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF0E4436),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 2,
                            ),
                            onPressed: _loading ? null : () async {
  if (!await _authenticate()) return;
  if (!mounted) return;
  switch (_selectedRoleIndex) {
    case 0: // صاحب الحملة -> (الرئيسية، المحطات، حجوزاتي، حسابي)
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const CampaignNavigationScreen(),
        ),
      );
      break;

    case 1: // صاحب المحطة -> (الرئيسية، إضافة محطة، إدارة المحطة، حسابي)
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const StationOwnerNavigationScreen(),
        ),
      );
      break;

    case 2: // مدير التطبيق -> لوحة تحكم الإدارة والتصفح الكامل
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const AdminNavigationScreen(),
        ),
      );
      break;

    case 3: // ضيف الرحمن -> (الرئيسية، المحطات، حجوزاتي)
    default:
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const GuestNavigationScreen(),
        ),
      );
      break;
  }
},

                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'تسجيل الدخول للمنصة',
                                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                                ),
                                SizedBox(width: 8),
                                Icon(Icons.arrow_back, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Footer Support & Security Badges
              TextButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.help_center_outlined, size: 18, color: Color(0xFF0E4436)),
                label: const Text(
                  'تحتاج مساعدة في الدخول؟ مركز الدعم الموحد (متاح 24/7)',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0E4436)),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFF0EDED),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.verified_user_outlined, size: 14, color: Color(0xFF366758)),
                    SizedBox(width: 6),
                    Text(
                      'بياناتك محمية ومشفرة وفق أعلى معايير الأمن السيبراني السعودية',
                      style: TextStyle(fontSize: 10, color: Color(0xFF404945)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'تطبيق راحة ضيف لخدمات الحجاج والمعتمرين',
                style: TextStyle(fontSize: 11, color: Color(0xFF707975)),
              ),
              const SizedBox(height: 2),
              const Text(
                'الإصدار 2.4.0 • جميع الحقوق محفوظة © 1446هـ',
                style: TextStyle(fontSize: 11, color: Color(0xFF707975)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}




// ==================== الصفحة الرئيسية ====================
class HomeScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateToDetails;
  final VoidCallback onNavigateToBookings;

  const HomeScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateToDetails,
    required this.onNavigateToBookings,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Function(String) get onShowToast => widget.onShowToast;
  VoidCallback get onNavigateToDetails => widget.onNavigateToDetails;
  VoidCallback get onNavigateToBookings => widget.onNavigateToBookings;

  // ---------- بيانات قاعدة البيانات ----------
  List<Station> _stations = [];
  Map<String, dynamic> _user = {};
  List<Map<String, dynamic>> _rewards = [];
  List<Map<String, dynamic>> _bookings = [];
  String _query = '';
  String? _serviceFilter;

  static const Map<String, List<String>> _categoryKeys = {
    'مصلى واسع': ['مصلى'],
    'دورات مياة': ['دورات'],
    'مطاعم': ['مطعم', 'مطاعم', 'مقه'],
    'وقود وصيانة': ['وقود', 'صيانة', 'غسيل'],
    'إسعاف أولي': ['إسعاف', 'صحي', 'عيادة', 'طوارئ', 'صيدلية'],
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final list = await ApiService.fetchStations();
      _stations = list.map(Station.new).toList();
    } catch (_) {}
    final uid = Session.userId;
    if (uid != null) {
      try {
        _user = asMap((await ApiService.getUserProfile(uid))['user']);
      } catch (_) {}
      if (Session.canBook) {
        try {
          _bookings = await ApiService.fetchBookings(userId: uid);
        } catch (_) {}
        try {
          _rewards = await ApiService.fetchRewards();
        } catch (_) {}
      }
    }
    if (mounted) setState(() {});
  }

  List<Station> get _visibleStations => _stations.where((s) {
        final q = _query;
        final okQ = q.isEmpty || s.title.contains(q) || s.city.contains(q) || s.area.contains(q) || s.highway.contains(q);
        final keys = _serviceFilter == null ? null : _categoryKeys[_serviceFilter!];
        final okS = keys == null || s.services.any((x) => keys.any((k) => x.contains(k)));
        return okQ && okS;
      }).toList();

  Map<String, dynamic>? get _activeBooking {
    final today = dateOnly(DateTime.now());
    final list = _bookings.where((b) {
      final d = toDate(b['booking_date']);
      return toStr(b['status']) == 'confirmed' && d != null && !dateOnly(d).isBefore(today);
    }).toList()
      ..sort((a, b) => toDate(a['booking_date'])!.compareTo(toDate(b['booking_date'])!));
    return list.isEmpty ? null : list.first;
  }

  /// من أقرب 5 محطات فيها مواقف شاغرة: الأقل إشغالاً
  Station? get _bestStation {
    final c = _stations.where((s) => !s.isPending && s.vacantSpots > 0).toList()
      ..sort((a, b) => (a.distanceKm ?? 9999).compareTo(b.distanceKm ?? 9999));
    if (c.isEmpty) return null;
    final near = c.take(5).toList()..sort((a, b) => a.occupancy.compareTo(b.occupancy));
    return near.first;
  }

  String get _welcomeName {
    if (Session.user == null) return 'أهلاً بك كابتن تركي';
    if (Session.userType == 'CAMPAIGN') return 'أهلاً بك ${Session.displayName}';
    return 'أهلاً بك ${toStr(_user['full_name'], Session.displayName)}';
  }

  void _openStation(Station s) {
    selectedStation = s;
    onNavigateToDetails();
  }

  void _bookStation(Station s) {
    if (!Session.canBook) {
      onShowToast('الحجز متاح لأصحاب الحملات وضيوف الرحمن');
      return;
    }
    if (s.isPending) {
      onShowToast('هذه المحطة قيد مراجعة الإدارة ولا تستقبل حجوزات بعد');
      return;
    }
    if (s.vacantSpots <= 0) {
      onShowToast('لا توجد مواقف شاغرة في ${s.title} حالياً');
      return;
    }
    bookingTargetStation = s;
    onShowToast("جاري الانتقال لصفحة الحجز...");
    onNavigateToBookings();
  }

  Future<void> _redeem() async {
    final points = toInt(_user['loyalty_points']);
    final options = _rewards.where((r) => toInt(r['cost_points']) <= points).toList()
      ..sort((a, b) => toInt(a['cost_points']).compareTo(toInt(b['cost_points'])));
    if (options.isEmpty) {
      onShowToast('رصيد النقاط لا يكفي لأي مكافأة حالياً');
      return;
    }
    final chosen = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('اختر المكافأة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        children: [
          for (final r in options)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, r),
              child: Text('${toStr(r['title'])} — ${r['cost_points']} نقطة', style: const TextStyle(fontSize: 13)),
            ),
        ],
      ),
    );
    if (chosen == null) return;
    try {
      final code = await ApiService.redeemReward(toInt(chosen['reward_id']));
      onShowToast('تم إصدار القسيمة $code: ${toStr(chosen['title'])}');
      _loadData();
    } catch (e) {
      onShowToast(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xD9FCF9F8),
        elevation: 0.5,
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: Color(0x1A2A5C4D),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.mosque,
                color: Color(0xFF0E4436),
                size: 20,
              ),
            ),
            const SizedBox(width: 8),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'راحة ضيف',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0E4436),
                  ),
                ),
                Text(
                  'منصة خدمة حافلات المعتمرين',
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xFF404945),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          SizedBox(
  width: 36,
  height: 36,
  child: IconButton(
    padding: EdgeInsets.zero,
    icon: const Icon(Icons.logout, size: 18, color: Color(0xFF0E4436)),
    tooltip: 'تسجيل الخروج',
    onPressed: () {
      // العودة إلى شاشة تسجيل الدخول وحذف مسار التنقل السابق
      Session.clear();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    },
  ),
),


          const Padding(
            padding: EdgeInsets.only(left: 16.0),
            child: CircleAvatar(
              radius: 16,
              backgroundImage: NetworkImage(
                'https://lh3.googleusercontent.com/aida/AEtjO1XnqM0nV_90wtxn8gBzctsKEAKfKnVVrcZjey1WAAZs6SBedREwp9dU2TrBuCxKTmnkMSOiVxyGA4F5qBIHmVM7kgfQJbBycTjD45V9d7UjAB1OlsxnaWqyW3DEhL1Pud-TkVTsPXEtkzQ9y9owqJnqmhGG2nYuFNN5RijD2y0q3Pypq-FQwX8_qLikqHAIICccM5f8G0VVkCxKhfO0Y2sohOJgD5RgCvydl_HCPeAoAOHQvr4V3Xsk8RIZ6AdJKjPc0qdDUwY6RQ',
              ),
              backgroundColor: Color(0x330E4436),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildWelcomeCard(),
            const SizedBox(height: 16),
            
            _buildSmartAlertCard(),
            const SizedBox(height: 16),
            _buildGuestPointsCard(), 
            const SizedBox(height: 12), 
            _buildSearchBar(),
            const SizedBox(height: 20),
            _buildCategoriesSection(),
            const SizedBox(height: 20),
            _buildMapCard(),
            const SizedBox(height: 20),
            _buildRecommendedSection(),
            const SizedBox(height: 20),
            _buildAddStationBar(context),
            const SizedBox(height: 16),
          ],
        ),
      ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Color(0x1A0E4436),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.verified_user, color: Color(0xFF0E4436), size: 24),
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_welcomeName, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                      const Text('ضيوف الرحمن في رعايتكم الكريمة', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    ],
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFB9EEDA),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    const CircleAvatar(radius: 3, backgroundColor: Color(0xFF0E4436)),
                    const SizedBox(width: 4),
                    Text(Session.user == null || _activeBooking != null ? 'رحلة نشطة' : 'لا رحلة نشطة', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF1C4F41))),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFF6F3F2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Row(
                  children: [
                    const Icon(Icons.alt_route, color: Color(0xFF0E4436), size: 20),
                    const SizedBox(width: 8),
                    Flexible(child: Text(_activeBooking != null ? toStr(_activeBooking!['app_title'], toStr(_activeBooking!['station_name'])) : (_bestStation?.highway.isNotEmpty == true ? _bestStation!.highway : 'طريق الهجرة السريع'), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis)),
                  ],
                ),
                ),
                Row(
                  children: [
                    const Icon(Icons.schedule, size: 16, color: Color(0xFF404945)),
                    const SizedBox(width: 4),
                    Text(_activeBooking != null ? 'الوصول المتوقع: ${arTime(toStr(_activeBooking!['arrival_time']))}' : 'الوصول المتوقع: 04:30 م', style: const TextStyle(fontSize: 12, color: Color(0xFF404945))),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSmartAlertCard() {
    return InkWell(
      onTap: () => _bestStation != null ? _openStation(_bestStation!) : onNavigateToDetails(),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFFFECE50),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: Color(0x26765A00),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.info, color: Color(0xFF765A00), size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('تنبيه ذكي للمسار', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF735800))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: const Color(0xB3FFFFFF),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(_bestStation?.distanceKm != null ? 'بعد ${fmtMoney(_bestStation!.distanceKm!, decimals: 0)} كم' : 'بعد 35 كم', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF765A00))),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(fontSize: 14, color: Color(0xFF735800), fontFamily: 'IBM Plex Sans Arabic'),
                      children: [
                        TextSpan(text: _bestStation != null ? '${_bestStation!.title} القادمة جاهزة لاستقبالكم — يتوفر ' : 'محطة واحة الحرمين القادمة جاهزة لاستقبالكم — يتوفر '),
                        TextSpan(text: _bestStation != null ? '${_bestStation!.vacantSpots} موقف حافلات شاغر ' : '12 موقف حافلات شاغر ', style: const TextStyle(fontWeight: FontWeight.bold)),
                        TextSpan(text: _bestStation == null || _bestStation!.services.any((x) => x.contains('مصلى')) ? 'حالياً ومصليات مهيأة.' : 'حالياً بنسبة إشغال ${_bestStation!.occupancy.round()}%.'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // بطاقة نقاط راحة ضيف
    // بطاقة نقاط راحة ضيف (معدلة لتكون بالترتيب الصحيح)
  Widget _buildGuestPointsCard() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0E4436),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // 1. أيقونة النجمة (تصبح على اليمين)
              Container(
                width: 32,
                height: 32,
                decoration: const BoxDecoration(
                  color: Color(0xFF1B5344),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.star,
                  color: Color(0xFFF7C967),
                  size: 18,
                ),
              ),

              // 2. النصوص والتفاصيل (في المنتصف)
              Expanded(
  child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 8.0),
    child: Directionality(
      textDirection: TextDirection.rtl, // لضمان الاتجاه الصحيح من اليمين لليسار
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // يبدأ من اليمين مع الاتجاه العربي
        children: [
          Text(
            _user.isEmpty ? 'نقاط راحة ضيف: 1,850 نقطة' : 'نقاط راحة ضيف: ${fmtMoney(toInt(_user['loyalty_points']))} نقطة',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            _pointsHint,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 11,
            ),
          ),
        ],
      ),
    ),
  ),
),


              // 3. زر استبدال (يصبح على اليسار)
              ElevatedButton.icon(
                onPressed: _redeem,
                icon: const Icon(Icons.card_giftcard, size: 16, color: Color(0xFF0E4436)),
                label: const Text(
                  'استبدال',
                  style: TextStyle(
                    color: Color(0xFF0E4436),
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF7C967),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  elevation: 0,
                  minimumSize: Size.zero,
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          // شريط التقدم
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: _pointsProgress,
              minHeight: 5,
              backgroundColor: const Color(0xFF1B5344),
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFF7C967)),
            ),
          ),
        ],
      ),
    );
  }

  /// المكافأة التالية حسب رصيد النقاط الفعلي (جدول rd_rewards)
  Map<String, dynamic>? get _nextReward {
    final points = toInt(_user['loyalty_points']);
    final sorted = [..._rewards]..sort((a, b) => toInt(a['cost_points']).compareTo(toInt(b['cost_points'])));
    for (final r in sorted) {
      if (toInt(r['cost_points']) > points) return r;
    }
    return null;
  }

  String get _pointsHint {
    if (_user.isEmpty || _rewards.isEmpty) return 'متبقي 150 نقطة لقسيمة وقود 100 ر.س';
    final points = toInt(_user['loyalty_points']);
    final next = _nextReward;
    if (next != null) return 'متبقي ${fmtMoney(toInt(next['cost_points']) - points)} نقطة لـ ${toStr(next['title'])}';
    final best = ([..._rewards]..sort((a, b) => toInt(b['cost_points']).compareTo(toInt(a['cost_points'])))).first;
    return 'رصيدك يكفي لـ ${toStr(best['title'])}';
  }

  double get _pointsProgress {
    if (_user.isEmpty || _rewards.isEmpty) return 0.85;
    final next = _nextReward;
    if (next == null) return 1;
    return (toInt(_user['loyalty_points']) / toInt(next['cost_points'], 1)).clamp(0, 1).toDouble();
  }




  Widget _buildSearchBar() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFF0EDED)),
            ),
            child: TextField(
              onChanged: (v) => setState(() => _query = v.trim()),
              decoration: const InputDecoration(
                hintText: 'ابحث عن محطة، استراحة، أو طريق (طريق الهجرة...)',
                hintStyle: TextStyle(fontSize: 14, color: Color(0xFF707975)),
                prefixIcon: Icon(Icons.search, color: Color(0xFF707975)),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        InkWell(
          onTap: () {
            setState(() => _serviceFilter = null);
            onShowToast("خيارات التصفية السريعة مفعلة");
          },
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xFF2A5C4D),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.tune, color: Colors.white, size: 22),
          ),
        ),
      ],
    );
  }

  Widget _buildCategoriesSection() {
    final categories = [
      {'title': 'مصلى واسع', 'sub': 'مكيف ومجهز', 'icon': Icons.mosque, 'color': const Color(0xFFB9EEDA), 'iconColor': const Color(0xFF1C4F41)},
      {'title': 'دورات مياة', 'sub': 'شامل التعقيم', 'icon': Icons.wash, 'color': const Color(0xFFEAE7E7), 'iconColor': const Color(0xFF0E4436)},
      {'title': 'مطاعم', 'sub': 'وجبات صحية', 'icon': Icons.restaurant, 'color': const Color(0xFFFFDF96), 'iconColor': const Color(0xFF251A00)},
      {'title': 'وقود وصيانة', 'sub': 'مسارات ديزل', 'icon': Icons.local_gas_station, 'color': const Color(0xFFEAE7E7), 'iconColor': const Color(0xFF1E433A)},
      {'title': 'إسعاف أولي', 'sub': 'طوارئ 24/7', 'icon': Icons.medical_services, 'color': const Color(0xFFFFDAD6), 'iconColor': const Color(0xFF93000A)},
    ];

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('الخدمات والمرافق المتوفرة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextButton(
              onPressed: () {
                setState(() => _serviceFilter = null);
                onShowToast('تم تصفية المحطات حسب خدمة: الكل');
              },
              child: const Text('عرض الكل', style: TextStyle(fontSize: 12, color: Color(0xFF0E4436))),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 120,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (context, index) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final cat = categories[index];
              return InkWell(
                onTap: () {
                  setState(() => _serviceFilter = cat['title'] as String);
                  onShowToast('تم تصفية المحطات حسب خدمة: ${cat['title']}');
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 94,
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFF0EDED)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: cat['color'] as Color,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(cat['icon'] as IconData, color: cat['iconColor'] as Color, size: 22),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        cat['title'] as String,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        cat['sub'] as String,
                        style: TextStyle(fontSize: 10, color: index == 4 ? Colors.red : const Color(0xFF404945)),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMapCard() {
    return Column(
      children: [
                Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded( // <--- أضيفي Expanded هنا لكي يمنع التجاوز
              child: Row(
                children: const [
                  Icon(Icons.map, color: Color(0xFF0E4436), size: 22),
                  SizedBox(width: 8),
                  Text(
                    'خريطة محطات الطريق السريع',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), // صغّرنا الخط قليلاً لكي يناسب الشاشة
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFEAE7E7),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text('المدينة • جدة • مكة', style: TextStyle(fontSize: 10, color: Color(0xFF404945))), // اختصرنا النص قليلاً
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 256,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            image: const DecorationImage(
              image: AssetImage (
                '/Users/rolly/Downloads/IMG_4617.jpeg',
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: [
              Container(color: const Color(0x330E4436)),
              Positioned(
                top: 16,
                right: 24,
                child: GestureDetector(
                  onTap: () => _stations.isNotEmpty ? _openStation(_stations.first) : onNavigateToDetails(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0E4436),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.mosque, color: Colors.white, size: 14),
                        const SizedBox(width: 4),
                        Text(_stations.isEmpty ? '1.  جبل الكعبة (مكه -  40 كم)' : '1.  ${_stations.first.title} (${_stations.first.shortCity}${_stations.first.distanceKm != null ? ' -  ${fmtMoney(_stations.first.distanceKm!, decimals: 0)} كم' : ''})', style: const TextStyle(color: Colors.white, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 12,
                left: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xE6FFFFFF),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.navigation, color: Color(0xFF0E4436), size: 20),
                          SizedBox(width: 6),
                          Text('المسار المعتمد: المدينة المنورة ↔ جدة ↔ مكة', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color.fromARGB(255, 42, 92, 77),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          minimumSize: Size.zero,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                        ),
                        onPressed: onNavigateToDetails,
                        icon: const Icon(Icons.open_in_full, size: 14, color: Colors.white),
                        label: const Text('توسيع الخريطة', style: TextStyle(fontSize: 11, color: Colors.white)),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

    // ==================== قسم المحطات الموصى بها (المحطات الـ 6) ====================
  Widget _buildRecommendedSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Row(
              children: [
                Icon(Icons.recommend, color: Color(0xFF0E4436), size: 22),
                SizedBox(width: 8),
                Text('محطات موصى بها لك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            TextButton(
              onPressed: onNavigateToDetails,
              child: const Text('عرض الكل', style: TextStyle(fontSize: 12, color: Color(0xFF0E4436))),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 380,
          // ربط الـ FutureBuilder لجلب البيانات من قاعدة البيانات rahadhaif_api في الخلفية
          child: Builder(
            builder: (context) {
              // المحطات الحقيقية من قاعدة البيانات بنفس تصميم البطاقة
              if (_stations.isNotEmpty) {
                final list = _visibleStations;
                if (list.isEmpty) {
                  return const Center(child: Text('لا توجد محطات مطابقة للبحث', style: TextStyle(fontSize: 12, color: Color(0xFF404945))));
                }
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 16),
                  itemBuilder: (_, i) => _buildStationCard(list[i], i),
                );
              }
              // في حال تعذّر الاتصال بالسيرفر تظهر الكروت الأساسية
              return ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  _buildCard1(),
                  const SizedBox(width: 16),
                  _buildCard2(),
                  const SizedBox(width: 16),
                  _buildCard3(),
                  const SizedBox(width: 16),
                  _buildCard4(),
                  const SizedBox(width: 16),
                  _buildCard5(),
                  const SizedBox(width: 16),
                  _buildCard6(),
                  const SizedBox(width: 16),
                  _buildCard7(),
                  const SizedBox(width: 16),
                  _buildCard8(),
                  const SizedBox(width: 16),
                  _buildCard9(),
                  const SizedBox(width: 16),
                  _buildCard10(),
                  const SizedBox(width: 16),
                  _buildCard11(),
                  const SizedBox(width: 16),
                  _buildCard12(),
                  const SizedBox(width: 16),
                  _buildCard13(),
                  const SizedBox(width: 16),
                  _buildCard14(),
                  const SizedBox(width: 16),
                  _buildCard15(),
                  const SizedBox(width: 16),
                  _buildCard16(),
                  const SizedBox(width: 16),
                  _buildCard17(),
                  const SizedBox(width: 16),
                  _buildCard18(),
                ],
              );
            },
          ),
        ),
      ],
    );
  }


  // بطاقة محطة من قاعدة البيانات (نفس تصميم بطاقات المحطات)
  Widget _buildStationCard(Station s, int index) {
    final chips = s.highlightServices;
    final first = index == 0;
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  s.image ?? 'assets/images/image66.png',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(height: 128, color: const Color(0xFFEAE7E7), child: const Center(child: Icon(Icons.storefront, color: Color(0xFF707975), size: 36))),
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: Text(s.locationPill, style: const TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: Row(
                    children: [
                      const Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      const SizedBox(width: 4),
                      Text(s.isPending ? 'قيد المراجعة' : '${s.vacantSpots} موقف شاغر', style: const TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(s.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        const Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        const SizedBox(width: 2),
                        Text(s.rating == 0 ? 'جديدة' : s.rating.toStringAsFixed(1), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                Text(s.area, style: const TextStyle(fontSize: 12, color: Color(0xFF404945)), maxLines: 1, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text(s.vacancyLabel, style: TextStyle(fontSize: 11, color: s.barColor, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(value: s.occupancy / 100, color: s.barColor, backgroundColor: const Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (var c = 0; c < chips.length; c++) ...[
                        if (c > 0) const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(serviceIcon(chips[c]), size: 14, color: s.barColor),
                              const SizedBox(width: 4),
                              Text(chips[c], style: const TextStyle(fontSize: 11)),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: first ? const Color.fromARGB(255, 35, 74, 63) : const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => _openStation(s),
                    icon: Text('عرض تفاصيل المحطة', style: TextStyle(color: first ? const Color(0xFFF6F3F3) : Colors.black, fontSize: 15)),
                    label: Icon(Icons.arrow_back, size: 16, color: first ? const Color(0xFFF6F3F3) : Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => _bookStation(s),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

// المحطة 1
  Widget _buildCard1() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/image66.png',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة • 40 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('12 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة جبل الكعبة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.2', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق مكة السريع', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 35% (مريح)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.35, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                
                Row(
                mainAxisAlignment: MainAxisAlignment.start, // يمكنك جعلها start لتبدأ من اليمين أو كما تفضلين
                children: [
                  // الميزة الأولى: مصلى واسع
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF6F3F2),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.mosque, size: 13, color: Color.fromRGBO(14, 68, 54, 1)),
                        const SizedBox(width: 4),
                        const Text('مصلى واسع', style: TextStyle(fontSize: 11)),
                      ],
                    ),
                  ),
                  
                  const SizedBox(width: 8), // مسافة بسيطة بين الميزتين

                  // الميزة الثانية: محطة وقود (أو ميزة أخرى)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF6F3F2),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.local_gas_station, size: 13, color: Color.fromRGBO(14, 68, 54, 1)),
                        const SizedBox(width: 4),
                        const Text('محطة وقود', style: TextStyle(fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),

              // 2. مسافة واضحة بين شريط الخدمات وزر "عرض تفاصيل المحطة"
              const SizedBox(height: 12), 





                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 35, 74, 63),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Color(0xFFF6F3F3), fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Color(0xFFF6F3F3)),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر في الأسفل بعرض البططة بالكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // المحطة 2
    Widget _buildCard2() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/image22.png',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text(' مكة • 25 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('18 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة كدي المركزية', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.0', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('محيط المسجد الحرام', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 50% (متاح)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.50, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    // العنصر الأول: إسعاف أولي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.medical_services, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('إسعاف أولي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 8), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: صيدلية (يمكنك تغيير الأيقونة والنص بحسب رغبتك)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_pharmacy, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('صيدلية', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر في الأسفل بعرض البطاقة بالكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // المحطة 3
    Widget _buildCard3() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/image.png',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('جدة •جدة التاريخية', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('15 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة النقل الجماعي سابكو', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('3.5', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق الحرمين السريع - شمال جدة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 58% (معتدل)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.58, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    // العنصر الأول: مطاعم
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.restaurant, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('مطاعم', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة

                    // العنصر الثاني: مقهى (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.coffee, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('مقهى', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بسيطة

                    // العنصر الثالث: دورات مياه (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.wc, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('دورات مياه', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // Butoonii agarsiisa bal'ina buufataa (Olitti)
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // Butoonii hajii keelloo (Jalaan)
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // المحطة 4
    Widget _buildCard4() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/نسخة من Image 3.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('جدة • 18 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('22 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة حافلات جده', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.1', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('حي الخالديه - جدة ', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 75% (رحابة عالية)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.25, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    // العنصر الأول: مصلى كبير
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.mosque, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مصلى كبير', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 8), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: صراف آلي (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.atm, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('صراف آلي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                
                // Butoonii agarsiisa bal'ina buufataa (Olitti)
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // Butoonii hajii keelloo (Jalaan)
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // المحطة 5
    Widget _buildCard5() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 3.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('المدينه المنورة •  22 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('26 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة قطار الحرمين السريع', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.7', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق الملك عبد العزيز', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 80% (استثنائي)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.2, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: مركز صحي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.medical_services, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مركز صحي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 8), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: صيدلية (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_pharmacy, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('صيدلية', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // المحطة 6
    Widget _buildCard6() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 5.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('المدينة المنوره •  15 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('14 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة حافلات المدينه', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.9', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('مطار الامير محمد بن عبدالعزيز الدولي', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 45% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.45, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: نقل ترددي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.airport_shuttle, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('نقل ترددي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة

                    // العنصر الثاني: مواقف حافلات (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.directions_bus, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('مواقف حافلات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بسيطة

                    // العنصر الثالث: استراحة ركاب (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.airline_seat_recline_normal, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('استراحة ركاب', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

// المحطة 7
Widget _buildCard7() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4789.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكه • 25 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('18 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة اجياد المصافي', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.5', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق مكه', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 45% (معتدل)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.45, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                    Row(
                  children: [
                    // العنصر الأول: مواقف
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_parking, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مواقف', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: واي فاي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.wifi, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('واي فاي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 8
Widget _buildCard8() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4783.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكه •  20 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('33موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة جرول', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.2', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('شارع جبل الكعبة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 55% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.55, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_parking, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('مواقف سيارات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 9
Widget _buildCard9() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4784.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  19 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('16 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة الحرم', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.6', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('بالقرب من مكتبة مكة المكرمه', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 33% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.33, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    // العنصر الأول: تموينات
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.store, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('تموينات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثاني: شحن كهربائي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.ev_station, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('شحن كهربائي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثالث: منطقة ألعاب (بدل الاستحمام)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.child_care, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('منطقة ألعاب', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 10
Widget _buildCard10() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4786.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  54 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('11 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة ابراهيم الخليل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.3', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('شارع المنصور', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 37% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.37, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: صيانة سيارات
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.build, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('صيانة سيارات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: جلسات خارجية
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.deck, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('جلسات خارجية', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 11
Widget _buildCard11() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4787.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  67 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('34 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة شعب عامر', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.3', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('مكة شعب عامر و شعب علي', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 70% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.70, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: فندق / موتيل
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.hotel, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('فندق', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: غسيل سيارات
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_car_wash, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('غسيل حافلات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 12
Widget _buildCard12() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  42 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('21 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة المروة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.4', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('شعب عامر و شعب علي مكة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 32% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xE60E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.32, color: Color(0xE60E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    // العنصر الأول: مطاعم
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.restaurant, size: 14, color: Color(0xE60E4436)),
                          SizedBox(width: 4),
                          Text('مطاعم', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: صراف آلي (من اختيارنا)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.atm, size: 14, color: Color(0xE60E4436)),
                          SizedBox(width: 4),
                          Text('صراف آلي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 13
Widget _buildCard13() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4785.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  74 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('32 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة ريع بخش', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('3.9', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('الهجلة ـ مكة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 44% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xE60E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.44, color: Color(0xE60E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: مركز معلومات
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.info_outline, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مركز معلومات', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثاني: منطقة تسوق
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.shopping_bag_outlined, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('تسوق', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثالث: حفظ الأمتعة
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.luggage, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('حفظ الأمتعة', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 14
Widget _buildCard14() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 2.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('جدة •  35 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('12 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة قطار الحرمين', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.7', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('السليمانية ، جدة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 23% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.23, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: محطة وقود
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_gas_station, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('محطة وقود', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثاني: متاجر (البديل الجديد)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.shopping_cart, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('متاجر', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثالث: نقطة طوارئ
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.eject, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('نقطة طوارئ', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 15
Widget _buildCard15() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 6.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('المدينة المنوره •  17 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('41 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة حافلات المدينه (المطار)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.5', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('المدينة طريق المطار', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 22% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.22, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: مصلى واسع
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.mosque, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مصلى واسع', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العناصر

                    // العنصر الثاني: مطاعم
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.restaurant, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مطاعم', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

// المحطة 16
Widget _buildCard16() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/IMG_4782.JPG',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  18 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('12 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة مواقف الهدا', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.6', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('خالد بن الوليد ، جرول، مكة', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 91% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF765A00), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.91, color: Color(0xFF765A00), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.support_agent, size: 14, color: Color(0xFF765A00)),
                          SizedBox(width: 4),
                          Text('خدمة العملاء', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 17
Widget _buildCard17() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 7.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  70 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('10 موقف شاغر', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة النقل الجماعي سابتكو', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('3.8', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق مكة، التنعيم', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 10% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.10, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: دورات مياه
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.wc, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('دورات مياه', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بسيطة بين العنصرين

                    // العنصر الثاني: مقاهي
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.local_cafe, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('مقاهي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


// المحطة 18
Widget _buildCard18() {
    return Container(
      width: 285,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Image.asset(
                  'assets/images/Image 4.jpeg',
                  height: 128,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE6FFFFFF), borderRadius: BorderRadius.circular(12)),
                  child: const Text('مكة •  10 كم', style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
              Positioned(
                bottom: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xE60E4436), borderRadius: BorderRadius.circular(6)),
                  child: const Row(
                    children: [
                      Icon(Icons.directions_bus, color: Colors.white, size: 14),
                      SizedBox(width: 4),
                      Text('11', style: TextStyle(color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('محطة حافلات مكة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                    Row(
                      children: [
                        Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                        SizedBox(width: 2),
                        Text('4.9', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const Text('طريق مزدلفة الفرعي', style: TextStyle(fontSize: 12, color: Color(0xFF404945))),
                const SizedBox(height: 8),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإشغال الحالية', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('شاغر 48% (نشط)', style: TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: const LinearProgressIndicator(value: 0.48, color: Color(0xFF0E4436), backgroundColor: Color(0xFFEAE7E7), minHeight: 8),
                ),
                const SizedBox(height: 10),
                                Row(
                  children: [
                    // العنصر الأول: نقل ترددي (الأصلي)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.airport_shuttle, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('نقل ترددي', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 6), // مسافة بين العناصر

                    // العنصر الثاني: عيادة طبية
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.medical_services, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('عيادة طبية', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),

                    const SizedBox(width: 6), // مسافة بين العناصر

                    // العنصر الثالث: كبار السن وذوي الهمم
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.accessible, size: 14, color: Color(0xFF0E4436)),
                          SizedBox(width: 4),
                          Text('تسهيلات حركة', style: TextStyle(fontSize: 11)),
                        ],
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 12),
                
                // زر عرض تفاصيل المحطة في الأعلى
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFEAE7E7),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: onNavigateToDetails,
                    icon: const Text('عرض تفاصيل المحطة', style: TextStyle(color: Colors.black, fontSize: 15)),
                    label: const Icon(Icons.arrow_back, size: 16, color: Colors.black),
                  ),
                ),
                const SizedBox(height: 6),
                
                // زر الحجز الأصفر بالأسفل بعرض البطاقة الكامل
                SizedBox(
                  width: double.infinity,
                  height: 38,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFECE50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 0,
                    ),
                    onPressed: () => onShowToast("جاري الانتقال لصفحة الحجز..."),
                    child: const Text(
                      'حجز',
                      style: TextStyle(color: Color(0xFF1B1C1C), fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }



  Widget _buildServiceChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF1B1C1C))),
    );
  }

      // دالة لإنشاء زر الانتقال لصفحة إضافة محطة
  Widget _buildAddStationBar(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // الانتقال لصفحة إضافة المحطة مع تمرير المعاملات المطلوبة
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AddStationScreen(
              onShowToast: (message) {
                // دالة لعرض رسالة التنبيه (Toast)
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(message)),
                );
              },
              onNavigateBack: () {
                // دالة للرجوع للصفحة السابقة
                Navigator.pop(context);
              },
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF0EDED),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0x4DC0C9C3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    color: Color(0x1A0E4436),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.add_business_rounded, color: Color(0xFF0E4436), size: 22),
                ),
                const SizedBox(width: 8),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('إضافة محطة جديدة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                    Text('انقر هنا للانتقال لصفحة تسجيل محطة جديدة', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                  ],
                ),
              ],
            ),
            const Icon(
              Icons.arrow_forward_ios,
              size: 16,
              color: Color(0xFF0E4436),
            ),
          ],
        ),
      ),
    );
  }
}





// ==================== صفحة تفاصيل المحطة ====================
class StationDetailsScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateBack;
  final VoidCallback onNavigateToBookings;
  
  
  final dynamic stationData;
  
  
  // أضفنا هذه المتغيرات لتستقبل بيانات المحطة المحددة
  final String stationName;
  final String stationLocation;
  final String imageUrl;
  final String rating;
  final String reviewAuthor;
  final String reviewText;

  const StationDetailsScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateBack,
    required this.onNavigateToBookings,
    this.stationData,
    this.stationName = 'محطة قطار الحرمين', // قيم افتراضية
    this.stationLocation = 'طريق مكة السريع • كم 40 باتجاه مكة',
    this.imageUrl = 'https://lh3.googleusercontent.com/aida-public/AB6AXuAYMnUYE3Md1PLAkeE077etRdhbDMrjTKGIjI_jdBaU7Z7iAU_7IRkfzzvUzpCXEUEKxB0ow8IB6O9cPV5fiVRK-gOspXhO8trzuR0wdDhQECJ4Kx_xvSap9USDTrx0ahpLBR7XI1Zm2_qxwPkrW5YeMYED46Cbwi06ZVGJL7AvRTDvj6Ioi1GT6LfyRX780_clbgWqEFxK00DnLqWf-fO9jknlK_8FHiMmNfx6EQ7HLlPkqUAsmjGkTA',
    this.rating = '4.8',
    this.reviewAuthor = 'عبدالله القرشي',
    this.reviewText = 'نظافة المصليات ودورات المياه مبهرة للغاية، ووجود عمال تنظيم المواقف اختصر علينا أكثر من نصف ساعة أثناء النزول وتوزيع وجبات الحجاج.',
  });

  @override
  State<StationDetailsScreen> createState() => _StationDetailsScreenState();
  
}

class _StationDetailsScreenState extends State<StationDetailsScreen> {
  
  
  
  bool isBookmarked = false;

  // ---------- بيانات المحطة من قاعدة البيانات ----------
  Station? _st;
  List<Map<String, dynamic>> _reviews = [];
  List<Map<String, dynamic>> _types = [];

  @override
  void initState() {
    super.initState();
    final d = widget.stationData;
    _st = d is Station ? d : (d is Map ? Station(Map<String, dynamic>.from(d)) : selectedStation);
    _loadDetails();
  }

  Future<void> _loadDetails() async {
    try {
      if (_st == null) {
        final list = await ApiService.fetchStations();
        if (list.isNotEmpty) _st = Station(list.first);
      }
      if (_st == null) return;
      final d = await ApiService.fetchStationDetails(_st!.id);
      _st = Station({..._st!.raw, ...asMap(d['station'])});
      _reviews = asList(d['reviews']);
      _types = asList(d['booking_types']);
    } catch (_) {}
    if (mounted) setState(() {});
  }

  String get _name => _st?.title ?? widget.stationName;
  String get _locationLine => _st == null
      ? widget.stationLocation
      : '${_st!.highway.isNotEmpty ? _st!.highway : _st!.area} • ${_st!.city}';
  String get _ratingText => _st == null ? widget.rating : (_st!.rating == 0 ? '—' : _st!.rating.toStringAsFixed(1));
  String get _qualityClass {
    final r = _st?.rating ?? 4.8;
    if (r >= 4.5) return 'فئة أ (ممتاز)';
    if (r >= 4.0) return 'فئة ب (جيد جداً)';
    if (r > 0) return 'فئة ج (جيد)';
    return 'جديدة (بدون تقييم)';
  }

  void _goBook() {
    if (!Session.canBook && Session.user != null) {
      widget.onShowToast('الحجز متاح لأصحاب الحملات وضيوف الرحمن');
      return;
    }
    if (_st != null) {
      if (_st!.isPending) {
        widget.onShowToast('هذه المحطة قيد مراجعة الإدارة ولا تستقبل حجوزات بعد');
        return;
      }
      if (_types.isEmpty) {
        widget.onShowToast('لا تتوفر في هذه المحطة خدمات قابلة للحجز المسبق');
        return;
      }
      bookingTargetStation = _st;
    }
    widget.onShowToast("جاري الانتقال لصفحة إدارة حجوزاتك...");
    widget.onNavigateToBookings();
  }

  void _toggleBookmark() {
    setState(() {
      isBookmarked = !isBookmarked;
    });
    widget.onShowToast(
      isBookmarked
          ? 'تم حفظ المحطة في قائمة محطاتك المفضلة'
          : 'تمت إزالة المحطة من المفضلة',
    );
  }

  void _showNavigationModal() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.white,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'اختر تطبيق الملاحة',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0E4436)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'سيتم إرسال إحداثيات مدخل الحافلات المخصص للمحطة إلى التطبيق المفضل لديك:',
                style: TextStyle(fontSize: 14, color: Color(0xFF404945)),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        widget.onShowToast('جاري فتح المسار المخصص عبر خرائط Google...');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF6F3F2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Column(
                          children: [
                            Icon(Icons.map, color: Color(0xFF0E4436), size: 28),
                            SizedBox(height: 8),
                            Text('خرائط Google', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        widget.onShowToast('جاري فتح المسار المخصص عبر تطبيق Waze...');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF6F3F2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Column(
                          children: [
                            Icon(Icons.navigation, color: Color(0xFF765A00), size: 28),
                            SizedBox(height: 8),
                            Text('تطبيق Waze', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xD9FCF9F8),
        elevation: 0.5,
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward, color: Color(0xFF1B1C1C)),
          onPressed: widget.onNavigateBack,
        ),
        title: const Text(
          'تفاصيل المحطة والاستراحة',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Color(0xFF0E4436),
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(left: 16.0),
            child: CircleAvatar(
              radius: 16,
              backgroundImage: NetworkImage(
                'https://lh3.googleusercontent.com/aida/AEtjO1XnqM0nV_90wtxn8gBzctsKEAKfKnVVrcZjey1WAAZs6SBedREwp9dU2TrBuCxKTmnkMSOiVxyGA4F5qBIHmVM7kgfQJbBycTjD45V9d7UjAB1OlsxnaWqyW3DEhL1Pud-TkVTsPXEtkzQ9y9owqJnqmhGG2nYuFNN5RijD2y0q3Pypq-FQwX8_qLikqHAIICccM5f8G0VVkCxKhfO0Y2sohOJgD5RgCvydl_HCPeAoAOHQvr4V3Xsk8RIZ6AdJKjPc0qdDUwY6RQ',
              ),
              backgroundColor: Color(0x330E4436),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadDetails,
        child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            
            _buildHeaderBanner(),
            const SizedBox(height: 16),
            _buildPrimaryInfoCard(),
            const SizedBox(height: 16),
            _buildLiveCapacityCard(),
            const SizedBox(height: 16),
            _buildFacilitiesSection(),
            const SizedBox(height: 16),
            _buildLocationMapCard(),
            const SizedBox(height: 16),
            _buildReviewsSection(),
            const SizedBox(height: 80),
          ],
        ),
      ),
      ),
      bottomSheet: Container(
        color: const Color(0xEFFCF9F8),
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0E4436),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _goBook,
                  icon: const Icon(Icons.how_to_reg, color: Colors.white),
                  label: const Text(
                    'حجز رصيف وخدمات المحطة',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            InkWell(
              onTap: () => widget.onShowToast('تم إرسال إحداثيات الموقع والحالة الحالية لغرفة العمليات المركزية'),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFF0EDED)),
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.satellite_alt, color: Color(0xFF0E4436), size: 20),
                    Text('العمليات', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderBanner() {
    final images = [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDuF8qytKj8e9YCW0fX5ji3XqkS4K5rOTkeFeiXApN72vXD-VpIZJX5vYzaeR_WIMen37V83RYKkt1iS-SYi8GaxEEaa0j7KO5YrjnISol3SHu3068glpED_05fVwJHyJkG7Gp6cuz26iF609PyYtMpn8aX81YUUX8syKLif39vaAZY5QXn_SP0gmc3eTeL7IqW-fLc7Imj1jKRfFOrNHYoklgAAQ4u8qHwj1UZVOfrzG2JrVrLUXW6xw',
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDqYbQjoGGOMtMbHh4mjY3X0VJlP6WTFki3y_rc_rA18-drpMuRWdImVTq3Jysa5kqjlZYuo2H6SzVh_f9AalzgmWjkKONzl3Idzivzt2yknsranvZA8yW74b-YY_b-I6gTKSIETxuPkFpIQoOZGnNv2Vg4IXfRCrxfCiNFDJuVKJCNknIVIMqYN3OHymTAlvACUPWPDeocI22DRfau2wchbzQXTAxCkk8rXyMlkCD_xkNiYJXV9DcJjQ',
      'https://lh3.googleusercontent.com/aida-public/AB6AXuCkmkM5QFwa-N2mfevNHtNfXWtzGn7l7X28m4sIyz4kIm7tJkHFKDSOjnjm0_DW3n3g9b4c_VwiTjpKdmflczZWsCyHu2Nu_ufe7b3_p6HqaUBumnoHHITGsd6nJmOPx4s8uR6FijLeTXI45rQyrbRlhq3bpGJzwnJ3jJTAmr_kSGV9GURSM9c3d4k0Zw5hD56ImJQb8Rp0idlIw1BPGRpoWRJLm5t_j51ZjJbd0ufC2FMkoq_jqrOfRA',
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDtcGPzp9KAEnro8hrU5GgGQG4XAy1ArFT5nFLHhG8C9naYgAjXv73RUY7-l5shlqOU8FnFV2t_4Hqq_5Eu7OJeFUUg-FirerDjQAambVNsQASyW4mpBpF-tFGX5-85uGwBJ9b6LkkMfRgyRZYX6u5Aqus3JB-xmbHjacNeh2lqCxB0MmlIAcq5Jta5Uu0Zc91Pbxee0vNKQ_S3w51IfSYUyodlJM0qsNHKlaOYQPinpzb9Yb03pg0thQ'
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                height: 220,
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: (_st?.image != null && _st!.image!.isNotEmpty)
                        ? AssetImage(_st!.image!) as ImageProvider
                        : const NetworkImage(
                      'https://lh3.googleusercontent.com/aida-public/AB6AXuAYMnUYE3Md1PLAkeE077etRdhbDMrjTKGIjI_jdBaU7Z7iAU_7IRkfzzvUzpCXEUEKxB0ow8IB6O9cPV5fiVRK-gOspXhO8trzuR0wdDhQECJ4Kx_xvSap9USDTrx0ahpLBR7XI1Zm2_qxwPkrW5YeMYED46Cbwi06ZVGJL7AvRTDvj6Ioi1GT6LfyRX780_clbgWqEFxK00DnLqWf-fO9jknlK_8FHiMmNfx6EQ7HLlPkqUAsmjGkTA',
                    ),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                height: 220,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.3),
                      const Color(0xFF0E4436).withOpacity(0.85),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const CircleAvatar(radius: 3, backgroundColor: Colors.green),
                      const SizedBox(width: 6),
                      Text(_st?.openLabel ?? 'مفتوح على مدار الساعة', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 12,
                left: 12,
                child: InkWell(
                  onTap: _toggleBookmark,
                  child: CircleAvatar(
                    backgroundColor: Colors.white.withOpacity(0.8),
                    child: Icon(
                      isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                      color: const Color(0xFF0E4436),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 12,
                right: 16,
                left: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.pin_drop, color: Color(0xFFFFDF96), size: 16),
                        SizedBox(width: 4),
                        Flexible(child: Text(_locationLine, style: const TextStyle(color: Colors.white70, fontSize: 12), overflow: TextOverflow.ellipsis)),
                      ],
                    ),
                    SizedBox(height: 4),
                    Text(
                    _name,
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  ],
                ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.white,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ...images.map((url) => Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(url, width: 64, height: 48, fit: BoxFit.cover),
                    ),
                  )),
                  InkWell(
                    onTap: () => widget.onShowToast("تم فتح معرض صور المحطة (10 صور)"),
                    child: Container(
                      width: 64,
                      height: 48,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF6F3F2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Center(
                        child: Text('+6 صور', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrimaryInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_st?.isPending == true ? 'طلب انضمام قيد مراجعة الإدارة' : 'محطة معتمدة من وزارة الحج والعمرة', style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
                  const SizedBox(height: 2),
                  Text(_name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                ],
              ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFDF96),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.star, color: Color(0xFF765A00), size: 16),
                    const SizedBox(width: 2),
                    Text(_ratingText, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Color(0xFF251A00))),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _buildMetricItem(Icons.local_parking, _st == null ? '18 موقف متاح' : '${_st!.vacantSpots} موقف متاح', _st == null ? 'لحافلات الـ 50 راكب' : 'من أصل ${_st!.capacity} موقف')),
              const SizedBox(width: 8),
              Expanded(child: _buildMetricItem(Icons.event_available, _st == null ? '12 دقيقة' : '${_st!.activeBookings} حجز', _st == null ? 'متوسط سرعة الإنجاز' : 'مؤكد قادم')),
              const SizedBox(width: 8),
              Expanded(child: _buildMetricItem(Icons.verified_user, _qualityClass, _st == null ? 'تصنيف الجودة' : 'تصنيف الجودة (${_st!.reviewsCount} تقييم)')),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0E4436),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: _showNavigationModal,
                  icon: const Icon(Icons.explore, color: Colors.white, size: 18),
                  label: const Text('بدء الملاحة الآن', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFECE50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: _goBook,
                  icon: const Icon(Icons.how_to_reg, color: Color(0xFF735800), size: 18),
                  label: const Text('حجز موعد فوري', style: TextStyle(color: Color(0xFF735800), fontWeight: FontWeight.bold, fontSize: 13)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricItem(IconData icon, String title, String sub) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F3F2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFF0E4436), size: 20),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          Text(sub, style: const TextStyle(fontSize: 9, color: Color(0xFF404945)), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildLiveCapacityCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.traffic, color: Color(0xFF0E4436), size: 20),
                  SizedBox(width: 8),
                  Text('مؤشر الاستيعاب الميداني الحي', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFB9EEDA), borderRadius: BorderRadius.circular(12)),
                child: Text(_st == null ? '45% شاغر' : '${(100 - _st!.occupancy).round()}% شاغر', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1C4F41))),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: _st == null ? 0.55 : _st!.occupancy / 100,
              minHeight: 10,
              backgroundColor: const Color(0xFFEAE7E7),
              color: const Color(0xFF0E4436),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_st == null ? 'مشغول: 22 حافلة' : 'مشغول: ${_st!.occupiedSpots} حافلة', style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
              Text(_st == null ? 'الهدوء المتوقع: بعد 35 دقيقة' : 'الحالة: ${_st!.crowdLabel}', style: const TextStyle(fontSize: 11, color: Color(0xFF765A00))),
              Text(_st == null ? 'سعة إجمالية 40 حافلة' : 'سعة إجمالية ${_st!.capacity} حافلة', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFacilitiesSection() {
    final facilities = [
      {'title': 'مصلى رجال ونساء (500 مصلٍ)', 'sub': 'مكيف مركزياً • سجاد فاخر • ممر كبار السن', 'tag': 'متاح', 'icon': Icons.mosque},
      {'title': '40 دورة مياه نموذجية', 'sub': 'مجهزة لذوي الاحتياجات الخاصة • تعقيم مستمر', 'tag': 'متاح', 'icon': Icons.wc},
      {'title': 'ردهة مطاعم وكافيهات سريعة', 'sub': 'وجبات ساخنة مغلفة ومياه مبردة ومشروبات', 'tag': 'خدمة فورية', 'icon': Icons.restaurant},
      {'title': 'نقطة طبية إسعافية متقدمة', 'sub': 'كادر طبي قياس ضغط وسكر وأدوية إجهاد حراري', 'tag': 'طوارئ 24س', 'icon': Icons.medical_services},
    ];
    if (_st != null && _st!.services.isNotEmpty) {
      facilities
        ..clear()
        ..addAll(_st!.services.map((name) => {
              'title': name,
              'sub': serviceDescription(name),
              'tag': _types.any((t) => serviceIcon(toStr(t['name'])) == serviceIcon(name)) ? 'قابل للحجز' : 'متاح',
              'icon': serviceIcon(name),
            }));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('المرافق والخدمات المتوفرة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
        const SizedBox(height: 8),
        ...facilities.map((fac) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFF0EDED)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
                child: Icon(fac['icon'] as IconData, color: const Color(0xFF0E4436), size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(fac['title'] as String, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                    Text(fac['sub'] as String, style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFB9EEDA), borderRadius: BorderRadius.circular(8)),
                child: Text(fac['tag'] as String, style: const TextStyle(fontSize: 10, color: Color(0xFF1C4F41), fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _buildLocationMapCard() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('الموقع الجغرافي للمحطة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
        const SizedBox(height: 8),
        Container(
          height: 180,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            image: const DecorationImage(
              image: AssetImage('/Users/rolly/Downloads/Zz.jpeg'),
              fit: BoxFit.cover,
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                bottom: 12,
                left: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.95), borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_st == null ? 'مخرج محطة جبل الكعبه رقم 14' : 'مدخل ${_st!.title}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
                          Text(_st?.lat != null && _st?.lng != null ? '${_st!.lat!.toStringAsFixed(4)}° N, ${_st!.lng!.toStringAsFixed(4)}° E' : 'منفذ واسع مهيأ لدخول قوافل الحافلات', style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
                        ],
                      ),
                      ),
                      TextButton(
                        onPressed: _showNavigationModal,
                        child: const Text('عرض المسار', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReviewsSection() {
    final items = _reviews.isNotEmpty
        ? _reviews
        : [
            {'reviewer_name': widget.reviewAuthor, 'rating': 5, 'comment_text': widget.reviewText, 'sub': 'مشرف فوج - شركة وفادة المشاعر'}
          ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('آراء المشرفين والسائقين', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
              TextButton(
                onPressed: () {
                  _loadDetails();
                  widget.onShowToast(_st == null ? "تم تحديث أحدث تقييمات قادة الحافلات" : "عدد التقييمات: ${_st!.reviewsCount} • المتوسط ${_ratingText}");
                },
                child: const Text('عرض الكل', style: TextStyle(fontSize: 12, color: Color(0xFF765A00))),
              ),
            ],
          ),
          const SizedBox(height: 8),
          for (var i = 0; i < items.length; i++) ...[
            if (i > 0) const Divider(height: 24),
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFFB9EEDA),
                  child: Text(nameInitials(toStr(items[i]['reviewer_name'], 'ضيف')), style: const TextStyle(color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        toStr(items[i]['reviewer_name'], 'ضيف راحة'),
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        toStr(items[i]['sub'], relativeTime(toDate(items[i]['created_at']))),
                        style: const TextStyle(fontSize: 10, color: Color(0xFF404945)),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: List.generate(
                    5,
                    (index) => Icon(index < toInt(items[i]['rating'], 5) ? Icons.star : Icons.star_border, color: const Color(0xFFFECE50), size: 16),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              toStr(items[i]['comment_text']),
              style: const TextStyle(fontSize: 12, color: Color(0xFF1B1C1C), height: 1.4),
            ),
          ],
        ],
      ),
    );
  }
}

// ==================== صفحة حجوزاتي  ====================
class MyBookingsScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateToDetails;

  const MyBookingsScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateToDetails,
  });

  @override
  State<MyBookingsScreen> createState() => _MyBookingsScreenState();
}

class _MyBookingsScreenState extends State<MyBookingsScreen> {
  int _selectedTab = 0; // 0: النشطة والقادمة, 1: السابقة والمكتملة
  
  // ---------- بيانات قاعدة البيانات ----------
  List<Station> _stations = [];
  List<Map<String, dynamic>> _bookings = [];
  Station? _stA;
  Station? _stB;
  List<Map<String, dynamic>> _types = [];
  DateTime _date = DateTime.now();
  TimeOfDay _time = TimeOfDay.fromDateTime(DateTime.now().add(const Duration(hours: 1)));
  Map<String, dynamic>? _lastResult;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _loadRealBookings();
  }

  Future<void> _loadRealBookings() async {
    try {
      final list = await ApiService.fetchStations();
      _stations = list.map(Station.new).where((s) => !s.isPending && s.vacantSpots > 0).toList();
    } catch (_) {}
    // المحطة القادمة من زر "حجز" تكون الخيار الأول، والبديل الأقل ازدحاماً
    final target = bookingTargetStation;
    bookingTargetStation = null;
    final sorted = [..._stations]..sort((a, b) => a.occupancy.compareTo(b.occupancy));
    _stA = target ?? (sorted.isNotEmpty ? sorted.first : null);
    final others = sorted.where((s) => s.id != _stA?.id).toList();
    _stB = others.isNotEmpty ? others.first : null;
    final uid = Session.userId;
    if (uid != null) {
      try {
        _bookings = await ApiService.fetchBookings(userId: uid);
      } catch (_) {}
    }
    await _loadTypes();
    if (mounted) setState(() {});
  }

  Station? get _chosen => _selectedStation == 'wahah2' ? _stB : _stA;

  Future<void> _loadTypes() async {
    final s = _chosen;
    _types = [];
    if (s == null) return;
    try {
      final d = await ApiService.fetchStationDetails(s.id);
      _types = asList(d['booking_types']);
    } catch (_) {}
    _clampCounts();
    if (mounted) setState(() {});
  }

  /// نوع الحجز: موقف الحافلة إن وُجد في المحطة
  Map<String, dynamic>? get _type {
    if (_types.isEmpty) return null;
    final parking = _types.where((t) => toStr(t['name']).contains('موقف')).toList();
    return parking.isNotEmpty ? parking.first : _types.first;
  }

  int get _maxBus => _chosen == null ? 99 : (_chosen!.vacantSpots > 0 ? _chosen!.vacantSpots : 1);
  double get _total => toDouble(_type?['price']) * _busCount;

  void _clampCounts() {
    if (_busCount > _maxBus) _busCount = _maxBus;
    if (_busCount < 1) _busCount = 1;
    if (_pilgrimCount > _busCount * 49) _pilgrimCount = _busCount * 49;
  }

  bool _isActive(Map<String, dynamic> b) {
    final st = toStr(b['status']);
    final d = toDate(b['booking_date']);
    return (st == 'confirmed' || st == 'pending') && d != null && !dateOnly(d).isBefore(dateOnly(DateTime.now()));
  }

  List<Map<String, dynamic>> get _active =>
      _bookings.where(_isActive).toList()..sort((a, b) => toDate(a['booking_date'])!.compareTo(toDate(b['booking_date'])!));
  List<Map<String, dynamic>> get _past => _bookings.where((b) => !_isActive(b)).toList();

  String _bkName(Map<String, dynamic> b) => toStr(b['app_title'], toStr(b['station_name'], 'محطة'));

  Future<void> _confirmBooking() async {
    if (Session.user == null) {
      widget.onShowToast('سجّل الدخول أولاً لإتمام الحجز');
      return;
    }
    final s = _chosen;
    final t = _type;
    if (s == null || t == null) {
      widget.onShowToast('لا تتوفر في هذه المحطة خدمات قابلة للحجز — اختر محطة أخرى');
      return;
    }
    final when = DateTime(_date.year, _date.month, _date.day, _time.hour, _time.minute);
    if (when.isBefore(DateTime.now())) {
      widget.onShowToast('وقت الوصول المختار مضى — اختر وقتاً لاحقاً');
      return;
    }
    setState(() => _submitting = true);
    try {
      final res = await ApiService.addBooking(
        restStopId: s.id,
        bookingTypeId: toInt(t['booking_type_id']),
        date: _date,
        arrivalTime: hhmm(_time),
        busCount: _busCount,
        peopleCount: _pilgrimCount,
        notes: 'مدة التوقف $_stopDuration دقيقة • $_busCount حافلة • $_pilgrimCount معتمر',
      );
      _lastResult = res;
      _isConfirmed = true;
      widget.onShowToast("تم تأكيد الحجز #${toStr(res['booking_code'])} وإصدار تصريح التوقف الذكي ورقم الرصيف بنجاح!");
      await _loadRealBookings();
    } catch (e) {
      widget.onShowToast(e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Future<void> _cancelBooking(Map<String, dynamic> b) async {
    try {
      await ApiService.cancelBooking(toInt(b['booking_id']));
      widget.onShowToast("تم إلغاء الحجز #${toStr(b['booking_code'])} وبث الشاغر على الشبكة");
      _loadRealBookings();
    } catch (e) {
      widget.onShowToast(e.toString());
    }
  }


  // متعدلات الحالة الخاصة بالحجز التفاعلي من الملف
  int _busCount = 1;
  int _pilgrimCount = 49;
  String _selectedStation = 'shumaisi';
  String _stopDuration = '60';
  bool _isConfirmed = false;







  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCF9F8),
      appBar: AppBar(
        backgroundColor: const Color(0xD9FCF9F8),
        elevation: 0.5,
        titleSpacing: 16,
        title: const Row(
          children: [
            Icon(Icons.book_online, color: Color(0xFF0E4436), size: 22),
            SizedBox(width: 8),
            Text(
              'حجز الاستراحة والرصيف',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0E4436),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_task, color: Color(0xFF0E4436)),
            onPressed: () {
              widget.onShowToast("حجز سريع لرحلة جديدة...");
              setState(() {
                _selectedTab = 0;
                _isConfirmed = false;
                _lastResult = null;
              });
              _loadRealBookings();
            },
            tooltip: 'حجز جديد',
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            _buildFilterTabs(),
            const SizedBox(height: 16),
            if (_selectedTab == 0) ...[
              _buildStepperIndicator(),
              const SizedBox(height: 16),
              _buildRouteAndStationCard(),
              const SizedBox(height: 16),
              _buildFleetAndPilgrimsCard(),
              const SizedBox(height: 16),
              _buildTimeAndDurationCard(),
              const SizedBox(height: 16),
              _buildReservationSummaryCard(),
              const SizedBox(height: 16),
              _buildConfirmationButton(),
              const SizedBox(height: 20),
              if (_active.isNotEmpty) ...[
                _buildActiveTicketCard(),
                const SizedBox(height: 16),
              ],
              if (_active.length > 1) ...[
                _buildUpcomingBookingsHeader(),
                const SizedBox(height: 12),
                for (final b in _active.skip(1)) ...[
                  _buildUpcomingBookingItem(b),
                  const SizedBox(height: 10),
                ],
              ],
            ] else ...[
              _buildCompletedBookingsList(),
            ],
            const SizedBox(height: 20),
            _buildPermitStatusCard(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // أزرار التبديل الأعلى
  Widget _buildFilterTabs() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFEAE7E7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedTab = 0),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedTab == 0 ? const Color(0xFF0E4436) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'النشطة والقادمة (${_active.length})',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: _selectedTab == 0 ? Colors.white : const Color(0xFF404945),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedTab = 1),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedTab == 1 ? const Color(0xFF0E4436) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'المكتملة والسابقة (${_past.length})',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: _selectedTab == 1 ? Colors.white : const Color(0xFF404945),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 1. شريط الخطوات المكتمل
  Widget _buildStepperIndicator() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F3F2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStepItem(Icons.check, 'المسار', isDone: true),
          Container(width: 40, height: 2, color: const Color(0xFF0E4436)),
          _buildStepItem(_isConfirmed ? Icons.check : Icons.schedule, 'التوقيت', isDone: true, isCurrent: !_isConfirmed),
          Container(width: 40, height: 2, color: _isConfirmed ? const Color(0xFF0E4436) : const Color(0xFFC0C9C3)),
          _buildStepItem(Icons.verified, 'الباركود', isDone: _isConfirmed),
        ],
      ),
    );
  }

  Widget _buildStepItem(IconData icon, String label, {bool isDone = false, bool isCurrent = false}) {
    Color bg = isDone ? const Color(0xFF0E4436) : (isCurrent ? const Color(0xFF765A00) : const Color(0xFFEAE7E7));
    Color iconColor = (isDone || isCurrent) ? Colors.white : const Color(0xFF707975);
    return Column(
      children: [
        CircleAvatar(
          radius: 16,
          backgroundColor: bg,
          child: Icon(icon, size: 16, color: iconColor),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.bold,
            color: isDone || isCurrent ? const Color(0xFF0E4436) : const Color(0xFF707975),
          ),
        ),
      ],
    );
  }

  // 2. بطاقة خط السير والمحطة الذكية
  Widget _buildRouteAndStationCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.alt_route, color: Color(0xFF0E4436), size: 20),
                  SizedBox(width: 6),
                  Text('خط السير والمحطة الذكية', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFB9EEDA), borderRadius: BorderRadius.circular(12)),
                child: const Text('محدد مسبقاً', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF1C4F41))),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(Icons.flight_takeoff, size: 16, color: Color(0xFF0E4436)),
                    SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('نقطة الانطلاق', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                        Text('مطار الملك عبد العزيز الدولي (جدة)', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
                const Divider(height: 16),
                Row(
                  children: [
                    const Icon(Icons.mosque, size: 16, color: Color(0xFF765A00)),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('الوجهة المباركة', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                        Text(_chosen == null ? 'مكة المكرمة (محطة قطار الحرمين)' : '${_chosen!.city} (${_chosen!.title})', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text('محطة الاستراحة المستهدفة', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() => _selectedStation = 'shumaisi');
                    _loadTypes();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _selectedStation == 'shumaisi' ? const Color(0xFF0E4436) : const Color(0xFFF0EDED),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _stA?.title ?? 'استراحة A',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _selectedStation == 'shumaisi' ? Colors.white : Colors.black),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _stA == null ? 'بوابة A - مجهزة بالكامل' : '${_stA!.vacantSpots} موقف شاغر • إشغال ${_stA!.occupancy.round()}%',
                          style: TextStyle(fontSize: 10, color: _selectedStation == 'shumaisi' ? Colors.white70 : const Color(0xFF404945)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() => _selectedStation = 'wahah2');
                    _loadTypes();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _selectedStation == 'wahah2' ? const Color(0xFF0E4436) : const Color(0xFFF0EDED),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _stB?.title ?? 'استراحة C',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _selectedStation == 'wahah2' ? Colors.white : Colors.black),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _stB == null ? 'بوابة C - ضغط متوسط' : '${_stB!.vacantSpots} موقف شاغر • إشغال ${_stB!.occupancy.round()}%',
                          style: TextStyle(fontSize: 10, color: _selectedStation == 'wahah2' ? Colors.white70 : const Color(0xFF404945)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 3. تفاصيل الفوج والأسطول
  Widget _buildFleetAndPilgrimsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.directions_bus, color: Color(0xFF0E4436), size: 20),
              SizedBox(width: 6),
              Text('تفاصيل الفوج والأسطول', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      const Text('عدد الحافلات (VIP)', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.remove, size: 16),
                            onPressed: () => setState(() {
                              _busCount = _busCount > 1 ? _busCount - 1 : 1;
                              _clampCounts();
                            }),
                          ),
                          Text('$_busCount', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                          IconButton(
                            icon: const Icon(Icons.add, size: 16),
                            onPressed: () {
                              if (_busCount >= _maxBus) {
                                widget.onShowToast('المتاح حالياً $_maxBus موقف فقط في هذه المحطة');
                                return;
                              }
                              setState(() => _busCount++);
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    children: [
                      const Text('إجمالي المعتمرين', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.remove, size: 16),
                            onPressed: () => setState(() => _pilgrimCount = _pilgrimCount > 5 ? _pilgrimCount - 5 : 5),
                          ),
                          Text('$_pilgrimCount', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                          IconButton(
                            icon: const Icon(Icons.add, size: 16),
                            onPressed: () {
                              if (_pilgrimCount + 5 > _busCount * 49) {
                                widget.onShowToast('سعة $_busCount حافلة = ${_busCount * 49} راكب كحد أقصى');
                                return;
                              }
                              setState(() => _pilgrimCount += 5);
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 4. وقت الوصول المقدر والمدة
  Widget _buildTimeAndDurationCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.access_time_filled, color: Color(0xFF0E4436), size: 20),
              SizedBox(width: 6),
              Text('الموعد ومدة التوقف المبرمجة', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () async {
                    final t = await showTimePicker(context: context, initialTime: _time);
                    if (t != null) setState(() => _time = t);
                  },
                  child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('وقت الوصول المتوقع', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                      Text(arTime(hhmm(_time)), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GestureDetector(
                  onTap: () async {
                    final now = DateTime.now();
                    final d = await showDatePicker(context: context, initialDate: _date, firstDate: dateOnly(now), lastDate: now.add(const Duration(days: 90)));
                    if (d != null) setState(() => _date = d);
                  },
                  child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(10)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(dateOnly(_date) == dateOnly(DateTime.now()) ? 'تاريخ اليوم' : 'تاريخ الوصول', style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
                      Text(' ${fmtDate(_date)} ', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text('مدة الاستراحة المقدرة', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(child: _buildDurationBtn('30', '30 دقيقة')),
              const SizedBox(width: 4),
              Expanded(child: _buildDurationBtn('60', 'صلاة وغداء (60د)')),
              const SizedBox(width: 4),
              Expanded(child: _buildDurationBtn('90', '90 دقيقة')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDurationBtn(String val, String text) {
    bool isSelected = _stopDuration == val;
    return GestureDetector(
      onTap: () => setState(() => _stopDuration = val),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF0E4436) : const Color(0xFFEAE7E7),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: isSelected ? Colors.white : const Color(0xFF404945)),
        ),
      ),
    );
  }

  // 5. ملخص الحجز الذكي
  Widget _buildReservationSummaryCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFECE50).withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFECE50)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.receipt_long, color: Color(0xFF765A00), size: 20),
                  SizedBox(width: 6),
                  Text('ملخص الحجز الذكي', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFFECE50), borderRadius: BorderRadius.circular(10)),
                child: Text(_lastResult != null ? '#${toStr(_lastResult!['booking_code'])}' : '#${toStr(_type?['name'], 'حجز جديد')}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF735800))),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('رصيف توقف الحافلات:', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('${_lastResult != null ? 'رصيف ${toStr(_lastResult!['bus_stop_bay'], 'يحدد عند الوصول')}' : 'يحدد عند التأكيد'} ($_busCount حافلات)', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('رسوم الضيافة والموقف:', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text(_type == null ? '—' : '${sar(_total)} (${sar(toDouble(_type!['price']))} × $_busCount)', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('حصة المحطة 85%: ${sar(_total * ApiService.ownerShare)}', style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
                    Text('المنصة 15%: ${sar(_total * ApiService.platformShare)}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF765A00))),
                  ],
                ),
              ],
            ),
          ),
          if (_isConfirmed) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFB9EEDA), borderRadius: BorderRadius.circular(10)),
              child: const Row(
                children: [
                  Icon(Icons.qr_code_2, size: 30, color: Color(0xFF0E4436)),
                  SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('تم إصدار تصريح الدخول الذكي', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                      Text('باركود التحقق مفعل بجميع البوابات', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // 6. زر التأكيد النهائي
  Widget _buildConfirmationButton() {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0E4436),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        onPressed: _submitting ? null : _confirmBooking,
        icon: Icon(_isConfirmed ? Icons.verified : Icons.qr_code_scanner, color: const Color(0xFFFECE50)),
        label: Text(
          _submitting ? 'جاري إرسال الحجز...' : (_isConfirmed ? 'تم تأكيد الحجز بنجاح' : 'تأكيد حجز الاستراحة والموقف'),
          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildActiveTicketCard() {
    final b = _active.first;
    final d = toDate(b['booking_date']);
    final isToday = d != null && dateOnly(d) == dateOnly(DateTime.now());
    final total = toDouble(b['total_amount']);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFB9EEDA), width: 1.5),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: Color(0xFF0E4436),
              borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.confirmation_number, color: Color(0xFFFECE50), size: 18),
                    const SizedBox(width: 6),
                    Text(
                      '${isToday ? 'حجز نشط حالياً' : 'الحجز القادم'} #${toStr(b['booking_code'])}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFECE50),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    toStr(b['status']) == 'pending' ? 'بانتظار التأكيد' : 'مؤكد للوصول',
                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF735800)),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_bkName(b), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                        const SizedBox(height: 2),
                        Text(' ${toStr(b['city'])} •  ${toStr(b['address_label'], toStr(b['highway_name']))}', style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
                      ],
                    ),
                    ),
                    InkWell(
                      onTap: () => widget.onShowToast("رمز تصريح الدخول: ${toStr(b['qr_code_token'])}"),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF6F3F2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: const Color(0xFFF0EDED)),
                        ),
                        child: const Icon(Icons.qr_code_2, size: 36, color: Color(0xFF0E4436)),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24, thickness: 1),
                Row(
                  children: [
                    Expanded(child: _buildDetailGridItem(Icons.event, 'التاريخ', '${isToday ? 'اليوم ، ' : ''}${fmtDate(d)}')),
                    Expanded(child: _buildDetailGridItem(Icons.access_time, 'وقت التوقف', arTime(toStr(b['arrival_time'])))),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _buildDetailGridItem(Icons.directions_bus, 'الموقف المحجوز', 'رصيف رقم ${toStr(b['bus_stop_bay'], '—')} (${toInt(b['bus_count'], 1)} حافلة)')),
                    Expanded(child: _buildDetailGridItem(Icons.payments, 'المبلغ', total == 0 ? 'مجاني (مبادرة راحة ضيف)' : sar(total))),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF6F3F2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: Color(0xFF765A00), size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          toStr(b['notes']).isEmpty ? 'يرجى إبراز رمز QR لمشرف البوابة عند الوصول لتسهيل دخول الحافلة.' : '${toStr(b['notes'])} — أبرز رمز QR لمشرف البوابة عند الوصول.',
                          style: const TextStyle(fontSize: 11, color: Color(0xFF404945)),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF0E4436),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                        ),
                        onPressed: () {
                          selectedStation = Station({'rest_stop_id': b['rest_stop_id'], 'app_title': _bkName(b), 'city': b['city']});
                          widget.onNavigateToDetails();
                        },
                        icon: const Icon(Icons.map, size: 16, color: Colors.white),
                        label: const Text('الملاحة للمحطة', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFF0E4436)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                      ),
                      onPressed: () => _cancelBooking(b),
                      icon: const Icon(Icons.edit_calendar, size: 16, color: Color(0xFF0E4436)),
                      label: const Text('إلغاء', style: TextStyle(color: Color(0xFF0E4436), fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailGridItem(IconData icon, String title, String val) {
    return Row(
      children: [
        Icon(icon, size: 18, color: const Color(0xFF0E4436)),
        const SizedBox(width: 6),
        Expanded(
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
            Text(val, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
          ],
        ),
        ),
      ],
    );
  }

  Widget _buildUpcomingBookingsHeader() {
    return const Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'الحجوزات القادمة للرحلة',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436)),
        ),
        Text('مجدولة تلقائياً', style: TextStyle(fontSize: 11, color: Color(0xFF404945))),
      ],
    );
  }

  Widget _buildUpcomingBookingItem(Map<String, dynamic> b) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF0EDED)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Row(
                children: [
                  const Icon(Icons.storefront, color: Color(0xFF765A00), size: 18),
                  const SizedBox(width: 6),
                  Flexible(child: Text(_bkName(b), style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
                ],
              ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFF6F3F2), borderRadius: BorderRadius.circular(8)),
                child: Text('${fmtDate(toDate(b['booking_date']))} • ${arTime(toStr(b['arrival_time']))}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF404945))),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text('الخدمات: ${toStr(b['type_name'], 'حجز استراحة')} × ${toInt(b['bus_count'], 1)} • ${sar(toDouble(b['total_amount']))}${toStr(b['notes']).isEmpty ? '' : ' • ${toStr(b['notes'])}'}', style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('رقم الحجز: #${toStr(b['booking_code'])}', style: const TextStyle(fontSize: 11, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () => _cancelBooking(b),
                child: const Text('إلغاء الحجز', style: TextStyle(fontSize: 11, color: Colors.red)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCompletedBookingsList() {
    final history = _past.map((b) {
      final st = toStr(b['status']);
      return {
        'title': _bkName(b),
        'date': fmtDate(toDate(b['booking_date'])),
        'code': '#${toStr(b['booking_code'])}',
        'status': st == 'completed' ? 'مكتملة بالكامل' : st == 'cancelled' ? 'ملغاة' : 'منتهية',
      };
    }).toList();
    if (history.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: Text('لا توجد حجوزات سابقة', style: TextStyle(fontSize: 12, color: Color(0xFF404945)))),
      );
    }

    return Column(
      children: history.map((item) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFF0EDED)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item['title']!, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text('${item['date']} • ${item['code']}', style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
              ],
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFFEAE7E7), borderRadius: BorderRadius.circular(8)),
              child: Text(item['status']!, style: const TextStyle(fontSize: 10, color: Color(0xFF0E4436), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      )).toList(),
    );
  }

  Widget _buildPermitStatusCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF0EDED),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0x4DC0C9C3)),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: const BoxDecoration(
              color: Color(0x1A0E4436),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.assignment_turned_in, color: Color(0xFF0E4436), size: 20),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('تصاريح الحافلة والمسار مرتبطة', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                Text('جميع الحجوزات متزامنة تلقائياً مع نظام النقابة العامة للسيارات', style: TextStyle(fontSize: 10, color: Color(0xFF404945))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== اضافة محطة جديده=================== 
class AddStationScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateBack;

  const AddStationScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateBack,
  });

  @override
  State<AddStationScreen> createState() => _AddStationScreenState();
}

class _AddStationScreenState extends State<AddStationScreen> {  @override
  void dispose() {
    nameController.dispose();
    cityController.dispose();
    highwayController.dispose();
    descriptionController.dispose();
    locationController.dispose();
    extraServicesController.dispose();
    super.dispose();
  }

  int busCount = 30;
  final TextEditingController nameController = TextEditingController(text: 'محطة واحة النخيل لخدمات المعتمرين');
  final TextEditingController locationController = TextEditingController(text: 'المدينة المنورة - طريق الهجرة السريع (ك 120)');
  final TextEditingController extraServicesController = TextEditingController();
  double _lat = 24.3298;
  double _lng = 39.5411;
  bool _submitting = false;

  // باقات الاشتراك من جدول rd_plans (قيم احتياطية مطابقة للقاعدة)
  List<Map<String, dynamic>> _plans = [
    {'plan_code': 'basic', 'plan_name': 'أساسية', 'monthly_price': 299, 'yearly_price': 2990},
    {'plan_code': 'plus', 'plan_name': 'مميزة', 'monthly_price': 599, 'yearly_price': 5990},
    {'plan_code': 'gold', 'plan_name': 'ذهبية', 'monthly_price': 999, 'yearly_price': 9990},
  ];
  String _planCode = 'plus';
  String _billingCycle = 'YEARLY';

  @override
  void initState() {
    super.initState();
    ApiService.fetchPlans().then((p) {
      if (p.isNotEmpty && mounted) setState(() => _plans = p);
    }).catchError((_) {});
  }

  Map<String, dynamic> get _plan => _plans.firstWhere((p) => p['plan_code'] == _planCode, orElse: () => _plans.first);
  double get _planPrice => toDouble(_billingCycle == 'YEARLY' ? _plan['yearly_price'] : _plan['monthly_price']);
  double get _planTotalWithVat => _planPrice * (1 + ApiService.vatRate);

  /// الخدمات المختارة بأسماء جدول rd_services
  List<String> get _selectedServices => [
        if (isFuelChecked) 'وقود',
        if (isServiceChecked) ...['صيانة حافلات', 'غسيل حافلات'],
        if (isRestChecked) 'استراحة',
        if (isShadeChecked) 'مواقف',
        if (isMosqueChecked) 'مصلى',
        if (isWcChecked) 'دورات مياه',
        if (isRestaurantChecked) 'مطعم',
        if (isStoreChecked) 'تموينات',
        if (isAtmChecked) 'صراف آلي',
        if (isAccessibilityChecked) 'تسهيلات حركة',
        if (isWifiChecked) 'واي فاي',
      ];

  Future<void> _choosePlan() async {
    final res = await showModalBottomSheet<List<String>>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('اختر باقة الشراكة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
            ),
            for (final p in _plans)
              for (final cycle in const ['YEARLY', 'MONTHLY'])
                ListTile(
                  title: Text('${toStr(p['plan_name'])} — ${cycle == 'YEARLY' ? 'سنوي' : 'شهري'}'),
                  trailing: Text('${fmtMoney(toDouble(cycle == 'YEARLY' ? p['yearly_price'] : p['monthly_price']))} ر.س',
                      style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
                  onTap: () => Navigator.pop(ctx, [toStr(p['plan_code']), cycle]),
                ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (res != null) setState(() {
      _planCode = res[0];
      _billingCycle = res[1];
    });
  }

  Future<void> _editLocation() async {
    final latC = TextEditingController(text: _lat.toString());
    final lngC = TextEditingController(text: _lng.toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الإحداثيات'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: latC, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'خط العرض (16 – 33)')),
          TextField(controller: lngC, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'خط الطول (34 – 56)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true) return;
    final la = double.tryParse(latC.text.trim());
    final ln = double.tryParse(lngC.text.trim());
    if (la == null || ln == null || la < 16 || la > 33 || ln < 34 || ln > 56) {
      widget.onShowToast('الإحداثيات يجب أن تكون داخل المملكة');
      return;
    }
    setState(() {
      _lat = la;
      _lng = ln;
    });
  }

  Future<void> _submitStation() async {
    final name = nameController.text.trim();
    if (name.length < 3) {
      widget.onShowToast('أدخل اسم المحطة التجاري');
      return;
    }
    if (!isTermsAccepted) {
      widget.onShowToast('يجب الإقرار بصحة البيانات والموافقة على الشروط');
      return;
    }
    if (_selectedServices.isEmpty) {
      widget.onShowToast('اختر خدمة واحدة على الأقل');
      return;
    }
    // "المدينة - الطريق (الكيلو)"
    final loc = locationController.text.trim();
    final parts = loc.split(RegExp(r'\s+-\s+'));
    final city = parts.first.trim().isEmpty ? cityController.text : parts.first.trim();
    final highway = parts.length > 1 ? parts.sublist(1).join(' - ').trim() : highwayController.text;
    final extra = extraServicesController.text.trim();

    setState(() => _submitting = true);
    widget.onShowToast("جاري إرسال البيانات إلى قاعدة البيانات...");
    try {
      final id = await ApiService.addStation({
        'owner_id': Session.userId,
        'name': name,
        'city': city,
        'highway_name': highway.replaceAll(RegExp(r'\s*\(.*\)\s*'), '').trim(),
        'address_label': highway,
        'description': [descriptionController.text.trim(), if (extra.isNotEmpty) 'خدمات إضافية: $extra'].join(' — '),
        'latitude': _lat,
        'longitude': _lng,
        'bus_capacity': busCount,
        'waiting_capacity': guestCount,
        'open_time': selectedWorkingHours == 0 ? '24/7' : '0500-2400',
        'plan_code': _planCode,
        'billing_cycle': _billingCycle,
        'services': _selectedServices,
      });
      widget.onShowToast("تم حفظ المحطة بنجاح في قاعدة البيانات! رقم الطلب #$id — قيد المراجعة");
      widget.onNavigateBack();
    } catch (e) {
      widget.onShowToast(e.toString());
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }
  final TextEditingController cityController = TextEditingController(text: 'المدينة المنورة');
  final TextEditingController highwayController = TextEditingController(text: 'طريق الهجرة السريع');
  final TextEditingController descriptionController = TextEditingController(text: 'استراحة نموذجية لخدمة ضيوف الرحمن');

  int guestCount = 1500;
  int selectedWorkingHours = 0; // 0: 24h, 1: specific
  bool isFuelChecked = true;
  bool isServiceChecked = true;
  bool isRestChecked = true;
  bool isShadeChecked = true;
  bool isMosqueChecked = true;
  bool isWcChecked = true;
  bool isRestaurantChecked = true;
  bool isStoreChecked = true;
  bool isAtmChecked = true;
  bool isAccessibilityChecked = true;
  bool isWifiChecked = true;
  bool isTermsAccepted = true;

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF0E4436);
    const primaryContainerColor = Color(0xFF2A5C4D);
    const secondaryColor = Color(0xFF765A00);
    const secondaryContainer = Color(0xFFFECE50);
    const secondaryFixed = Color(0xFFFFDF96);
    const onPrimary = Colors.white;
    const surfaceContainerLow = Color(0xFFF6F3F2);
    const surfaceContainer = Color(0xFFF0EDED);
    const onSurface = Color(0xFF1B1C1C);
    const onSurfaceVariant = Color(0xFF404945);

    return Scaffold(
      backgroundColor: const Color(0xFFFCF9F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF9F8).withOpacity(0.85),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward, color: onSurface),
          onPressed: widget.onNavigateBack,
        
      
      ),
        title: const Text(
          'Station Details',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: primaryColor,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(left: 16.0),
            child: CircleAvatar(
              radius: 16,
              backgroundImage: NetworkImage(
                'https://lh3.googleusercontent.com/aida/AEtjO1XnqM0nV_90wtxn8gBzctsKEAKfKnVVrcZjey1WAAZs6SBedREwp9dU2TrBuCxKTmnkMSOiVxyGA4F5qBIHmVM7kgfQJbBycTjD45V9d7UjAB1OlsxnaWqyW3DEhL1Pud-TkVTsPXEtkzQ9y9owqJnqmhGG2nYuFNN5RijD2y0q3Pypq-FQwX8_qLikqHAIICccM5f8G0VVkCxKhfO0Y2sohOJgD5RgCvydl_HCPeAoAOHQvr4V3Xsk8RIZ6AdJKjPc0qdDUwY6RQ',
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            // 1. Header Banner & Partner Welcome
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryContainerColor, primaryColor],
                  begin: Alignment.centerRight,
                  end: Alignment.centerLeft,
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.verified, size: 14, color: secondaryFixed),
                                  SizedBox(width: 4),
                                  Text(
                                    'بوابة الشركاء وملاك المحطات',
                                    style: TextStyle(color: secondaryFixed, fontSize: 11, fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'طلب إضافة محطة جديدة',
                              style: TextStyle(color: onPrimary, fontSize: 22, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'انضم لشبكة "راحة ضيف" المعتمدة لخدمة قوافل ضيوف الرحمن وحقق عوائد استثمارية تشغيلية مستدامة على مدار العام.',
                              style: TextStyle(color: onPrimary.withOpacity(0.85), fontSize: 13, height: 1.4),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: secondaryContainer.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Icon(Icons.storefront, color: secondaryFixed, size: 30),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Stepper Tracker
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStepItem('1', 'البيانات الأساسية', true, secondaryContainer, secondaryFixed),
                        Expanded(child: Divider(color: onPrimary.withOpacity(0.3), thickness: 1)),
                        _buildStepItem('2', 'المرافق والطاقة', false, secondaryContainer, secondaryFixed),
                        Expanded(child: Divider(color: onPrimary.withOpacity(0.3), thickness: 1)),
                        _buildStepItem('3', 'الرسوم والاعتماد', false, secondaryContainer, secondaryFixed),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 2. Section One: Basic Station Information
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.domain, color: primaryColor, size: 24),
                      SizedBox(width: 8),
                      Text('1. معلومات المحطة والاستراحة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: onSurface)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildTextField('اسم المحطة أو الاستراحة التجاري', 'محطة واحة النخيل لخدمات المعتمرين', Icons.badge, surfaceContainerLow, nameController),
                  const SizedBox(height: 14),
                  _buildDropdownField('تصنيف المحطة التشغيلي', 'محطة توقف واستراحة ضيافة متكاملة', surfaceContainerLow),
                  const SizedBox(height: 14),
                  _buildTextField('المدينة / الطريق السريع والموقع', 'المدينة المنورة - طريق الهجرة السريع (ك 120)', Icons.add_location_alt, surfaceContainerLow, locationController),
                  const SizedBox(height: 16),
                  
                  // Map Selector Component
                  const Text('الإحداثيات الجغرافية الدقيقة', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: onSurface)),
                  const SizedBox(height: 6),
                  Container(
                    height: 140,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: surfaceContainer,
                      borderRadius: BorderRadius.circular(16),
                      image: const DecorationImage(
                        image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuCJncvm1yvbuh-_dvt_K376XMiH0MUzabZ1lrkJ3BpTQgLMFeUi4KAXng3KNTMlxrYZa1AiJdODwDPPwt4rgS8xfVooaGY22nNAhQQCw15ERPRd-85Devw3lSkh6GjjXxzCt3IX9ZDJLfrfDBSWCPTEzlUrvL44joo5vFCxSCcsOFxinaA-oM6UL-fv61Wued131IOAZ8LzcrmbKq0gZShfXSi26GK_m8VD6aZL8GJwuFLfNhGEMzvEbg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [primaryColor.withOpacity(0.7), Colors.transparent],
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 12,
                          left: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    const Icon(Icons.pin_drop, color: primaryColor, size: 20),
                                    const SizedBox(width: 8),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('${_lat.toStringAsFixed(4)}° N, ${_lng.toStringAsFixed(4)}° E', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                                        const Text('طريق الهجرة باتجاه مكة المكرمة', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                                      ],
                                    ),
                                  ],
                                ),
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: primaryColor,
                                    minimumSize: Size.zero,
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                  ),
                                  onPressed: _editLocation,
                                  icon: const Icon(Icons.my_location, size: 14, color: onPrimary),
                                  label: const Text('تعديل', style: TextStyle(fontSize: 11, color: onPrimary)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Documents Upload
                  const Text('التراخيص المعتمدة (السجل وتصريح هيئة النقل)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: onSurface)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: surfaceContainerLow,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: primaryColor.withOpacity(0.1),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.upload_file, color: primaryColor, size: 26),
                        ),
                        const SizedBox(height: 8),
                        const Text('اضغط لرفع نسخة السجل والتراخيص التشغيلية', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                        const Text('صيغ مدعومة: PDF أو JPG حتى 10 ميجابايت كحد أقصى', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Row(
                                children: [
                                  Icon(Icons.description, color: secondaryColor, size: 22),
                                  SizedBox(width: 8),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('tasreeh_naql_2024.pdf', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                                      Text('2.4 ميجابايت • تم التحقق الأولي', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                                    ],
                                  ),
                                ],
                              ),
                              const Icon(Icons.check_circle, color: primaryColor, size: 20),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 3. Section Two: Operational Capacity & Timings
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.speed, color: primaryColor, size: 24),
                      SizedBox(width: 8),
                      Text('2. الطاقة الاستيعابية وساعات العمل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: onSurface)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildCounterRow('سعة مواقف الحافلات الكبرى', 'القدرة على استيعاب حافلات بالتزامن', busCount, (val) => setState(() => busCount = val), surfaceContainerLow, primaryColor),
                  const SizedBox(height: 12),
                  _buildCounterRow('سعة صالات الضيافة والانتظار', 'إجمالي ضيوف الرحمن في الساعة', guestCount, (val) => setState(() => guestCount = val), surfaceContainerLow, primaryColor),
                  const SizedBox(height: 16),
                  const Text('أوقات وساعات العمل والتشغيل', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: onSurface)),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => setState(() => selectedWorkingHours = 0),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: surfaceContainerLow,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: selectedWorkingHours == 0 ? primaryColor : Colors.transparent),
                      ),
                      child: Row(
                        children: [
                          Radio<int>(
                            value: 0,
                            groupValue: selectedWorkingHours,
                            activeColor: primaryColor,
                            onChanged: (val) => setState(() => selectedWorkingHours = val!),
                          ),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('تشغيل مستمر على مدار 24 ساعة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                Text('الخيار المفضل والموصى به لجميع قوافل المعتمرين', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                              ],
                            ),
                          ),
                          const Icon(Icons.all_inclusive, color: secondaryColor),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => setState(() => selectedWorkingHours = 1),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: surfaceContainerLow,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: selectedWorkingHours == 1 ? primaryColor : Colors.transparent),
                      ),
                      child: Row(
                        children: [
                          Radio<int>(
                            value: 1,
                            groupValue: selectedWorkingHours,
                            activeColor: primaryColor,
                            onChanged: (val) => setState(() => selectedWorkingHours = val!),
                          ),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('فترات محددة يومياً (فترات مخصصة)', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                Text('مثال: من صلاة الفجر وحتى منتصف الليل', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                              ],
                            ),
                          ),
                          const Icon(Icons.schedule, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 4. Section Three: Station Facilities & Services Checklist
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.room_service, color: primaryColor, size: 24),
                      SizedBox(width: 8),
                      Text('3. الخدمات والمرافق المتاحة بالمحطة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: onSurface)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Row(
                    children: [
                      CircleAvatar(radius: 5, backgroundColor: secondaryColor),
                      SizedBox(width: 6),
                      Text('خدمات الحافلات وأطقم القيادة', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: primaryColor)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _buildCheckboxTile('تزويد وقود مخصص للحافلات (ديزل فائق / بنزين)', Icons.local_gas_station, isFuelChecked, (v) => setState(() => isFuelChecked = v!)),
                  _buildCheckboxTile('ورشة إطارات وغسيل حافلات', Icons.car_repair, isServiceChecked, (v) => setState(() => isServiceChecked = v!)),
                  _buildCheckboxTile('استراحة نوم مكيّفة وغرف مخصصة للسائقين', Icons.bed, isRestChecked, (v) => setState(() => isRestChecked = v!)),
                  _buildCheckboxTile('مواقف مظللة', Icons.ev_station, isShadeChecked, (v) => setState(() => isShadeChecked = v!)),
                  
                  const SizedBox(height: 16),
                  const Row(
                    children: [
                      CircleAvatar(radius: 5, backgroundColor: secondaryColor),
                      SizedBox(width: 6),
                      Text('مرافق الضيافة وخدمات الحجاج والمعتمرين', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: primaryColor)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _buildCheckboxTile('مصلى للرجال والنساء', Icons.mosque, isMosqueChecked, (v) => setState(() => isMosqueChecked = v!)),
                  _buildCheckboxTile('دورات مياه فندقية نموذجية معقمة بنظام تنظيف دوري', Icons.wc, isWcChecked, (v) => setState(() => isWcChecked = v!)),
                  _buildCheckboxTile('مطاعم وكافيهات حاصلة على شهادات صحية', Icons.restaurant, isRestaurantChecked, (v) => setState(() => isRestaurantChecked = v!)),
                  _buildCheckboxTile('سوبرماركت ومستلزمات إحرام وضيافة 24 ساعة', Icons.local_convenience_store, isStoreChecked, (v) => setState(() => isStoreChecked = v!)),
                  _buildCheckboxTile('أجهزة صراف آلي (ATM) دعم نقاط الدفع الرقمية', Icons.atm, isAtmChecked, (v) => setState(() => isAtmChecked = v!)),
                  _buildCheckboxTile('مسارات ومرافق مجهزة بالكامل لذوي الإعاقة وكبار السن', Icons.accessible, isAccessibilityChecked, (v) => setState(() => isAccessibilityChecked = v!)),
                  _buildCheckboxTile('إنترنت مفتوح فائق السرعة 5G ومحطات شحن هواتف', Icons.wifi, isWifiChecked, (v) => setState(() => isWifiChecked = v!)),
                  
                  const SizedBox(height: 14),
                  const Text('خدمات ومميزات استثنائية أخرى تقدمها المحطة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  TextField(
                    controller: extraServicesController,
                    maxLines: 2,
                    decoration: InputDecoration(
                      hintText: 'أذكر أي خدمات إضافية مثل: عيادة إسعافية، صالة VIP لكبار الضيوف، خدمات شحن حقائب...',
                      hintStyle: const TextStyle(fontSize: 12, color: onSurfaceVariant),
                      filled: true,
                      fillColor: surfaceContainerLow,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Visual Hospitality Vignettes
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 110,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      image: const DecorationImage(
                        image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuAFTXW6r2bvNG-NJbURtb90Z15A7JS4zZQSzDWcC93tL0I0-C_rNnu--5x5vvabBVrN236VEczk2zD7yx3H0qLXGRro-ji5Qj6GvThSmQoUrKxntJ44nPfm2HTf8BvOMG7QQ8Ad6_C28VeyXibgwSNafuoIE0qVvowVysiwcZJLim4hQyfJhfS5zhkmZnnz5S-z803yc2ypvyWxSkuuM73CU7qGgG14aHd2GoCI4M7w1xUx-8yY6zdWzQ'),
                        fit: BoxFit.cover,
                      ),
                    ),
                    alignment: Alignment.bottomRight,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
                        gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [primaryColor.withOpacity(0.9), Colors.transparent]),
                      ),
                      child: const Text('مواقف مظللة', style: TextStyle(color: onPrimary, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    height: 110,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      image: const DecorationImage(
                        image: NetworkImage('https://lh3.googleusercontent.com/aida-public/AB6AXuADgbxlOwupqNg636AY691Z30BjfMJFM0gvPowIwCWpRaV3fGrpCfIk_m2CToU-iZH6uKwGbypkl8qmEl5-mUwxd0CtUFikDbrASRv7mNxFuC5VsuLf2evQyyJ1YQpc2Y90JDTdsdFxr2tcUDj_xj885ZvhsB8WhbTAPYoN7Zh35QoFnNYaNfaOf0QcGLubAPjjMlaMHkHQ4KeKta9fa3kAKHCpEATFW61QsSgZ1VfAuGi4MZ65oQHssQ'),
                        fit: BoxFit.cover,
                      ),
                    ),
                    alignment: Alignment.bottomRight,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
                        gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [primaryColor.withOpacity(0.9), Colors.transparent]),
                      ),
                      child: const Text('صالات انتظار وضيافة', style: TextStyle(color: onPrimary, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // 5. Section Four: Monetization Model & Annual Partnership Package
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [secondaryContainer.withOpacity(0.25), Colors.white],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.payments, color: secondaryColor, size: 26),
                          SizedBox(width: 8),
                          Text('4. باقة الشراكة ونموذج العوائد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface)),
                        ],
                      ),
                      GestureDetector(
                        onTap: _choosePlan,
                        child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: secondaryColor, borderRadius: BorderRadius.circular(20)),
                        child: Text('باقة ${toStr(_plan['plan_name'], 'معتمدة')}', style: const TextStyle(color: onPrimary, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: _choosePlan,
                              child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(_billingCycle == 'YEARLY' ? 'رسوم الربط والاشتراك السنوي' : 'رسوم الربط والاشتراك الشهري', style: const TextStyle(fontSize: 10, color: onSurfaceVariant)),
                                const SizedBox(height: 2),
                                Row(
                                  children: [
                                    Text(fmtMoney(_planPrice), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: primaryColor)),
                                    const SizedBox(width: 4),
                                    Text(_billingCycle == 'YEARLY' ? 'ريال سعودي / سنوي' : 'ريال سعودي / شهري', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: secondaryColor)),
                                  ],
                                ),
                              ],
                            ),
                            ),
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: surfaceContainerLow, borderRadius: BorderRadius.circular(12)),
                              child: Column(
                                children: [
                                  const Text('تُدفع لاحقاً', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: primaryColor)),
                                  Text('شامل الضريبة ${fmtMoney(_planTotalWithVat)}', style: const TextStyle(fontSize: 9, color: onSurfaceVariant)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'تشمل الرسوم: التضمين في تطبيق السائقين، اللوحات الإرشادية الذكية بالمحطة، الربط مع منصة إدارة الحجوزات اللوجستية، ولوحة تحكم مباشرة لمتابعة القوافل القادمة.',
                          style: TextStyle(fontSize: 11, color: onSurfaceVariant, height: 1.4),
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: surfaceContainerLow, borderRadius: BorderRadius.circular(12)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Row(
                                children: [
                                  Icon(Icons.percent, size: 16, color: primaryColor),
                                  SizedBox(width: 4),
                                  Text('نموذج تقاسم الأرباح والحجوزات المباشرة', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: primaryColor)),
                                ],
                              ),
                              const SizedBox(height: 8),
                              const Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('85% لصاحب المحطة', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: primaryColor)),
                                  Text('15% لمنصة راحة ضيف', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: onSurfaceVariant)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Row(
                                  children: [
                                    Expanded(flex: 85, child: Container(height: 10, color: primaryColor)),
                                    Expanded(flex: 15, child: Container(height: 10, color: secondaryColor)),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 6),
                              const Text('تخضع مبيعات الحجوزات المسبقة ومشتريات القوافل للتسوية التلقائية والتحويل الدوري لحسابك البنكي المعتمد.', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Checkbox(
                        value: isTermsAccepted,
                        activeColor: primaryColor,
                        onChanged: (val) => setState(() => isTermsAccepted = val!),
                      ),
                      const Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(top: 8.0),
                          child: Text(
                            'أقر بصفتي مالكاً أو ممثلاً نظامياً بصحة البيانات المرفقة، وأوافق على الشروط والأحكام ونظام تقاسم الأرباح وسياسات معايير ضيافة ضيوف الرحمن.',
                            style: TextStyle(fontSize: 12, color: onSurface, height: 1.3),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // 6. Section Five: Workflow Steps Timeline
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.account_tree, color: primaryColor, size: 24),
                      SizedBox(width: 8),
                      Text('مسار مراجعة واعتماد المحطة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: onSurface)),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _buildTimelineStep('1', 'إرسال الطلب إلكترونياً', 'رفع وتوثيق الوثائق الرسمية والموقع الجغرافي عبر النموذج الحالي.', primaryColor, onPrimary),
                  _buildTimelineStep('2', 'التدقيق المكتبي والزيارة الميدانية', 'يقوم فريق مراقبة الجودة بزيارة المحطة والتحقق من اشتراطات النظافة والسلامة.', secondaryColor, onPrimary),
                  _buildTimelineStep('3', 'توقيع العقد الرقمي وسداد الرسوم', 'إصدار الفاتورة الرسمية (${fmtMoney(_planTotalWithVat)} ر.س شامل ضريبة القيمة المضافة 15%) بعد الاعتماد والموافقة الفورية.', surfaceContainer, onSurface),
                  _buildTimelineStep('4', 'التدشين والإتاحة لقوافل الحافلات', 'ظهور محطتك مباشرة كـ "محطة موثوقة ونشطة" في نظام توجيه السائقين ومكاتب العمرة.', surfaceContainer, onSurface, isLast: true),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 7. Bottom Action Trigger
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: _submitting ? null : _submitStation,
  style: ElevatedButton.styleFrom(
    backgroundColor: primaryContainerColor,
    foregroundColor: onPrimary,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),
  icon: const Icon(Icons.send, size: 20),
  label: const Text('إرسال طلب إضافة المحطة للمراجعة', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
),
            ),
            const SizedBox(height: 12),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.verified_user, size: 16, color: secondaryColor),
                SizedBox(width: 6),
                Text('منظومة معتمدة من وزارة الحج والعمرة والهيئة العامة للنقل', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
              ],
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  static Widget _buildStepItem(String step, String title, bool isActive, Color activeBg, Color activeFg) {
    return Column(
      children: [
        CircleAvatar(
          radius: 14,
          backgroundColor: isActive ? activeBg : Colors.white24,
          child: Text(
            step,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: isActive ? activeFg : Colors.white),
          ),
        ),
        const SizedBox(height: 4),
        Text(title, style: TextStyle(color: isActive ? Colors.white : Colors.white70, fontSize: 9)),
      ],
    );
  }

  static Widget _buildTextField(String label, String value, IconData icon, Color bg, [TextEditingController? controller]) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        TextField(
          controller: controller ?? TextEditingController(text: value),
          decoration: InputDecoration(
            filled: true,
            fillColor: bg,
            suffixIcon: Icon(icon, color: const Color(0xFF707975), size: 20),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
          style: const TextStyle(fontSize: 13),
        ),
      ],
    );
  }

  static Widget _buildDropdownField(String label, String value, Color bg) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              isExpanded: true,
              items: [value].map((e) => DropdownMenuItem(value: e, child: Text(e, style: const TextStyle(fontSize: 13)))).toList(),
              onChanged: (v) {},
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCounterRow(String title, String subtitle, int value, Function(int) onChange, Color bg, Color primaryColor) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              Text(subtitle, style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => onChange(value > 5 ? value - 5 : value),
                  icon: const Icon(Icons.remove, size: 16),
                  color: Colors.black54,
                ),
                Text('$value', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: primaryColor)),
                IconButton(
                  onPressed: () => onChange(value + 5),
                  icon: const Icon(Icons.add, size: 16),
                  color: primaryColor,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildCheckboxTile(String label, IconData icon, bool value, Function(bool?) onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F3F2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Checkbox(value: value, activeColor: const Color(0xFF0E4436), onChanged: onChanged),
          Icon(icon, color: const Color(0xFF0E4436), size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF1B1C1C)))),
        ],
      ),
    );
  }

  static Widget _buildTimelineStep(String number, String title, String subtitle, Color circleBg, Color circleFg, {bool isLast = false}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(color: circleBg, shape: BoxShape.circle),
              alignment: Alignment.center,
              child: Text(number, style: TextStyle(color: circleFg, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
            if (!isLast)
              Container(width: 2, height: 40, color: const Color(0xFFEAE7E7)),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF1B1C1C))),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xFF404945))),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ],
    );
  }
}

// ==================== ادارة المحطة===================
class StationDashboardScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateToAddStation;

  const StationDashboardScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateToAddStation,
  });

  @override
  State<StationDashboardScreen> createState() => _StationDashboardScreenState();
}

class _StationDashboardScreenState extends State<StationDashboardScreen> {
  Function(String) get onShowToast => widget.onShowToast;
  VoidCallback get onNavigateToAddStation => widget.onNavigateToAddStation;

  // ---------- بيانات اللوحة من قاعدة البيانات ----------
  bool _loaded = false;
  Map<String, dynamic> _user = {};
  Map<String, dynamic> _totals = {};
  List<Map<String, dynamic>> _stations = [];
  List<Map<String, dynamic>> _orders = [];
  List<Map<String, dynamic>> _ledger = [];
  List<Map<String, dynamic>> _meals = [];
  double _pendingPayouts = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    // تحديث لحظي كل 30 ثانية
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool announce = false}) async {
    final uid = Session.userId;
    if (uid == null) return;
    try {
      final d = await ApiService.getOwnerDashboard(uid);
      _user = asMap(d['user']);
      _totals = asMap(d['totals']);
      _stations = asList(d['stations']);
      _orders = asList(d['orders']);
      _ledger = asList(d['ledger']);
      _pendingPayouts = toDouble(d['pending_payouts']);
      try {
        _meals = await ApiService.fetchMeals();
      } catch (_) {}
      _loaded = true;
      if (announce) onShowToast("تم تحديث بيانات المحطة والمحفظة من قاعدة البيانات بنجاح!");
    } catch (e) {
      if (announce) onShowToast(e.toString());
    }
    if (mounted) setState(() {});
  }

  // الأرقام المالية محسوبة من المعاملات الفعلية بنسبة 85% للمحطة و15% للمنصة
  double get _sales => toDouble(_totals['sales']);
  double get _ownerNet => _sales * ApiService.ownerShare;
  double get _platformFee => _sales * ApiService.platformShare;
  double get _available {
    final v = toDouble(_user['wallet_balance']) - _pendingPayouts;
    return v < 0 ? 0 : v;
  }

  String get _stationLabel {
    if (!_loaded) return 'محطة واحة النخيل - نشطة ومفعلة';
    if (_stations.isEmpty) return 'لا توجد محطة مسجلة';
    final s = _stations.first;
    return '${toStr(s['app_title'], toStr(s['name']))} - ${toStr(s['status']) == 'PENDING' ? 'قيد المراجعة' : 'نشطة ومفعلة'}';
  }

  String get _subscriptionLabel {
    if (!_loaded) return 'الاشتراك السنوي ساري (ينتهي بعد 240 يوم)';
    final renews = toDate(_user['subscription_expires_at']) ?? (_stations.isNotEmpty ? toDate(_stations.first['renews_at']) : null);
    if (renews == null) return 'لا يوجد اشتراك مفعل';
    final days = dateOnly(renews).difference(dateOnly(DateTime.now())).inDays;
    final cycle = _stations.isNotEmpty && toStr(_stations.first['billing_cycle']) == 'MONTHLY' ? 'الشهري' : 'السنوي';
    return days >= 0 ? 'الاشتراك $cycle ساري (ينتهي بعد $days يوم)' : 'انتهى الاشتراك منذ ${-days} يوم';
  }

  Map<String, dynamic>? get _openOrder {
    for (final o in _orders) {
      if (toStr(o['status']) != 'DELIVERED') return o;
    }
    return null;
  }

  Future<void> _requestPayout() async {
    if (!_loaded || _stations.isEmpty) {
      onShowToast('لا توجد محطة مرتبطة بحسابك');
      return;
    }
    final ctrl = TextEditingController(text: _available.floor().toString());
    final amount = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('طلب تحويل للأيبان'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('الرصيد المتاح للسحب: ${sar(_available)}', style: const TextStyle(fontSize: 12)),
          TextField(controller: ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (ر.س)', helperText: 'الحد الأدنى 100 ر.س')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, double.tryParse(ctrl.text.trim())), child: const Text('إرسال')),
        ],
      ),
    );
    if (amount == null) return;
    if (amount < 100 || amount > _available) {
      onShowToast('المبلغ يجب أن يكون بين 100 و ${sar(_available)}');
      return;
    }
    try {
      final code = await ApiService.requestPayout(toInt(_stations.first['rest_stop_id']), amount);
      onShowToast("تم إرسال طلب تحويل للأيبان بنجاح ($code — ${sar(amount)})");
      _load();
    } catch (e) {
      onShowToast(e.toString());
    }
  }

  Future<void> _advanceOrder(String status) async {
    final o = _openOrder;
    if (o == null) {
      onShowToast('لا توجد طلبات وجبات مفتوحة حالياً');
      return;
    }
    if (status == 'PREPARING' && toStr(o['status']) != 'PAID') {
      onShowToast('الطلب قيد التجهيز بالفعل — أكّد التسليم عند وصول الحافلة');
      return;
    }
    if (status == 'DELIVERED' && toStr(o['status']) != 'PREPARING') {
      onShowToast('ابدأ تجهيز الوجبات أولاً');
      return;
    }
    try {
      await ApiService.updateMealOrderStatus(toInt(o['order_id']), status);
      onShowToast(status == 'PREPARING'
          ? "تم البدء في تجهيز وجبات الحملة (${o['quantity']} وجبة)"
          : "تم تأكيد التسليم وإيداع ${sar(toDouble(o['total']) * ApiService.ownerShare)} في محفظتك");
      _load();
    } catch (e) {
      onShowToast(e.toString());
    }
  }

  IconData _mealIcon(String name) =>
      name.contains('إفطار') ? Icons.bakery_dining : name.contains('خفيفة') ? Icons.takeout_dining : Icons.rice_bowl;

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF0E4436);
    const primaryContainerColor = Color(0xFF2A5C4D);
    const secondaryColor = Color(0xFF765A00);
    const secondaryContainer = Color(0xFFFECE50);
    const secondaryFixed = Color(0xFFFFDF96);
    const secondaryFixedDim = Color(0xFFEFC043);
    const onPrimary = Colors.white;
    const surfaceContainerLow = Color(0xFFF6F3F2);
    const surfaceContainer = Color(0xFFF0EDED);
    const onSurface = Color(0xFF1B1C1C);
    const onSurfaceVariant = Color(0xFF404945);

    return Scaffold(
      backgroundColor: const Color(0xFFFCF9F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF9F8).withOpacity(0.85),
        elevation: 0,
        titleSpacing: 12,
        title: Row(
          children: [
            const Icon(Icons.local_gas_station, color: primaryColor, size: 20),
            const SizedBox(width: 6),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'إدارة المحطة والمحفظة المالية',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: primaryColor),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    'لوحة تحكم المشغل المعتمد • شبكة راحة ضيف',
                    style: TextStyle(fontSize: 10, color: onSurfaceVariant),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.sync, color: primaryColor, size: 20),
            onPressed: () => _load(announce: true),
            tooltip: 'تحديث البيانات',
          ),
          const Padding(
            padding: EdgeInsets.only(left: 12.0),
            child: CircleAvatar(
              radius: 16,
              backgroundImage: NetworkImage(
                'https://lh3.googleusercontent.com/aida/AEtjO1XnqM0nV_90wtxn8gBzctsKEAKfKnVVrcZjey1WAAZs6SBedREwp9dU2TrBuCxKTmnkMSOiVxyGA4F5qBIHmVM7kgfQJbBycTjD45V9d7UjAB1OlsxnaWqyW3DEhL1Pud-TkVTsPXEtkzQ9y9owqJnqmhGG2nYuFNN5RijD2y0q3Pypq-FQwX8_qLikqHAIICccM5f8G0VVkCxKhfO0Y2sohOJgD5RgCvydl_HCPeAoAOHQvr4V3Xsk8RIZ6AdJKjPc0qdDUwY6RQ',
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => _load(announce: true),
        child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          
          children: [
            
            
            
            // 1. Station Overview & Active Partner Status Card
            Container(
              
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryContainerColor, primaryColor],
                  begin: Alignment.centerRight,
                  end: Alignment.centerLeft,
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.verified, size: 14, color: secondaryFixed),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                    _stationLabel,
                                    style: const TextStyle(color: secondaryFixed, fontSize: 10, fontWeight: FontWeight.bold),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'لوحة العمليات والأرباح',
                              style: TextStyle(color: onPrimary, fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'مرحباً بك أ/ ${_loaded ? toStr(_user['full_name'], Session.displayName) : 'تركي العتيبي'}، نظام التسوية المالية الآلي يعمل مباشرة ومربوط بقواعد بيانات الحملات والقوافل.',
                              style: TextStyle(color: onPrimary.withOpacity(0.85), fontSize: 12, height: 1.4),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: secondaryContainer.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Icon(Icons.account_balance_wallet, color: secondaryFixed, size: 26),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              const Icon(Icons.verified_user, color: secondaryFixed, size: 18),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  _subscriptionLabel,
                                  style: const TextStyle(color: onPrimary, fontSize: 10),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(color: secondaryContainer, borderRadius: BorderRadius.circular(20)),
                          child: Text(_loaded && _subscriptionLabel.startsWith('انتهى') ? 'يلزم التجديد' : 'مدفوع وموثق', style: const TextStyle(color: Color(0xFF735800), fontSize: 10, fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 2. Real-time Wallet & Earnings Dashboard
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Row(
                          children: [
                            Icon(Icons.payments, color: primaryColor, size: 22),
                            SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                'المحفظة الرقمية',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          Container(width: 8, height: 8, decoration: const BoxDecoration(color: secondaryFixedDim, shape: BoxShape.circle)),
                          const SizedBox(width: 4),
                          const Text('تسوية فورية', style: TextStyle(fontSize: 10, color: primaryColor, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: surfaceContainerLow, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('الرصيد المتاح للسحب ', style: TextStyle(fontSize: 11, color: onSurfaceVariant)),
                                  const SizedBox(height: 2),
                                  FittedBox(
                                    fit: BoxFit.scaleDown,
                                    alignment: Alignment.centerRight,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.baseline,
                                      textBaseline: TextBaseline.alphabetic,
                                      children: [
                                        Text(_loaded ? fmtMoney(_available) : '48,250', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: primaryColor)),
                                        const SizedBox(width: 4),
                                        const Text('ريال سعودي', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: secondaryColor)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const Text('إجمالي المبيعات', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                                const SizedBox(height: 2),
                                Text(_loaded ? sar(_sales) : '76,400 ر.س', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: onSurface)),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      _loaded ? 'صافي ربح المحطة 85%: ${sar(_ownerNet)}' : 'صافي ربح المحطة 85%: 64,940 ر.س',
                                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: primaryColor),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Text(_loaded ? 'رسوم المنصة 15%: ${sar(_platformFee)}' : 'رسوم المنصة 15%: 11,460 ر.س', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: onSurfaceVariant)),
                                ],
                              ),
                              const SizedBox(height: 6),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Row(
                                  children: [
                                    Expanded(flex: 85, child: Container(height: 8, color: primaryColor)),
                                    Expanded(flex: 15, child: Container(height: 8, color: secondaryColor)),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(_loaded ? '${toInt(_totals['today_count'])} عملية معالجة اليوم تلقائياً' : '14 عملية معالجة اليوم تلقائياً', style: const TextStyle(fontSize: 10, color: onSurfaceVariant)),
                                  Text(_loaded ? '${toInt(_totals['tx_count'])} Transaction معتمد' : 'Transaction معتمد', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: primaryColor)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor,
                            foregroundColor: onPrimary,
                            minimumSize: const Size(double.infinity, 40),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          onPressed: _requestPayout,
                          icon: const Icon(Icons.account_balance, size: 16),
                          label: const Text('طلب تحويل للأيبان', style: TextStyle(fontSize: 11)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: surfaceContainer,
                            foregroundColor: onSurface,
                            minimumSize: const Size(double.infinity, 40),
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          onPressed: () => onShowToast(_loaded
                              ? "ضريبة القيمة المضافة 15% على رسوم المنصة: ${sar(_platformFee * ApiService.vatRate)}"
                              : "جاري فتح سجل الفواتير الضريبية..."),
                          icon: const Icon(Icons.receipt_long, size: 16),
                          label: const Text('سجل الفواتير الضريبية', style: TextStyle(fontSize: 11)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 3. Live Pilgrim Meal Order Processing
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Row(
                          children: [
                            Icon(Icons.lunch_dining, color: primaryColor, size: 22),
                            SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                'معالجة طلبات وجبات الحملات',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(color: secondaryColor.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                        child: Text(!_loaded ? 'طلب جديد' : _openOrder == null ? 'لا طلبات' : (toStr(_openOrder!['status']) == 'PAID' ? 'طلب جديد' : 'قيد التجهيز'), style: const TextStyle(color: secondaryColor, fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: surfaceContainerLow,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: primaryColor.withOpacity(0.2), width: 2),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(color: primaryColor, borderRadius: BorderRadius.circular(12)),
                                    child: const Icon(Icons.tour, color: onPrimary, size: 22),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          !_loaded ? 'حملة الوفادة الكبرى لحجاج بيت الله' : toStr(_openOrder?['campaign_name'], 'لا توجد طلبات وجبات مفتوحة'),
                                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: onSurface),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          !_loaded ? 'كود الحجز: #ORD-8821 • وصول الحافلة بعد 20 دقيقة' : (_openOrder == null ? 'ستظهر هنا طلبات الحملات فور دفعها' : 'كود الطلب: #${toStr(_openOrder!['order_code'])} • ${toStr(_openOrder!['meal_name'])} • ${relativeTime(toDate(_openOrder!['created_at']))}'),
                                          style: const TextStyle(fontSize: 10, color: onSurfaceVariant),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(color: secondaryContainer, borderRadius: BorderRadius.circular(20)),
                              child: Text(!_loaded ? '95 وجبة' : '${toInt(_openOrder?['quantity'])} وجبة', style: const TextStyle(color: Color(0xFF735800), fontSize: 10, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: const Border(right: BorderSide(color: primaryColor, width: 4)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('تفاصيل المعالجة البرمجية (Transaction):', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: onSurface)),
                              const SizedBox(height: 6),
                              _buildTransactionRow('الخصم من محفظة صاحب الحملة:', !_loaded ? '2,375.00 ر.س' : sar(toDouble(_openOrder?['total'])), primaryColor),
                              const SizedBox(height: 4),
                              _buildTransactionRow('إيداع فوري في محفظتك (85%):', !_loaded ? '+2,018.75 ر.س' : '+${sar(toDouble(_openOrder?['total']) * ApiService.ownerShare)}', primaryColor),
                              const SizedBox(height: 4),
                              _buildTransactionRow('أرباح المنصة المقتطعة (15%):', !_loaded ? '356.25 ر.س' : sar(toDouble(_openOrder?['total']) * ApiService.platformShare), secondaryColor),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryColor,
                                  foregroundColor: onPrimary,
                                  minimumSize: const Size(double.infinity, 38),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                ),
                                onPressed: () => _advanceOrder('PREPARING'),
                                icon: const Icon(Icons.soup_kitchen, size: 16),
                                label: const Text('تجهيز الوجبات', style: TextStyle(fontSize: 10)),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: secondaryColor,
                                  foregroundColor: onPrimary,
                                  minimumSize: const Size(double.infinity, 38),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                ),
                                onPressed: () => _advanceOrder('DELIVERED'),
                                icon: const Icon(Icons.qr_code_scanner, size: 16),
                                label: const Text('تأكيد التسليم (QR)', style: TextStyle(fontSize: 10)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: surfaceContainer,
                              foregroundColor: onSurface,
                              minimumSize: const Size(double.infinity, 36),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              side: BorderSide.none,
                            ),
                            onPressed: () => onShowToast("جاري طباعة استلام الحملة..."),
                            icon: const Icon(Icons.print, size: 16),
                            label: const Text('طباعة استلام الحملة', style: TextStyle(fontSize: 10)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 4. Station Meal Packages & Menu Inventory
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Row(
                          children: [
                            Icon(Icons.restaurant_menu, color: primaryColor, size: 22),
                            SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                'إدارة الوجبات',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: surfaceContainerLow,
                          foregroundColor: primaryColor,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        ),
                        onPressed: () => onShowToast("فتح نافذة إضافة وجبة جديدة..."),
                        child: const Text('+ إضافة وجبة', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_meals.isNotEmpty)
                    for (var i = 0; i < _meals.length; i++) ...[
                      if (i > 0) const SizedBox(height: 8),
                      _buildMealItem(
                        toStr(_meals[i]['meal_name']),
                        'المتوفر: ${_meals[i]['stock_qty'] == null ? 'غير محدد' : '${fmtMoney(toInt(_meals[i]['stock_qty']))} وجبة'} • ${fmtMoney(toDouble(_meals[i]['price']))} ر.س',
                        _mealIcon(toStr(_meals[i]['meal_name'])),
                        i.isOdd ? secondaryColor : primaryColor,
                      ),
                    ]
                  else ...[
                  _buildMealItem('وجبة غداء ', 'المتوفر: 350 وجبة • 25 ر.س', Icons.rice_bowl, primaryColor),
                  const SizedBox(height: 8),
                  _buildMealItem('باقة إفطار صائم معتمر ', 'المتوفر: 520 وجبة • 14 ر.س', Icons.bakery_dining, secondaryColor),
                  const SizedBox(height: 8),
                  _buildMealItem('وجبة خفيفة للطريق', 'المتوفر: 210 وجبة • 10 ر.س', Icons.takeout_dining, primaryColor),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 5. Real-time Transaction Ledger
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Row(
                          children: [
                            Icon(Icons.receipt_long, color: primaryColor, size: 22),
                            SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                'سجل القيود المالية اللحظية (Ledger)',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Text('تحديث حي', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_loaded)
                    for (var i = 0; i < _ledger.length; i++) ...[
                      if (i > 0) const SizedBox(height: 8),
                      _buildLedgerItem(
                        toStr(_ledger[i]['reason']),
                        '${relativeTime(toDate(_ledger[i]['created_at']))}${toStr(_ledger[i]['ref_code']).isEmpty ? '' : ' • ${toStr(_ledger[i]['ref_code'])}'}',
                        '${toDouble(_ledger[i]['amount']) >= 0 ? '+' : ''}${sar(toDouble(_ledger[i]['amount']))}',
                        toDouble(_ledger[i]['amount']) >= 0 ? Icons.arrow_downward : Icons.arrow_upward,
                      ),
                    ]
                  else ...[
                  _buildLedgerItem('إيداع مبيعات وجبات', 'منذ 5 دقائق • معالجة تلقائية', '+2,018.75 ر.س', Icons.arrow_downward),
                  const SizedBox(height: 8),
                  _buildLedgerItem('رسوم توقف ومسار حافلة VIP', 'منذ 34 دقيقة • خصم رقمي', '+127.50 ر.س', Icons.directions_bus),
                  const SizedBox(height: 8),
                  _buildLedgerItem('حجز صالة استراحة خاصة ', 'منذ ساعتين • عبر التطبيق', '+425.00 ر.س', Icons.meeting_room),
                  ],
                  if (_loaded && _ledger.isEmpty)
                    const Text('لا توجد قيود مالية بعد', style: TextStyle(fontSize: 11, color: onSurfaceVariant)),
                ],
              ),
            ),
            //                هناااااااااا
            // Bottom Guarantee Footer
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.security, size: 14, color: secondaryColor),
                SizedBox(width: 4),
                Expanded(
                  child: Text(
                    'جميع العمليات المالية مشفرة وخاضعة لضوابط الامتثال المالي لمنظومة راحة ضيف',
                    style: TextStyle(fontSize: 9, color: onSurfaceVariant),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      ),
    );
  }

  static Widget _buildTransactionRow(String label, String amount, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Row(
            children: [
              const Icon(Icons.check_circle, size: 14, color: Color(0xFF0E4436)),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 10, color: Color(0xFF1B1C1C)),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 4),
        Text(amount, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: color)),
      ],
    );
  }

  Widget _buildMealItem(String title, String subtitle, IconData icon, Color iconColor) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F3F2),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF1B1C1C)),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(fontSize: 9, color: Color(0xFF404945)),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF0E4436),
              elevation: 0,
              minimumSize: Size.zero,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () => onShowToast("تعديل وجبة: $title"),
            child: const Text('تعديل', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  static Widget _buildLedgerItem(String title, String subtitle, String amount, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF6F3F2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Icon(icon, color: const Color(0xFF0E4436), size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF1B1C1C)),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(fontSize: 9, color: Color(0xFF404945)),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(amount, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
              const Text('ناجحة ومسجلة', style: TextStyle(fontSize: 9, color: Color(0xFF0E4436))),
            ],
          ),
        ],
      ),
    );
  }
}



// ==================== حسابي ==================
class MyAccountScreen extends StatefulWidget {
  final Function(String) onShowToast;
  final VoidCallback onNavigateToAddStation;

  const MyAccountScreen({
    super.key,
    required this.onShowToast,
    required this.onNavigateToAddStation,
  });

  @override
  State<MyAccountScreen> createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  Function(String) get onShowToast => widget.onShowToast;
  VoidCallback get onNavigateToAddStation => widget.onNavigateToAddStation;

  // ---------- بيانات الحساب من قاعدة البيانات ----------
  bool _loaded = false;
  Map<String, dynamic> _user = {};
  Map<String, dynamic> _stats = {};
  List<Map<String, dynamic>> _stations = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = Session.userId;
    if (uid == null) return;
    try {
      final p = await ApiService.getUserProfile(uid);
      _user = asMap(p['user']);
      _stats = asMap(p['stats']);
      _stations = asList(p['stations']);
      _loaded = true;
    } catch (_) {}
    if (mounted) setState(() {});
  }

  String get _type => toStr(_user['user_type'], Session.userType);
  String get _name => !_loaded ? 'الكابتن تركي بن عبدالله العتيبي' : toStr(_user['manager_name'], toStr(_user['full_name']));
  String get _org {
    if (!_loaded) return 'حملة أنوار المشاعر لخدمات المعتمرين وحجاج بيت الله';
    switch (_type) {
      case 'CAMPAIGN':
        return toStr(_user['full_name']);
      case 'OWNER':
        return 'مالك ${_stations.length} محطة مسجلة في شبكة راحة ضيف';
      case 'ADMIN':
        return 'إدارة منصة راحة ضيف';
      default:
        return 'ضيف الرحمن — ${toStr(_user['email'])}';
    }
  }

  String get _licenseBadge {
    if (!_loaded) return 'رخصة نقل: 489201';
    if (_type == 'CAMPAIGN') return 'ترخيص الحملة: ${toStr(_user['license_no'], 'غير مسجل')}';
    if (_type == 'OWNER') return 'س.ت: ${_stations.isEmpty ? 'غير مسجل' : toStr(_stations.first['commercial_reg'], 'غير مسجل')}';
    return toStr(_user['email']);
  }

  bool get _docsComplete {
    if (_type == 'CAMPAIGN') return toStr(_user['license_no']).isNotEmpty && toStr(_user['phone']).isNotEmpty;
    if (_type == 'OWNER') return _stations.isNotEmpty && _stations.every((s) => RegExp(r'^\d{10}$').hasMatch(toStr(s['commercial_reg'])));
    return toStr(_user['phone']).isNotEmpty;
  }

  /// تاريخ انتهاء اشتراك المحطة
  DateTime? get _renewsAt => toDate(_user['subscription_expires_at']) ?? (_stations.isNotEmpty ? toDate(_stations.first['renews_at']) : null);

  String get _subscriptionLine {
    if (!_loaded) return 'صالحة حتى 30 ذو الحجة 1445هـ (متبقي 240 يوماً)';
    final d = _renewsAt;
    if (_type != 'OWNER' || d == null) return 'لا يوجد اشتراك محطة — سجّل محطتك للانضمام كشريك';
    final days = dateOnly(d).difference(dateOnly(DateTime.now())).inDays;
    return days >= 0 ? 'صالحة حتى ${fmtDate(d)} (متبقي $days يوماً)' : 'انتهت في ${fmtDate(d)} — يلزم التجديد';
  }

  String get _planPill {
    if (!_loaded) return 'باقة سنوية نشطة';
    if (_type != 'OWNER' || _stations.isEmpty) return 'غير مشترك';
    final s = _stations.first;
    return 'باقة ${toStr(s['plan_name'], 'أساسية')} ${toStr(s['billing_cycle']) == 'MONTHLY' ? 'شهرية' : 'سنوية'}';
  }

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF0E4436);
    const secondaryColor = Color(0xFF765A00);
    const secondaryContainer = Color(0xFFFECE50);
    const secondaryFixed = Color(0xFFFFDF96);
    const onPrimary = Colors.white;
    const surfaceContainerLow = Color(0xFFF6F3F2);
    const surfaceContainerHigh = Color(0xFFEAE7E7);
    const onSurface = Color(0xFF1B1C1C);
    const onSurfaceVariant = Color(0xFF404945);

    return Scaffold(
      backgroundColor: const Color(0xFFFCF9F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF9F8).withOpacity(0.85),
        elevation: 0,
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.mosque, color: primaryColor, size: 20),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'راحة ضيف',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: primaryColor),
                ),
                Text(
                  'منصة خدمة حافلات المعتمرين',
                  style: TextStyle(fontSize: 10, color: onSurfaceVariant),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: onSurfaceVariant, size: 22),
            onPressed: () => onShowToast("لا توجد إشعارات جديدة"),
            tooltip: 'الإشعارات',
          ),
          const Padding(
            padding: EdgeInsets.only(left: 16.0),
            child: CircleAvatar(
              radius: 16,
              backgroundImage: NetworkImage(
                'https://lh3.googleusercontent.com/aida/AEtjO1XnqM0nV_90wtxn8gBzctsKEAKfKnVVrcZjey1WAAZs6SBedREwp9dU2TrBuCxKTmnkMSOiVxyGA4F5qBIHmVM7kgfQJbBycTjD45V9d7UjAB1OlsxnaWqyW3DEhL1Pud-TkVTsPXEtkzQ9y9owqJnqmhGG2nYuFNN5RijD2y0q3Pypq-FQwX8_qLikqHAIICccM5f8G0VVkCxKhfO0Y2sohOJgD5RgCvydl_HCPeAoAOHQvr4V3Xsk8RIZ6AdJKjPc0qdDUwY6RQ',
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            
            // Profile Header Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                children: [
                  // Avatar with Nafath & Role Badges
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 96,
                        height: 96,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: surfaceContainerHigh,
                          shape: BoxShape.circle,
                          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: Image.network(
                            'https://lh3.googleusercontent.com/aida-public/AB6AXuBJJbFmZoFCZfYjQ9knqADmGkyZhKtFc6abvHkZOQ-RCDZhH18k9hUmeQ4CINyQhHuHNSB74TnV4QXNq848voo0XKL-Klcf6J_GqyUcs7JO8LXav0FAkfJkHav3uNNsvbbUtJbBOjKTPQNO2v47luw9Y8wSru8kn3px-pADbL1ogCyeq0Amho5bQdH9s9eNRK3cUnKTE_tItT0oRlfVO0XHbBWzt3sQTd6YDo5tTAvv27wosbNMM1AbEQ',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      // Nafath Verified Badge
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: primaryColor,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: const Icon(Icons.verified, size: 14, color: onPrimary),
                        ),
                      ),
                      // Certified Captain Pill
                      Positioned(
                        bottom: -4,
                        left: -4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: secondaryContainer,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.white, width: 2),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.military_tech, size: 12, color: Color(0xFF735800)),
                              SizedBox(width: 2),
                              Text('معتمد', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF735800))),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    _name,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: onSurface),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _org,
                    style: const TextStyle(fontSize: 12, color: primaryColor, fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  // Meta Badges Pill Row
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: surfaceContainerLow,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.phone_iphone, size: 14, color: primaryColor),
                            const SizedBox(width: 4),
                            Text(_loaded ? fmtPhone(_user['phone']?.toString()) : '+966 50 123 4567', style: const TextStyle(fontSize: 11, color: onSurfaceVariant)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: surfaceContainerLow,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.badge, size: 14, color: secondaryColor),
                            const SizedBox(width: 4),
                            Text(_licenseBadge, style: const TextStyle(fontSize: 11, color: onSurfaceVariant)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Quick Metrics Ribbon
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: surfaceContainerLow,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        if (_loaded && _type == 'OWNER') ...[
                          _buildMetricItem('${_stations.length}', 'محطات مسجلة'),
                          Container(width: 1, height: 28, color: surfaceContainerHigh),
                          _buildMetricItem('${_stations.where((s) => toStr(s['status']) != 'PENDING').length}', 'محطات معتمدة'),
                          Container(width: 1, height: 28, color: surfaceContainerHigh),
                          _buildMetricItem(fmtMoney(toDouble(_user['total_earnings']), decimals: 0), 'أرباح (ر.س)'),
                        ] else ...[
                        _buildMetricItem(_loaded ? '${toInt(_stats['completed_trips'])}' : '14', 'رحلة مكتملة'),
                        Container(width: 1, height: 28, color: surfaceContainerHigh),
                        _buildMetricItem(_loaded ? '${toInt(_stats['stations_booked'])}' : '6', 'محطات محجوزة'),
                        Container(width: 1, height: 28, color: surfaceContainerHigh),
                        _buildRatingMetricItem(_loaded ? toDouble(_user['rating'], 5).toStringAsFixed(1) : '4.9', _type == 'USER' ? 'تقييم الضيف' : 'تقييم الكابتن'),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // VIP Subscription Golden Pass
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [secondaryContainer, secondaryFixed, Color(0xFFFEE285)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: onSurface.withOpacity(0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.storefront, size: 18, color: onSurface),
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'اشتراك شركاء المحطات المعتمدة',
                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: onSurface),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: primaryColor,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(_planPill, style: const TextStyle(fontSize: 10, color: onPrimary, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text('ترخيص سنوي معتمد عبر منصة راحة ضيف', style: TextStyle(fontSize: 11, color: onSurfaceVariant)),
                  const SizedBox(height: 2),
                  Text(
                    _subscriptionLine,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: onSurface),
                  ),
                  const SizedBox(height: 12),
                  // Partner Benefits Checklist
                  Column(
                    children: [
                      _buildCheckBenefit('إدراج محطتك في الخريطة الرقمية'),
                      const SizedBox(height: 4),
                      _buildCheckBenefit('تحصيل أرباح الوجبات والمواقف بنسبة 85% مع تحويل تلقائي'),
                      const SizedBox(height: 4),
                      _buildCheckBenefit('لوحة تحكم فورية لإدارة الحجوزات والطلبات المباشرة'),
                      const SizedBox(height: 4),
                      _buildCheckBenefit('شعار وشهادة محطة معتمدة من راحة ضيف وهيئة النقل'),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    height: 44,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor,
                        foregroundColor: onPrimary,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: onNavigateToAddStation,
                      icon: const Icon(Icons.add_business, size: 18),
                      label: const Text('إدارة وتجديد اشتراك المحطة / إضافة محطة جديدة', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Profile & Vehicle Management List
            const Text(
              'البيانات والمحطات المسجلة',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: onSurface),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                children: [
                  _buildListItem(
                    icon: Icons.badge,
                    iconBg: primaryColor.withOpacity(0.1),
                    iconColor: primaryColor,
                    title: 'وثائق الكابتن والحملة',
                    subtitle: !_loaded
                        ? 'الهوية، رخصة القيادة الثقيلة، السجل التجاري'
                        : _type == 'CAMPAIGN'
                            ? 'ترخيص وزارة الحج والعمرة: ${toStr(_user['license_no'], 'غير مسجل')} • الجوال: ${fmtPhone(_user['phone']?.toString())}'
                            : _type == 'OWNER'
                                ? 'السجل التجاري لكل محطة وبطاقة تشغيل المنشأة'
                                : 'البريد: ${toStr(_user['email'])} • الجوال: ${fmtPhone(_user['phone']?.toString())}',
                    badge: !_loaded || _docsComplete ? 'مكتمل' : 'ناقص',
                    onTap: () => onShowToast(!_loaded || _docsComplete ? "جميع الوثائق مكتملة" : "يرجى استكمال الوثائق الناقصة عبر مركز الدعم"),
                  ),
                  const Divider(height: 1, color: surfaceContainerHigh),
                  _buildListItem(
                    icon: Icons.ev_station,
                    iconBg: secondaryFixed.withOpacity(0.6),
                    iconColor: secondaryColor,
                    title: 'محطاتي المسجلة في راحة ضيف',
                    subtitle: !_loaded
                        ? 'محطة واحة النخيل (طريق الهجرة - نشطة ومعتمدة)'
                        : _type == 'OWNER'
                            ? (_stations.isEmpty
                                ? 'لا توجد محطات مسجلة بعد'
                                : _stations.map((s) => '${toStr(s['app_title'], toStr(s['name']))} (${toStr(s['status']) == 'PENDING' ? 'قيد المراجعة' : 'معتمدة'})').join('، '))
                            : 'حجوزاتك القادمة: ${toInt(_stats['upcoming'])} • محطات زرتها: ${toInt(_stats['stations_booked'])}',
                    badge: !_loaded
                        ? 'معتمدة'
                        : _type == 'OWNER'
                            ? (_stations.any((s) => toStr(s['status']) == 'PENDING') ? 'قيد المراجعة' : (_stations.isEmpty ? '—' : 'معتمدة'))
                            : '${toInt(_stats['upcoming'])} قادم',
                    onTap: () => onShowToast(_type == 'OWNER' ? "عدد المحطات المسجلة: ${_stations.length}" : "عرض المحطات المسجلة"),
                  ),
                  const Divider(height: 1, color: surfaceContainerHigh),
                  _buildListItem(
                    icon: Icons.account_balance_wallet,
                    iconBg: primaryColor.withOpacity(0.1),
                    iconColor: primaryColor,
                    title: 'المحفظة وطرق الدفع',
                    subtitle: !_loaded ? 'مدى (**** 8820)، Apple Pay المفعّل' : (_type == 'OWNER' ? 'أرباح المحطة القابلة للتحويل للآيبان' : 'رصيد يُستخدم للحجوزات وطلبات الوجبات • ${fmtMoney(toInt(_user['loyalty_points']))} نقطة'),
                    badge: _loaded ? sar(toDouble(_user['wallet_balance'])) : '1,450 ر.س',
                    isBadgeAmount: true,
                    onTap: () => onShowToast("فتح المحفظة وطرق الدفع"),
                  ),
                  const Divider(height: 1, color: surfaceContainerHigh),
                  _buildListItem(
                    icon: Icons.notifications_active,
                    iconBg: surfaceContainerHigh,
                    iconColor: onSurface,
                    title: 'تنبيهات الطريق وحالة الازدحام',
                    subtitle: 'إشعارات مسبقة للمحطات، بلاغات الطقس',
                    onTap: () => onShowToast("إعدادات تنبيهات الطريق"),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Support, Emergency & System Safety Options
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))],
              ),
              child: Column(
                children: [
                  // Road Emergency Dispatch Banner
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: const BoxDecoration(
                                color: primaryColor,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.support_agent, size: 20, color: onPrimary),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text('طوارئ النقل وغرفة العمليات', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: onSurface)),
                                Text('فريق التدخل السريع لمسار المشاعر', style: TextStyle(fontSize: 10, color: onSurfaceVariant)),
                              ],
                            ),
                          ],
                        ),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor,
                            foregroundColor: onPrimary,
                            minimumSize: Size.zero,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          onPressed: () => onShowToast("جاري الاتصال بغرفة العمليات والطوارئ..."),
                          icon: const Icon(Icons.call, size: 14),
                          label: const Text('اتصال', style: TextStyle(fontSize: 11)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildSimpleLinkItem('مركز المساعدة والأسئلة الشائعة', Icons.help_center, () => onShowToast("فتح مركز المساعدة")),
                  const Divider(height: 1, color: surfaceContainerHigh),
                  _buildSimpleLinkItem('سياسة الخصوصية والشروط التشغيلية', Icons.verified_user, () => onShowToast("عرض سياسة الخصوصية")),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Logout Button
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFDAD6).withOpacity(0.5),
                  foregroundColor: const Color(0xFFBA1A1A),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  onShowToast("تم تسجيل الخروج بنجاح");
                  Session.clear();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                    (route) => false,
                  );
                },
                icon: const Icon(Icons.logout, size: 18),
                label: const Text('تسجيل الخروج من الحساب', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),

            // Version & Footnote
            const Center(
              child: Text(
                'تطبيق راحة ضيف للمشاعر المقدسة • الإصدار v2.4 (بناء 104)',
                style: TextStyle(fontSize: 10, color: onSurfaceVariant),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  static Widget _buildMetricItem(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0E4436))),
        Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
      ],
    );
  }

  static Widget _buildRatingMetricItem(String value, String label) {
    return Column(
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.star, size: 16, color: Color(0xFFEFC043)),
            const SizedBox(width: 2),
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1B1C1C))),
          ],
        ),
        Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF404945))),
      ],
    );
  }

  static Widget _buildCheckBenefit(String text) {
    return Row(
      children: [
        const Icon(Icons.check_circle, size: 14, color: Color(0xFF0E4436)),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text, style: const TextStyle(fontSize: 10, color: Color(0xFF1B1C1C))),
        ),
      ],
    );
  }

  static Widget _buildListItem({
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String subtitle,
    String? badge,
    bool isBadgeAmount = false,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF1B1C1C))),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 10, color: Color(0xFF404945)), overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            const SizedBox(width: 8),
            if (badge != null)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: isBadgeAmount ? Colors.transparent : const Color(0xFF0E4436).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  badge,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: isBadgeAmount ? const Color(0xFF0E4436) : const Color(0xFF0E4436),
                  ),
                ),
              ),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_left, size: 18, color: Color(0xFF404945)),
          ],
        ),
      ),
    );
  }

  static Widget _buildSimpleLinkItem(String title, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 4.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: const Color(0xFF404945)),
                const SizedBox(width: 10),
                Text(title, style: const TextStyle(fontSize: 12, color: Color(0xFF1B1C1C))),
              ],
            ),
            const Icon(Icons.chevron_left, size: 18, color: Color(0xFF404945)),
          ],
        ), 
      ),
    );
  }
}

// ============================================================================
// أدوات الربط مع قاعدة البيانات (مشتركة بين الشاشات)
// ============================================================================

/// المحطة المختارة لعرض تفاصيلها (تُضبط عند الضغط على "عرض تفاصيل المحطة")
Station? selectedStation;

/// المحطة المختارة للحجز (تُضبط عند الضغط على زر "حجز" وتُقرأ في صفحة حجوزاتي)
Station? bookingTargetStation;

void showAppToast(BuildContext context, String message, {bool error = false}) {
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (messenger == null) return;
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      content: Row(
        children: [
          Icon(error ? Icons.error_outline : Icons.check_circle, color: const Color(0xFFEFC043), size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: Colors.white),
            ),
          ),
        ],
      ),
      backgroundColor: error ? const Color(0xFF93000A) : const Color(0xFF0E4436),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.only(top: 50, left: 16, right: 16),
      duration: Duration(seconds: error ? 4 : 2),
    ),
  );
}

/// فتح تفاصيل المحطة كصفحة مستقلة (لصاحب المحطة ومدير التطبيق)
void openDetailsRoute(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (ctx) => StationDetailsScreen(
        onShowToast: (m) => showAppToast(ctx, m),
        onNavigateBack: () => Navigator.pop(ctx),
        onNavigateToBookings: () => showAppToast(ctx, 'الحجز متاح لأصحاب الحملات وضيوف الرحمن'),
      ),
    ),
  );
}

String fmtMoney(num v, {int decimals = 2}) {
  final neg = v < 0;
  final parts = v.abs().toStringAsFixed(decimals).split('.');
  final intPart = parts[0].replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  final frac = parts.length > 1 ? parts[1] : '';
  final showFrac = frac.isNotEmpty && int.parse(frac) != 0;
  return '${neg ? '-' : ''}$intPart${showFrac ? '.$frac' : ''}';
}

String sar(num v) => '${fmtMoney(v)} ر.س';

DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

const List<String> _arMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

String fmtDate(DateTime? d) => d == null ? '—' : '${d.day} ${_arMonths[d.month - 1]} ${d.year}';

String hhmm(TimeOfDay t) => '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

/// "16:30" → "04:30 م" (القيم الأخرى تُعرض كما هي)
String arTime(String raw) {
  final m = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(raw.trim());
  if (m == null) return raw;
  var h = int.parse(m.group(1)!);
  final suffix = h >= 12 ? 'م' : 'ص';
  h = h % 12;
  if (h == 0) h = 12;
  return '${h.toString().padLeft(2, '0')}:${m.group(2)} $suffix';
}

String relativeTime(DateTime? d) {
  if (d == null) return '';
  final diff = DateTime.now().difference(d);
  if (diff.inMinutes < 1) return 'الآن';
  if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
  if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
  if (diff.inDays < 30) return 'منذ ${diff.inDays} يوم';
  return fmtDate(d);
}

/// 0501234567 → +966 50 123 4567
String fmtPhone(String? p) {
  final d = (p ?? '').replaceAll(RegExp(r'\D'), '');
  if (d.length == 10 && d.startsWith('05')) return '+966 ${d.substring(1, 3)} ${d.substring(3, 6)} ${d.substring(6)}';
  if (d.length == 12 && d.startsWith('9665')) return '+966 ${d.substring(3, 5)} ${d.substring(5, 8)} ${d.substring(8)}';
  return (p == null || p.trim().isEmpty) ? 'جوال غير مسجل' : p;
}

String nameInitials(String name) {
  final parts = name.split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
  if (parts.isEmpty) return 'ض';
  if (parts.length == 1) return parts.first.characters.first;
  return '${parts[0].characters.first}.${parts[1].characters.first}';
}

IconData serviceIcon(String n) {
  if (n.contains('مصلى')) return Icons.mosque;
  if (n.contains('دورات')) return Icons.wc;
  if (n.contains('مطعم') || n.contains('مطاعم')) return Icons.restaurant;
  if (n.contains('مقه')) return Icons.local_cafe;
  if (n.contains('وقود')) return Icons.local_gas_station;
  if (n.contains('غسيل')) return Icons.local_car_wash;
  if (n.contains('صيانة')) return Icons.build;
  if (n.contains('مواقف')) return Icons.local_parking;
  if (n.contains('استراحة')) return Icons.airline_seat_recline_normal;
  if (n.contains('إسعاف') || n.contains('صحي') || n.contains('عيادة')) return Icons.medical_services;
  if (n.contains('صيدلية')) return Icons.local_pharmacy;
  if (n.contains('صراف')) return Icons.atm;
  if (n.contains('واي')) return Icons.wifi;
  if (n.contains('شحن')) return Icons.ev_station;
  if (n.contains('فندق') || n.contains('غرف') || n.contains('شقق')) return Icons.hotel;
  if (n.contains('نقل')) return Icons.airport_shuttle;
  if (n.contains('تموينات') || n.contains('متاجر') || n.contains('تسوق')) return Icons.shopping_bag_outlined;
  if (n.contains('ألعاب')) return Icons.child_care;
  if (n.contains('أمتعة')) return Icons.luggage;
  if (n.contains('طوارئ')) return Icons.emergency;
  if (n.contains('معلومات') || n.contains('عملاء')) return Icons.support_agent;
  if (n.contains('حركة')) return Icons.accessible;
  if (n.contains('جلسات')) return Icons.deck;
  return Icons.check_circle_outline;
}

String serviceDescription(String n) {
  if (n.contains('مصلى')) return 'مصلى مكيف للرجال والنساء قريب من مواقف الحافلات';
  if (n.contains('دورات')) return 'دورات مياه بتنظيف وتعقيم دوري';
  if (n.contains('مطعم') || n.contains('مطاعم')) return 'وجبات ساخنة ومياه مبردة • يستقبل طلبات وجبات الحملات';
  if (n.contains('مقه')) return 'مشروبات ساخنة وباردة';
  if (n.contains('وقود')) return 'تزويد وقود الديزل للحافلات';
  if (n.contains('صيانة') || n.contains('غسيل')) return 'خدمة فنية للحافلات أثناء التوقف';
  if (n.contains('مواقف')) return 'مواقف حافلات قابلة للحجز المسبق عبر التطبيق';
  if (n.contains('استراحة')) return 'جلسات انتظار مكيفة للركاب والسائقين';
  if (n.contains('إسعاف') || n.contains('صحي') || n.contains('عيادة') || n.contains('طوارئ')) return 'رعاية أولية وحالات الإجهاد الحراري';
  if (n.contains('صيدلية')) return 'أدوية ومستلزمات طبية أساسية';
  if (n.contains('صراف')) return 'سحب نقدي ونقاط بيع مدى';
  if (n.contains('حركة')) return 'مسارات مهيأة لكبار السن وذوي الإعاقة';
  return 'خدمة متوفرة في المحطة';
}

/// نموذج المحطة — كل الأرقام محسوبة من بيانات rd_rest_stops
class Station {
  final Map<String, dynamic> raw;
  Station(this.raw);

  static const Set<String> _genericServices = {'وقود', 'مصلى', 'دورات مياه', 'مطعم', 'مواقف', 'استراحة', 'صيانة حافلات', 'غرف', 'شقق'};

  int get id => toInt(raw['rest_stop_id']);
  String get title => toStr(raw['app_title'], toStr(raw['name'], 'محطة'));
  String get city => toStr(raw['city']);
  String get shortCity => city == 'مكة المكرمة' ? 'مكة' : city;
  String get highway => toStr(raw['highway_name']);
  String get area => toStr(raw['address_label'], toStr(raw['highway_name'], city));
  double get rating => toDouble(raw['rating'] ?? raw['avg_rating']);
  int get reviewsCount => toInt(raw['reviews_count']);
  double get occupancy => toDouble(raw['occupancy_percentage']).clamp(0, 100).toDouble();
  double? get distanceKm => raw['distance_km'] == null ? null : toDouble(raw['distance_km']);
  String? get image => raw['image_asset'] == null || toStr(raw['image_asset']).isEmpty ? null : raw['image_asset'].toString();
  bool get isPending => toStr(raw['status']) == 'PENDING';
  int get activeBookings => toInt(raw['active_bookings']);
  double? get lat => raw['latitude'] == null ? null : toDouble(raw['latitude']);
  double? get lng => raw['longitude'] == null ? null : toDouble(raw['longitude']);

  String get openLabel {
    final t = toStr(raw['open_time'], '24/7');
    if (t == '24/7') return 'مفتوح على مدار الساعة';
    final m = RegExp(r'^(\d{2})(\d{2})-(\d{2})(\d{2})$').firstMatch(t);
    if (m == null) return 'ساعات العمل: $t';
    return 'من ${arTime('${m[1]}:${m[2]}')} إلى ${arTime('${m[3]}:${m[4]}')}';
  }

  List<String> get services {
    final s = raw['services'];
    if (s is List) return s.map((e) => e.toString()).toList();
    final str = toStr(s);
    if (str.isEmpty) return [];
    return str.split(RegExp(r'[|،,]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }

  /// الخدمات المميزة للبطاقة (حتى 3)
  List<String> get highlightServices {
    final all = services;
    final special = all.where((x) => !_genericServices.contains(x)).toList();
    final rest = all.where((x) => _genericServices.contains(x)).toList();
    return [...special, ...rest].take(special.length >= 2 ? 3 : 2).toList();
  }

  /// السعة الكلية لمواقف الحافلات
  int get capacity {
    final c = toInt(raw['bus_capacity']);
    if (c > 0) return c;
    if (raw['vacant_spots'] != null && occupancy < 100) return (toInt(raw['vacant_spots']) / (1 - occupancy / 100)).round();
    return 0;
  }

  int get vacantSpots {
    if (raw['vacant_spots'] != null) return toInt(raw['vacant_spots']);
    return (capacity * (1 - occupancy / 100)).round();
  }

  int get occupiedSpots => (capacity - vacantSpots).clamp(0, capacity).toInt();

  String get crowdLabel => occupancy < 40 ? 'حركة خفيفة' : occupancy < 75 ? 'حركة متوسطة' : 'ازدحام';

  String get locationPill =>
      distanceKm != null ? '$shortCity • ${fmtMoney(distanceKm!, decimals: 0)} كم' : '$shortCity • ${highway.isNotEmpty ? highway : area}';

  String get vacancyLabel {
    final v = (100 - occupancy).round();
    final word = v >= 70 ? 'رحابة عالية' : v >= 50 ? 'متاح' : v >= 30 ? 'معتدل' : 'مزدحم';
    return 'شاغر $v% ($word)';
  }

  Color get barColor => occupancy < 50 ? const Color(0xFF0E4436) : const Color(0xFF765A00);
}