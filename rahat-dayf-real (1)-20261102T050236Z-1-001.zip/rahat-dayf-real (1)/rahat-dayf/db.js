'use strict';
// قاعدة البيانات: SQLite المدمجة في Node (بدون حزم خارجية). يلزم Node 22.5 أو أحدث.
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA, { recursive: true });
const db = new DatabaseSync(path.join(DATA, 'rahat.sqlite'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');

// ---------- كلمات المرور (scrypt + ملح عشوائي) ----------
function hashPw(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(pw), salt, 64);
  return 'scrypt$' + salt.toString('hex') + '$' + h.toString('hex');
}
function verifyPw(pw, stored) {
  const [alg, s, h] = String(stored).split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const calc = crypto.scryptSync(String(pw), Buffer.from(s, 'hex'), 64);
  const want = Buffer.from(h, 'hex');
  return want.length === calc.length && crypto.timingSafeEqual(calc, want);
}

// ---------- المعاملات (Transactions) ----------
function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) {}
    throw e;
  }
}

// ---------- الجداول ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  role TEXT NOT NULL CHECK(role IN ('ADMIN','OWNER','CAMPAIGN','USER')),
  pw TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0),
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plans(code TEXT PRIMARY KEY, monthly REAL NOT NULL, yearly REAL NOT NULL);
CREATE TABLE IF NOT EXISTS stations(
  id INTEGER PRIMARY KEY,
  owner_id INTEGER REFERENCES users(id),
  name TEXT NOT NULL UNIQUE,
  city TEXT NOT NULL,
  area TEXT,
  load INTEGER NOT NULL DEFAULT 0 CHECK(load BETWEEN 0 AND 100),
  visible INTEGER NOT NULL DEFAULT 1 CHECK(visible IN (0,1)),
  plan TEXT NOT NULL DEFAULT 'basic' REFERENCES plans(code),
  billing TEXT NOT NULL DEFAULT 'MONTHLY' CHECK(billing IN ('MONTHLY','YEARLY'))
);
CREATE TABLE IF NOT EXISTS station_services(
  station_id INTEGER NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
  service TEXT NOT NULL,
  PRIMARY KEY(station_id, service)
);
CREATE TABLE IF NOT EXISTS booking_types(service TEXT PRIMARY KEY, label TEXT NOT NULL, price REAL NOT NULL CHECK(price > 0));
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  station_id INTEGER NOT NULL REFERENCES stations(id),
  user_id INTEGER REFERENCES users(id),
  service TEXT NOT NULL REFERENCES booking_types(service),
  price REAL NOT NULL,
  arrival TEXT,
  people INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS meals(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL CHECK(price > 0), active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS meal_orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  campaign_id INTEGER NOT NULL REFERENCES users(id),
  station_id INTEGER NOT NULL REFERENCES stations(id),
  meal_name TEXT NOT NULL,
  qty INTEGER NOT NULL CHECK(qty > 0),
  total REAL NOT NULL,
  status INTEGER NOT NULL DEFAULT 0 CHECK(status IN (0,1,2)),
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS wallets(user_id INTEGER PRIMARY KEY REFERENCES users(id), balance REAL NOT NULL DEFAULT 0 CHECK(balance >= 0));
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  amount REAL NOT NULL,
  reason TEXT NOT NULL,
  ref TEXT,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  station_id INTEGER NOT NULL REFERENCES stations(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id),
  name TEXT NOT NULL,
  stars INTEGER NOT NULL CHECK(stars BETWEEN 1 AND 5),
  text TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  seeded INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_review_once ON reviews(station_id, user_id) WHERE user_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS rewards(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, cost INTEGER NOT NULL CHECK(cost > 0));
CREATE TABLE IF NOT EXISTS redemptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  reward_id INTEGER NOT NULL REFERENCES rewards(id),
  code TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS payouts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  station_id INTEGER NOT NULL REFERENCES stations(id),
  amount REAL NOT NULL CHECK(amount > 0),
  status INTEGER NOT NULL DEFAULT 0 CHECK(status IN (0,1)),
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS ix_bookings_station ON bookings(station_id);
CREATE INDEX IF NOT EXISTS ix_orders_station ON meal_orders(station_id);
CREATE INDEX IF NOT EXISTS ix_orders_campaign ON meal_orders(campaign_id);
CREATE INDEX IF NOT EXISTS ix_reviews_station ON reviews(station_id);
`);

// ---------- البيانات الأولية (تُنفَّذ مرة واحدة فقط على قاعدة فارغة) ----------
const DAYS = { 'اليوم': 0, 'أمس': 1, 'قبل يومين': 2, 'قبل 3 أيام': 3, 'قبل 4 أيام': 4, 'قبل 5 أيام': 5, 'قبل أسبوع': 7, 'قبل أسبوعين': 14, 'قبل شهر': 30 };
const rnd = (n) => crypto.randomBytes(n).toString('base64url');

function seedIfEmpty() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return null;
  const seed = JSON.parse(fs.readFileSync(path.join(__dirname, 'seed.json'), 'utf8'));
  const demo = process.env.SEED_DEMO !== '0';
  const adminEmail = (process.env.ADMIN_EMAIL || 'admin@rahatdayf.sa').toLowerCase();
  const adminPw = process.env.ADMIN_PASSWORD || rnd(10);
  const demoPw = process.env.DEMO_PASSWORD || rnd(10);
  const now = Math.floor(Date.now() / 1000);
  const creds = [];

  tx(() => {
    const ins = (sql, ...a) => db.prepare(sql).run(...a);
    ins("INSERT INTO plans VALUES ('basic',299,2990)");
    ins("INSERT INTO plans VALUES ('plus',599,5990)");
    ins("INSERT INTO plans VALUES ('gold',999,9990)");
    ins("INSERT INTO settings VALUES ('BOOKING_COMMISSION_PCT',8)");
    ins("INSERT INTO settings VALUES ('MEAL_COMMISSION_PCT',10)");
    [['غرف', 'غرفة فندقية (ليلة)', 250], ['شقق', 'شقة مفروشة (ليلة)', 420], ['مواقف', 'موقف حافلة محجوز', 120], ['استراحة', 'جلسة استراحة', 40]]
      .forEach((b) => ins('INSERT INTO booking_types VALUES (?,?,?)', ...b));
    [['وجبة غداء', 25], ['وجبة إفطار صائم', 14], ['وجبة خفيفة للطريق', 10]].forEach((m) => ins('INSERT INTO meals(name,price) VALUES (?,?)', ...m));
    [['خصم 10% على الوجبات', 100], ['خصم 15 ريال على الوقود', 200], ['مشروب مجاني', 60]].forEach((r) => ins('INSERT INTO rewards(title,cost) VALUES (?,?)', ...r));

    for (const s of seed.stations) {
      ins('INSERT INTO stations(id,name,city,area,load,plan,billing) VALUES (?,?,?,?,?,?,?)', s.id, s.name, s.city, s.area, s.load, s.plan, s.bill);
      for (const sv of s.sv) ins('INSERT INTO station_services VALUES (?,?)', s.id, sv);
    }

    const addUser = (name, email, role, pw, points = 0) => {
      const id = Number(ins('INSERT INTO users(name,email,role,pw,points) VALUES (?,?,?,?,?)', name, email, role, hashPw(pw), points).lastInsertRowid);
      creds.push(`${role.padEnd(9)} ${email}  ${pw}`);
      return id;
    };
    addUser('إدارة راحة ضيف', adminEmail, 'ADMIN', adminPw);

    if (demo) {
      const owner = addUser('مالك محطة جبل الكعبة', 'owner@jabalkaaba.sa', 'OWNER', demoPw);
      ins('UPDATE stations SET owner_id=? WHERE id=0', owner);
      const c1 = addUser('حملة الوفاء للمعتمرين', 'campaign@wafaa.sa', 'CAMPAIGN', demoPw);
      const c2 = addUser('حملة ضيوف الرحمن', 'campaign2@diyouf.sa', 'CAMPAIGN', demoPw);
      addUser('ضيف راحة', 'guest@mail.com', 'USER', demoPw, 120);
      const camp = { 'حملة الوفاء للمعتمرين': c1, 'حملة ضيوف الرحمن': c2 };
      const spent = { [c1]: 0, [c2]: 0 };
      for (const o of seed.orders) {
        const cid = camp[o.camp];
        ins('INSERT INTO meal_orders(code,campaign_id,station_id,meal_name,qty,total,status,created_at) VALUES (?,?,?,?,?,?,?,?)', o.id, cid, o.st, o.meal, o.q, o.tot, o.s, now - 86400 * 3);
        spent[cid] += o.tot;
      }
      for (const cid of [c1, c2]) {
        ins('INSERT INTO wallets VALUES (?,?)', cid, 10000 - spent[cid]);
        ins('INSERT INTO ledger(user_id,amount,reason,ref) VALUES (?,?,?,?)', cid, 10000, 'رصيد افتتاحي تجريبي', 'OPENING');
        if (spent[cid]) ins('INSERT INTO ledger(user_id,amount,reason,ref) VALUES (?,?,?,?)', cid, -spent[cid], 'طلبات وجبات سابقة', 'HISTORY');
      }
      for (const b of seed.bookings) {
        ins('INSERT INTO bookings(code,station_id,service,price,arrival,people,created_at) VALUES (?,?,?,?,?,?,?)', b.id, b.sid, b.type, b.price, b.t, b.p, now - 86400 * 2);
      }
      for (const p of seed.payouts) {
        const st = db.prepare('SELECT id FROM stations WHERE name=?').get(p.st);
        if (st.id === 0) continue; // محطة الحساب التجريبي لصاحب المحطة تبدأ بدون طلبات تحويل
        ins('INSERT INTO payouts(code,station_id,amount,status,created_at) VALUES (?,?,?,?,?)', p.id, st.id, p.amt, p.s, now - 86400 * 5);
      }
      for (const r of seed.reviews) {
        ins('INSERT INTO reviews(station_id,name,stars,text,created_at,seeded) VALUES (?,?,?,?,?,1)', r.st, r.name, r.stars, r.text, now - 86400 * (DAYS[r.d] ?? 0) - 3600);
      }
    }
  });

  const file = path.join(DATA, 'initial-credentials.txt');
  fs.writeFileSync(file, 'بيانات الدخول الأولية (احذف هذا الملف بعد حفظها وغيّر كلمات المرور)\n\n' + creds.join('\n') + '\n', { mode: 0o600 });
  console.log('\n=== تم إنشاء قاعدة البيانات لأول مرة ===');
  console.log(creds.join('\n'));
  console.log('(محفوظة أيضًا في ' + file + ')\n');
  return creds;
}

module.exports = { db, hashPw, verifyPw, tx, seedIfEmpty, DATA };
