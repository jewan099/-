'use strict';
// خادم راحة ضيف — بدون حزم خارجية (http + node:sqlite). يلزم Node 22.5 أو أحدث.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { db, hashPw, verifyPw, tx, seedIfEmpty, DATA } = require('./db');

seedIfEmpty();

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');
const SESSION_DAYS = 7;
const REMEMBER_DAYS = 30;

// ---------- مفتاح توقيع الجلسات ----------
function loadSecret() {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) return process.env.SESSION_SECRET;
  const f = path.join(DATA, 'session.secret');
  try { return fs.readFileSync(f, 'utf8').trim(); } catch (_) {}
  const s = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}
const SECRET = loadSecret();

const b64 = (b) => Buffer.from(b).toString('base64url');
const sign = (p) => crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
function makeToken(uid, days = SESSION_DAYS) {
  const p = b64(JSON.stringify({ u: uid, e: Date.now() + days * 86400000 }));
  return p + '.' + sign(p);
}
function readToken(tok) {
  if (!tok || tok.indexOf('.') < 0) return null;
  const [p, s] = tok.split('.');
  const want = Buffer.from(sign(p));
  const got = Buffer.from(String(s));
  if (want.length !== got.length || !crypto.timingSafeEqual(want, got)) return null;
  try {
    const d = JSON.parse(Buffer.from(p, 'base64url').toString());
    return d.e > Date.now() ? d.u : null;
  } catch (_) { return null; }
}
function cookies(req) {
  const o = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) o[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return o;
}
function setSession(req, res, uid, remember) {
  const days = remember ? REMEMBER_DAYS : SESSION_DAYS;
  const secure = req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === '1';
  res.setHeader('Set-Cookie', `rd_session=${makeToken(uid, days)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${days * 86400}${secure ? '; Secure' : ''}`);
}
function clearSession(res) {
  res.setHeader('Set-Cookie', 'rd_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
}
const currentUser = (req) => {
  const uid = readToken(cookies(req).rd_session);
  return uid ? db.prepare('SELECT id,name,email,role,points FROM users WHERE id=?').get(uid) || null : null;
};

// ---------- تحديد المحاولات ----------
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const h = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (h.length >= max) { hits.set(key, h); return true; }
  h.push(now); hits.set(key, h);
  return false;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some((t) => now - t < 3600000)) hits.delete(k); }, 600000).unref();
const clientIp = (req) => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

// ---------- أدوات ----------
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const bad = (msg, code = 400) => { throw new HttpError(code, msg); };
const money = (n) => Math.round(Number(n) * 100) / 100;
const setting = (k) => db.prepare('SELECT v FROM settings WHERE k=?').get(k).v;
const code = (p) => p + '-' + crypto.randomInt(10000, 100000);
const isInt = (n, a, b) => Number.isInteger(n) && n >= a && n <= b;
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const ARRIVALS = ['الآن', 'بعد ساعة', 'بعد ساعتين', 'مساءً'];
function ageLabel(ts) {
  const d = Math.floor((Date.now() / 1000 - ts) / 86400);
  if (d <= 0) return 'اليوم';
  if (d === 1) return 'أمس';
  if (d === 2) return 'قبل يومين';
  if (d < 7) return 'قبل ' + d + ' أيام';
  if (d < 14) return 'قبل أسبوع';
  if (d < 30) return 'قبل أسبوعين';
  return 'قبل شهر أو أكثر';
}

// ---------- بناء حالة الواجهة حسب الدور ----------
function stationsOut() {
  const rows = db.prepare('SELECT * FROM stations ORDER BY id').all();
  const sv = {};
  for (const r of db.prepare('SELECT station_id,service FROM station_services ORDER BY rowid').all()) (sv[r.station_id] ||= []).push(r.service);
  return rows.map((s) => ({ id: s.id, name: s.name, city: s.city, area: s.area, load: s.load, on: s.visible, plan: s.plan, bill: s.billing === 'YEARLY' ? 'سنوي' : 'شهري', sv: sv[s.id] || [] }));
}
const bookingOut = (b, mine) => ({ id: b.code, sid: b.station_id, st: b.station_name, type: b.service, price: b.price, t: b.arrival, p: b.people, mine });
const BK_SQL = 'SELECT b.*, s.name station_name FROM bookings b JOIN stations s ON s.id=b.station_id';
const ORD_SQL = 'SELECT o.*, u.name camp FROM meal_orders o JOIN users u ON u.id=o.campaign_id';
const orderOut = (o) => ({ id: o.code, camp: o.camp, st: o.station_id, meal: o.meal_name, q: o.qty, tot: o.total, s: o.status });
const PAY_SQL = 'SELECT p.*, s.name station_name FROM payouts p JOIN stations s ON s.id=p.station_id';
const payoutOut = (p) => ({ id: p.code, st: p.station_name, amt: p.amount, s: p.status });

function ownerAvailable(stationId) {
  const comm = setting('BOOKING_COMMISSION_PCT'), mcomm = setting('MEAL_COMMISSION_PCT');
  const b = db.prepare('SELECT COALESCE(SUM(price),0) t FROM bookings WHERE station_id=?').get(stationId).t;
  const m = db.prepare('SELECT COALESCE(SUM(total),0) t FROM meal_orders WHERE station_id=? AND status=2').get(stationId).t;
  const out = db.prepare('SELECT COALESCE(SUM(amount),0) t FROM payouts WHERE station_id=?').get(stationId).t;
  return Math.max(0, money(b * (1 - comm / 100) + m * (1 - mcomm / 100) - out));
}

function buildState(u) {
  const S = {
    me: { id: u.id, name: u.name, email: u.email, role: u.role },
    own: -1,
    comm: setting('BOOKING_COMMISSION_PCT'),
    mcomm: setting('MEAL_COMMISSION_PCT'),
    stations: stationsOut(),
    meals: db.prepare('SELECT id,name n,price p FROM meals WHERE active=1 ORDER BY id').all(),
    reviews: db.prepare('SELECT station_id st,name,stars,text,created_at FROM reviews ORDER BY created_at DESC,id DESC').all()
      .map((r) => ({ st: r.st, name: r.name, stars: r.stars, text: r.text, d: ageLabel(r.created_at) })),
    bookings: [], orders: [], payouts: [], points: 0, wallet: 0, avail: 0, accounts: [],
  };
  if (u.role === 'USER') {
    S.points = u.points;
    S.bookings = db.prepare(BK_SQL + ' WHERE b.user_id=? ORDER BY b.id DESC').all(u.id).map((b) => bookingOut(b, 1));
  } else if (u.role === 'CAMPAIGN') {
    const w = db.prepare('SELECT balance FROM wallets WHERE user_id=?').get(u.id);
    S.wallet = w ? w.balance : 0;
    S.orders = db.prepare(ORD_SQL + ' WHERE o.campaign_id=? ORDER BY o.id DESC').all(u.id).map(orderOut);
  } else if (u.role === 'OWNER') {
    const st = db.prepare('SELECT id FROM stations WHERE owner_id=?').get(u.id);
    if (st) {
      S.own = st.id;
      S.bookings = db.prepare(BK_SQL + ' WHERE b.station_id=? ORDER BY b.id DESC').all(st.id).map((b) => bookingOut(b, 0));
      S.orders = db.prepare(ORD_SQL + ' WHERE o.station_id=? ORDER BY o.id DESC').all(st.id).map(orderOut);
      S.payouts = db.prepare(PAY_SQL + ' WHERE p.station_id=? ORDER BY p.id DESC').all(st.id).map(payoutOut);
      S.avail = ownerAvailable(st.id);
    }
  } else if (u.role === 'ADMIN') {
    S.bookings = db.prepare(BK_SQL + ' ORDER BY b.id DESC').all().map((b) => bookingOut(b, 0));
    S.orders = db.prepare(ORD_SQL + ' ORDER BY o.id DESC').all().map(orderOut);
    S.payouts = db.prepare(PAY_SQL + ' ORDER BY p.id DESC').all().map(payoutOut);
    S.accounts = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.points,w.balance,
        (SELECT name FROM stations WHERE owner_id=u.id) station FROM users u LEFT JOIN wallets w ON w.user_id=u.id ORDER BY u.id`).all();
  }
  return S;
}

// ---------- الحسابات ----------
function createUser({ name, email, password, role }) {
  name = str(name, 60);
  email = str(email, 254).toLowerCase();
  if (name.length < 2) bad('اكتب الاسم (حرفان على الأقل)');
  if (!EMAIL.test(email)) bad('البريد الإلكتروني غير صالح');
  if (String(password || '').length < 8) bad('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
  if (String(password).length > 200) bad('كلمة المرور طويلة جدًا');
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email)) bad('هذا البريد مسجّل مسبقًا', 409);
  const id = Number(db.prepare('INSERT INTO users(name,email,role,pw) VALUES (?,?,?,?)').run(name, email, role, hashPw(password)).lastInsertRowid);
  if (role === 'CAMPAIGN') db.prepare('INSERT INTO wallets(user_id,balance) VALUES (?,0)').run(id);
  return id;
}

// ---------- المسارات ----------
const routes = {};
const route = (method, p, roles, fn) => { routes[method + ' ' + p] = { roles, fn }; };

route('POST', '/api/login', null, (req, res, u, b) => {
  const email = str(b.email, 254).toLowerCase();
  const ip = clientIp(req);
  if (limited('login|' + ip, 30, 600000) || limited('loginE|' + email, 8, 600000)) bad('محاولات كثيرة، حاول بعد 10 دقائق', 429);
  const row = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  // نفس زمن الاستجابة تقريبًا سواء وُجد الحساب أم لا
  const ok = row ? verifyPw(b.password, row.pw) : (verifyPw(b.password, 'scrypt$00$00'), false);
  if (!ok) bad('البريد أو كلمة المرور غير صحيحة', 401);
  setSession(req, res, row.id, b.remember === true);
  return { role: row.role, name: row.name };
});

route('POST', '/api/signup', null, (req, res, u, b) => {
  if (limited('signup|' + clientIp(req), 10, 3600000)) bad('محاولات كثيرة، حاول لاحقًا', 429);
  if (b.role !== 'USER' && b.role !== 'CAMPAIGN') bad('نوع الحساب غير مسموح للتسجيل الذاتي', 403);
  const id = tx(() => createUser(b));
  setSession(req, res, id, b.remember === true);
  return { role: b.role };
});

route('POST', '/api/logout', null, (req, res) => { clearSession(res); return { ok: true }; });
route('GET', '/api/state', ['ADMIN', 'OWNER', 'CAMPAIGN', 'USER'], (req, res, u) => buildState(u));

// --- المستخدم ---
route('POST', '/api/booking', ['USER'], (req, res, u, b) => tx(() => {
  const station = Number(b.station), service = str(b.service, 30), time = str(b.time, 30), people = Number(b.people);
  if (!ARRIVALS.includes(time)) bad('وقت الوصول غير صالح');
  if (!isInt(people, 1, 50)) bad('عدد الأفراد غير صالح');
  const row = db.prepare(`SELECT bt.price, s.name FROM stations s
      JOIN station_services ss ON ss.station_id=s.id JOIN booking_types bt ON bt.service=ss.service
      WHERE s.id=? AND s.visible=1 AND ss.service=?`).get(station, service);
  if (!row) bad('هذه الخدمة غير متوفرة في المحطة المختارة');
  const today = db.prepare("SELECT COUNT(*) c FROM bookings WHERE user_id=? AND created_at > strftime('%s','now')-86400").get(u.id).c;
  if (today >= 10) bad('وصلت للحد اليومي للحجوزات (10)', 429);
  const c = code('RD');
  db.prepare('INSERT INTO bookings(code,station_id,user_id,service,price,arrival,people) VALUES (?,?,?,?,?,?,?)').run(c, station, u.id, service, row.price, time, people);
  db.prepare('UPDATE users SET points=points+50 WHERE id=?').run(u.id);
  return { booking: { id: c, sid: station, st: row.name, type: service, price: row.price, t: time, p: people, mine: 1 } };
}));

route('POST', '/api/review', ['USER'], (req, res, u, b) => tx(() => {
  const station = Number(b.st), stars = Number(b.stars), text = str(b.text, 200), name = str(b.name, 30) || 'ضيف راحة';
  if (!db.prepare('SELECT 1 FROM stations WHERE id=? AND visible=1').get(station)) bad('المحطة غير موجودة');
  if (!isInt(stars, 1, 5)) bad('اختر تقييمًا من 1 إلى 5');
  if (!text) bad('اكتب تعليقك أولاً');
  if (db.prepare('SELECT 1 FROM reviews WHERE station_id=? AND user_id=?').get(station, u.id)) bad('قيّمت هذه المحطة من قبل', 409);
  db.prepare('INSERT INTO reviews(station_id,user_id,name,stars,text) VALUES (?,?,?,?,?)').run(station, u.id, name, stars, text);
  db.prepare('UPDATE users SET points=points+10 WHERE id=?').run(u.id);
  return { ok: true };
}));

route('POST', '/api/redeem', ['USER'], (req, res, u, b) => tx(() => {
  const r = db.prepare('SELECT * FROM rewards ORDER BY id').all()[Number(b.i)];
  if (!r) bad('المكافأة غير موجودة');
  const cur = db.prepare('SELECT points FROM users WHERE id=?').get(u.id).points;
  if (cur < r.cost) bad('رصيد النقاط غير كافٍ');
  const c = code('RW');
  db.prepare('UPDATE users SET points=points-? WHERE id=?').run(r.cost, u.id);
  db.prepare('INSERT INTO redemptions(user_id,reward_id,code) VALUES (?,?,?)').run(u.id, r.id, c);
  return { code: c };
}));

// --- صاحب الحملة ---
route('POST', '/api/order', ['CAMPAIGN'], (req, res, u, b) => tx(() => {
  const station = Number(b.station), mealId = Number(b.meal), qty = Number(b.qty);
  if (!isInt(qty, 1, 1000)) bad('أدخل عددًا صحيحًا');
  const st = db.prepare(`SELECT s.id FROM stations s JOIN station_services ss ON ss.station_id=s.id
      WHERE s.id=? AND s.visible=1 AND ss.service='مطعم'`).get(station);
  if (!st) bad('هذه المحطة لا يوجد فيها مطعم');
  const meal = db.prepare('SELECT * FROM meals WHERE id=? AND active=1').get(mealId);
  if (!meal) bad('الوجبة غير متوفرة');
  const total = money(meal.price * qty);
  const w = db.prepare('SELECT balance FROM wallets WHERE user_id=?').get(u.id);
  if (!w || total > w.balance) bad('الرصيد غير كافٍ لهذا الطلب');
  const c = code('O');
  db.prepare('UPDATE wallets SET balance=ROUND(balance-?,2) WHERE user_id=?').run(total, u.id);
  db.prepare('INSERT INTO ledger(user_id,amount,reason,ref) VALUES (?,?,?,?)').run(u.id, -total, `طلب وجبات: ${meal.name} × ${qty}`, c);
  db.prepare('INSERT INTO meal_orders(code,campaign_id,station_id,meal_name,qty,total) VALUES (?,?,?,?,?,?)').run(c, u.id, station, meal.name, qty, total);
  return { code: c, total };
}));

// --- صاحب المحطة ---
const ownStation = (u) => { const s = db.prepare('SELECT id FROM stations WHERE owner_id=?').get(u.id); if (!s) bad('لا توجد محطة مرتبطة بحسابك', 403); return s.id; };
route('POST', '/api/owner/plan', ['OWNER'], (req, res, u, b) => {
  const id = ownStation(u);
  if (!db.prepare('SELECT 1 FROM plans WHERE code=?').get(b.plan)) bad('الباقة غير موجودة');
  if (b.bill !== 'شهري' && b.bill !== 'سنوي') bad('دورة الدفع غير صالحة');
  db.prepare('UPDATE stations SET plan=?, billing=? WHERE id=?').run(b.plan, b.bill === 'سنوي' ? 'YEARLY' : 'MONTHLY', id);
  return { ok: true };
});
route('POST', '/api/owner/payout', ['OWNER'], (req, res, u, b) => tx(() => {
  const id = ownStation(u), amount = money(b.amount);
  if (!(amount > 0)) bad('أدخل مبلغًا صحيحًا');
  if (amount > ownerAvailable(id)) bad('المبلغ أكبر من الرصيد المتاح للتحويل');
  db.prepare('INSERT INTO payouts(code,station_id,amount) VALUES (?,?,?)').run(code('P'), id, amount);
  return { ok: true };
}));

// --- مدير الموقع ---
route('POST', '/api/admin/commission', ['ADMIN'], (req, res, u, b) => tx(() => {
  const a = Number(b.comm), m = Number(b.mcomm);
  if (!(a >= 0 && a <= 50 && m >= 0 && m <= 50)) bad('النسبة يجب أن تكون بين 0 و 50');
  db.prepare("UPDATE settings SET v=? WHERE k='BOOKING_COMMISSION_PCT'").run(a);
  db.prepare("UPDATE settings SET v=? WHERE k='MEAL_COMMISSION_PCT'").run(m);
  return { ok: true };
}));
route('POST', '/api/admin/load', ['ADMIN'], (req, res, u, b) => {
  if (!isInt(Number(b.load), 0, 100)) bad('نسبة الزحام غير صالحة');
  if (!db.prepare('UPDATE stations SET load=? WHERE id=?').run(Number(b.load), Number(b.id)).changes) bad('المحطة غير موجودة', 404);
  return { ok: true };
});
route('POST', '/api/admin/toggle', ['ADMIN'], (req, res, u, b) => {
  if (!db.prepare('UPDATE stations SET visible=1-visible WHERE id=?').run(Number(b.id)).changes) bad('المحطة غير موجودة', 404);
  return { ok: true };
});
route('POST', '/api/admin/order-advance', ['ADMIN'], (req, res, u, b) => {
  db.prepare('UPDATE meal_orders SET status=status+1 WHERE code=? AND status<2').run(str(b.id, 30));
  return { ok: true };
});
route('POST', '/api/admin/payout-approve', ['ADMIN'], (req, res, u, b) => {
  db.prepare('UPDATE payouts SET status=1 WHERE code=? AND status=0').run(str(b.id, 30));
  return { ok: true };
});
route('POST', '/api/admin/account', ['ADMIN'], (req, res, u, b) => tx(() => {
  if (!['OWNER', 'CAMPAIGN', 'ADMIN'].includes(b.role)) bad('نوع الحساب غير صالح');
  let station = null;
  if (b.role === 'OWNER') {
    station = Number(b.station);
    const st = db.prepare('SELECT owner_id FROM stations WHERE id=?').get(station);
    if (!st) bad('اختر المحطة التابعة لصاحب المحطة');
    if (st.owner_id) bad('هذه المحطة لها صاحب مسجّل مسبقًا', 409);
  }
  const id = createUser(b);
  if (station !== null) db.prepare('UPDATE stations SET owner_id=? WHERE id=?').run(id, station);
  return { id };
}));
route('POST', '/api/admin/topup', ['ADMIN'], (req, res, u, b) => tx(() => {
  const amount = money(b.amount), ref = str(b.ref, 60);
  if (!(amount > 0 && amount <= 1000000)) bad('أدخل مبلغًا صحيحًا');
  if (ref.length < 3) bad('اكتب مرجع الإيداع البنكي (3 أحرف على الأقل)');
  const w = db.prepare('SELECT 1 FROM wallets w JOIN users u ON u.id=w.user_id WHERE u.id=? AND u.role=?').get(Number(b.user), 'CAMPAIGN');
  if (!w) bad('الحملة غير موجودة');
  db.prepare('UPDATE wallets SET balance=ROUND(balance+?,2) WHERE user_id=?').run(amount, Number(b.user));
  db.prepare('INSERT INTO ledger(user_id,amount,reason,ref) VALUES (?,?,?,?)').run(Number(b.user), amount, 'إيداع بنكي معتمد', ref);
  return { ok: true };
}));

// ---------- الخادم ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8' };
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};
function send(res, code, body, type = 'application/json; charset=utf-8', extra = {}) {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', ...SEC_HEADERS, ...extra, ...(res.getHeader('Set-Cookie') ? { 'Set-Cookie': res.getHeader('Set-Cookie') } : {}) });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > 20000) { reject(new HttpError(413, 'الطلب كبير جدًا')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { const j = JSON.parse(Buffer.concat(chunks).toString()); resolve(j && typeof j === 'object' && !Array.isArray(j) ? j : {}); }
      catch (_) { reject(new HttpError(400, 'صيغة الطلب غير صحيحة')); }
    });
    req.on('error', reject);
  });
}

async function handleApi(req, res, pathname) {
  const r = routes[req.method + ' ' + pathname];
  if (!r) return send(res, 404, JSON.stringify({ error: 'غير موجود' }));
  if (req.method === 'POST') {
    const origin = req.headers.origin;
    if (origin) { let h; try { h = new URL(origin).host; } catch (_) { h = ''; } if (h !== req.headers.host) throw new HttpError(403, 'طلب مرفوض'); }
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) throw new HttpError(415, 'نوع المحتوى غير مدعوم');
  }
  const u = currentUser(req);
  if (r.roles) {
    if (!u) throw new HttpError(401, 'سجّل الدخول أولاً');
    if (!r.roles.includes(u.role)) throw new HttpError(403, 'غير مصرّح لك بهذا الإجراء');
  }
  const body = req.method === 'POST' ? await readBody(req) : {};
  const out = r.fn(req, res, u, body);
  send(res, 200, JSON.stringify(out));
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res, 404, 'غير موجود', 'text/plain; charset=utf-8');
  send(res, 200, fs.readFileSync(file), MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', { 'Cache-Control': 'no-cache' });
}

const server = http.createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, 'http://x');
    if (pathname.startsWith('/api/')) return await handleApi(req, res, pathname);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'غير مسموح', 'text/plain; charset=utf-8');
    serveStatic(req, res, pathname);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.code, JSON.stringify({ error: e.message }));
    if (e && /UNIQUE constraint failed: bookings\.code|meal_orders\.code|redemptions\.code|payouts\.code/.test(String(e.message))) return send(res, 409, JSON.stringify({ error: 'تعذر إنشاء الرمز، أعد المحاولة' }));
    console.error(e);
    send(res, 500, JSON.stringify({ error: 'حدث خطأ في الخادم' }));
  }
});

if (require.main === module) {
  server.listen(PORT, () => console.log('راحة ضيف يعمل على http://localhost:' + PORT));
}
module.exports = { server, db };
