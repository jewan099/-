'use strict';
// اختبار تكاملي: يشغّل الخادم على قاعدة مؤقتة ويجرّب كل الأدوار والصلاحيات.  التشغيل: node test.js
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'rahat-'));
process.env.DATA_DIR = tmp;
process.env.ADMIN_PASSWORD = 'AdminPass-123';
process.env.DEMO_PASSWORD = 'DemoPass-123';
process.env.SESSION_SECRET = 'x'.repeat(40);
const { server } = require('./server');

let base, pass = 0, fail = 0;
const jar = () => ({ c: '' });
async function call(j, method, p, body, headers = {}) {
  const h = { ...headers };
  if (body !== undefined && !h['Content-Type'] && h['Content-Type'] !== null) h['Content-Type'] = 'application/json';
  if (h['Content-Type'] === null) delete h['Content-Type'];
  if (j && j.c) h.Cookie = j.c;
  const r = await fetch(base + p, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
  const sc = r.headers.get('set-cookie');
  if (j && sc) j.c = sc.split(';')[0];
  let data = null; const t = await r.text(); try { data = JSON.parse(t); } catch (_) { data = t; }
  return { s: r.status, d: data, h: r.headers, raw: sc };
}
async function t(name, fn) {
  try { await fn(); pass++; console.log('  ✓', name); } catch (e) { fail++; console.log('  ✗', name, '\n     ', e.message); }
}
const login = async (email, password) => { const j = jar(); const r = await call(j, 'POST', '/api/login', { email, password }); assert.equal(r.s, 200, 'login ' + email + ' → ' + r.s + ' ' + JSON.stringify(r.d)); return j; };

(async () => {
  await new Promise((r) => server.listen(0, r));
  base = 'http://127.0.0.1:' + server.address().port;

  console.log('الملفات الثابتة والأمان');
  await t('الصفحة الرئيسية تعمل', async () => { const r = await call(null, 'GET', '/'); assert.equal(r.s, 200); assert.ok(String(r.d).includes('راحة ضيف')); });
  await t('ملفات السيرفر وقاعدة البيانات غير مكشوفة', async () => {
    for (const p of ['/server.js', '/db.js', '/seed.json', '/data/rahat.sqlite', '/../server.js', '/%2e%2e/server.js', '/..%2fdb.js', '/public/../db.js']) {
      const r = await call(null, 'GET', p); assert.ok(r.s === 404 || r.s === 400, p + ' → ' + r.s);
      assert.ok(!String(r.d).includes('require('), p + ' leaked');
    }
  });
  await t('ترويسات الأمان موجودة', async () => { const r = await call(null, 'GET', '/'); assert.ok(r.h.get('content-security-policy')); assert.equal(r.h.get('x-frame-options'), 'DENY'); });
  await t('الحالة تتطلب تسجيل دخول', async () => { assert.equal((await call(null, 'GET', '/api/state')).s, 401); });

  console.log('تسجيل الدخول');
  await t('كلمة مرور خاطئة ترفض', async () => { assert.equal((await call(jar(), 'POST', '/api/login', { email: 'admin@rahatdayf.sa', password: 'wrong' })).s, 401); });
  await t('أي كلمة مرور قصيرة لا تفتح (لا يوجد قبول عشوائي)', async () => { assert.equal((await call(jar(), 'POST', '/api/login', { email: 'admin@rahatdayf.sa', password: '1234' })).s, 401); });
  await t('الدخول الصحيح يضع كوكي HttpOnly', async () => {
    const r = await call(jar(), 'POST', '/api/login', { email: 'admin@rahatdayf.sa', password: 'AdminPass-123' });
    assert.equal(r.s, 200); assert.equal(r.d.role, 'ADMIN'); assert.ok(/HttpOnly/i.test(r.raw) && /SameSite=Lax/i.test(r.raw));
  });
  await t('كوكي مزوّر مرفوض', async () => { const j = { c: 'rd_session=' + Buffer.from(JSON.stringify({ u: 1, e: Date.now() + 1e9 })).toString('base64url') + '.AAAA' }; assert.equal((await call(j, 'GET', '/api/state')).s, 401); });
  await t('طلب بدون application/json مرفوض (415)', async () => { assert.equal((await call(null, 'POST', '/api/login', undefined, { 'Content-Type': 'text/plain' })).s, 415); });
  await t('طلب من موقع آخر مرفوض (403)', async () => { assert.equal((await call(jar(), 'POST', '/api/login', { email: 'a@b.co', password: 'x' }, { Origin: 'https://evil.example' })).s, 403); });

  const admin = await login('admin@rahatdayf.sa', 'AdminPass-123');
  const owner = await login('owner@jabalkaaba.sa', 'DemoPass-123');
  const camp = await login('campaign@wafaa.sa', 'DemoPass-123');
  const guest = await login('guest@mail.com', 'DemoPass-123');

  console.log('الصلاحيات حسب الدور');
  await t('المستخدم لا يصل لإجراءات المدير', async () => {
    for (const p of ['admin/commission', 'admin/load', 'admin/toggle', 'admin/order-advance', 'admin/payout-approve', 'admin/account', 'admin/topup']) assert.equal((await call(guest, 'POST', '/api/' + p, {})).s, 403, p);
  });
  await t('الحملة لا تحجز ولا تقيّم، والمستخدم لا يطلب وجبات', async () => {
    assert.equal((await call(camp, 'POST', '/api/booking', { station: 0, service: 'مواقف', time: 'الآن', people: 1 })).s, 403);
    assert.equal((await call(guest, 'POST', '/api/order', { station: 0, meal: 1, qty: 1 })).s, 403);
  });
  await t('التسجيل الذاتي لا يسمح بدور مدير أو صاحب محطة', async () => {
    for (const role of ['ADMIN', 'OWNER']) assert.equal((await call(jar(), 'POST', '/api/signup', { name: 'مخترق', email: role + '@x.com', password: 'LongPassword1', role })).s, 403);
  });
  await t('الحالة لا تسرّب بيانات الآخرين', async () => {
    const g = (await call(guest, 'GET', '/api/state')).d, c = (await call(camp, 'GET', '/api/state')).d, o = (await call(owner, 'GET', '/api/state')).d;
    assert.equal(g.orders.length, 0); assert.equal(g.accounts.length, 0); assert.equal(g.payouts.length, 0);
    assert.ok(c.orders.every((x) => x.camp === 'حملة الوفاء للمعتمرين')); assert.equal(c.accounts.length, 0);
    assert.ok(o.bookings.every((b) => b.sid === 0)); assert.equal(o.own, 0);
    assert.ok(JSON.stringify(g).indexOf('scrypt') < 0 && JSON.stringify(c).indexOf('scrypt') < 0 && JSON.stringify((await call(admin, 'GET', '/api/state')).d).indexOf('scrypt') < 0, 'password hash leaked');
  });

  console.log('المستخدم: حجز وتقييم ونقاط');
  const me = jar();
  await t('تسجيل مستخدم جديد: كلمة قصيرة ترفض ثم تنجح', async () => {
    assert.equal((await call(jar(), 'POST', '/api/signup', { name: 'سعد', email: 'saad@x.com', password: '123', role: 'USER' })).s, 400);
    assert.equal((await call(me, 'POST', '/api/signup', { name: 'سعد', email: 'saad@x.com', password: 'LongPassword1', role: 'USER' })).s, 200);
    assert.equal((await call(jar(), 'POST', '/api/signup', { name: 'سعد', email: 'SAAD@x.com', password: 'LongPassword1', role: 'USER' })).s, 409, 'duplicate email (case-insens)');
  });
  await t('حجز بخدمة غير موجودة في المحطة يرفض', async () => { assert.equal((await call(me, 'POST', '/api/booking', { station: 7, service: 'غرف', time: 'الآن', people: 1 })).s, 400); });
  await t('حجز بمدخلات خبيثة يرفض', async () => {
    assert.equal((await call(me, 'POST', '/api/booking', { station: 0, service: 'مواقف', time: 'غدًا', people: 1 })).s, 400);
    assert.equal((await call(me, 'POST', '/api/booking', { station: 0, service: 'مواقف', time: 'الآن', people: -5 })).s, 400);
    assert.equal((await call(me, 'POST', '/api/booking', { station: 999, service: 'مواقف', time: 'الآن', people: 1 })).s, 400);
  });
  await t('الحجز الصحيح يضيف 50 نقطة ويظهر لصاحبه فقط', async () => {
    const r = await call(me, 'POST', '/api/booking', { station: 0, service: 'مواقف', time: 'الآن', people: 2 });
    assert.equal(r.s, 200); assert.equal(r.d.booking.price, 120);
    const s = (await call(me, 'GET', '/api/state')).d; assert.equal(s.points, 50); assert.equal(s.bookings.length, 1);
    assert.equal((await call(guest, 'GET', '/api/state')).d.bookings.every((b) => b.id !== r.d.booking.id), true);
  });
  await t('تقييم واحد لكل مستخدم لكل محطة، ويضيف 10 نقاط', async () => {
    assert.equal((await call(me, 'POST', '/api/review', { st: 0, stars: 5, text: 'ممتاز', name: 'سعد' })).s, 200);
    assert.equal((await call(me, 'POST', '/api/review', { st: 0, stars: 5, text: 'مرة ثانية' })).s, 409);
    assert.equal((await call(me, 'POST', '/api/review', { st: 1, stars: 9, text: 'x' })).s, 400);
    assert.equal((await call(me, 'POST', '/api/review', { st: 1, stars: 3, text: '   ' })).s, 400);
    assert.equal((await call(me, 'GET', '/api/state')).d.points, 60);
  });
  await t('الاستبدال يتطلب نقاطًا كافية ولا ينزل الرصيد عن صفر', async () => {
    assert.equal((await call(me, 'POST', '/api/redeem', { i: 0 })).s, 400);
    const r = await call(me, 'POST', '/api/redeem', { i: 2 }); assert.equal(r.s, 200); assert.ok(/^RW-/.test(r.d.code));
    assert.equal((await call(me, 'GET', '/api/state')).d.points, 0);
    assert.equal((await call(me, 'POST', '/api/redeem', { i: 2 })).s, 400);
  });
  await t('الحد اليومي للحجوزات (منع تجميع النقاط)', async () => {
    const j = jar(); await call(j, 'POST', '/api/signup', { name: 'مكرر', email: 'farm@x.com', password: 'LongPassword1', role: 'USER' });
    let last; for (let i = 0; i < 11; i++) last = await call(j, 'POST', '/api/booking', { station: 0, service: 'مواقف', time: 'الآن', people: 1 });
    assert.equal(last.s, 429);
  });

  console.log('صاحب الحملة: المحفظة والطلبات');
  await t('طلب يتجاوز الرصيد يرفض بدون خصم', async () => {
    const before = (await call(camp, 'GET', '/api/state')).d.wallet;
    assert.equal((await call(camp, 'POST', '/api/order', { station: 0, meal: 1, qty: 1000 })).s, 400);
    assert.equal((await call(camp, 'GET', '/api/state')).d.wallet, before);
  });
  await t('مدخلات الطلب الخبيثة ترفض', async () => {
    for (const b of [{ station: 0, meal: 1, qty: 0 }, { station: 0, meal: 1, qty: -3 }, { station: 0, meal: 1, qty: 2.5 }, { station: 0, meal: 99, qty: 1 }, { station: 7, meal: 1, qty: 1 }]) assert.equal((await call(camp, 'POST', '/api/order', b)).s, 400, JSON.stringify(b));
  });
  await t('الطلب الصحيح يخصم المحفظة ويحسب المجموع من السيرفر', async () => {
    const before = (await call(camp, 'GET', '/api/state')).d.wallet;
    const r = await call(camp, 'POST', '/api/order', { station: 0, meal: 1, qty: 10, total: 1 });
    assert.equal(r.s, 200); assert.equal(r.d.total, 250);
    assert.equal((await call(camp, 'GET', '/api/state')).d.wallet, before - 250);
  });
  await t('طلبان متزامنان لا يسببان رصيدًا سالبًا', async () => {
    const j = await login('campaign2@diyouf.sa', 'DemoPass-123');
    const w = (await call(j, 'GET', '/api/state')).d.wallet;
    const qty = Math.floor((w / 25) * 0.6);
    const rs = await Promise.all([call(j, 'POST', '/api/order', { station: 0, meal: 1, qty }), call(j, 'POST', '/api/order', { station: 0, meal: 1, qty })]);
    assert.equal(rs.filter((r) => r.s === 200).length, 1);
    assert.ok((await call(j, 'GET', '/api/state')).d.wallet >= 0);
  });

  console.log('صاحب المحطة');
  await t('تغيير الباقة لمحطته فقط وبقيم صحيحة', async () => {
    assert.equal((await call(owner, 'POST', '/api/owner/plan', { plan: 'diamond', bill: 'شهري' })).s, 400);
    assert.equal((await call(owner, 'POST', '/api/owner/plan', { plan: 'plus', bill: 'سنوي' })).s, 200);
    const s = (await call(owner, 'GET', '/api/state')).d.stations[0]; assert.equal(s.plan, 'plus'); assert.equal(s.bill, 'سنوي');
    assert.equal((await call(guest, 'POST', '/api/owner/plan', { plan: 'gold', bill: 'شهري' })).s, 403);
  });
  await t('طلب التحويل لا يتجاوز الرصيد المتاح', async () => {
    const st = (await call(owner, 'GET', '/api/state')).d;
    assert.equal((await call(owner, 'POST', '/api/owner/payout', { amount: st.avail + 1 })).s, 400);
    assert.equal((await call(owner, 'POST', '/api/owner/payout', { amount: -5 })).s, 400);
    assert.equal((await call(owner, 'POST', '/api/owner/payout', { amount: 100 })).s, 200);
    assert.equal(Math.round(((await call(owner, 'GET', '/api/state')).d.avail - (st.avail - 100)) * 100), 0);
  });

  console.log('مدير الموقع');
  await t('العمولة بين 0 و50 فقط', async () => {
    assert.equal((await call(admin, 'POST', '/api/admin/commission', { comm: 51, mcomm: 10 })).s, 400);
    assert.equal((await call(admin, 'POST', '/api/admin/commission', { comm: -1, mcomm: 10 })).s, 400);
    assert.equal((await call(admin, 'POST', '/api/admin/commission', { comm: 12, mcomm: 9 })).s, 200);
    assert.equal((await call(admin, 'GET', '/api/state')).d.comm, 12);
  });
  await t('إنشاء حساب صاحب محطة وإيداع في محفظة حملة', async () => {
    assert.equal((await call(admin, 'POST', '/api/admin/account', { name: 'مالك', email: 'o2@x.com', password: 'LongPassword1', role: 'OWNER', station: 0 })).s, 409, 'station already owned');
    assert.equal((await call(admin, 'POST', '/api/admin/account', { name: 'مالك', email: 'o2@x.com', password: 'LongPassword1', role: 'OWNER', station: 5 })).s, 200);
    const o2 = await login('o2@x.com', 'LongPassword1'); assert.equal((await call(o2, 'GET', '/api/state')).d.own, 5);
    const c = jar(); await call(c, 'POST', '/api/signup', { name: 'حملة جديدة', email: 'newc@x.com', password: 'LongPassword1', role: 'CAMPAIGN' });
    const id = (await call(admin, 'GET', '/api/state')).d.accounts.find((a) => a.email === 'newc@x.com').id;
    assert.equal((await call(admin, 'POST', '/api/admin/topup', { user: id, amount: 500, ref: 'x' })).s, 400);
    assert.equal((await call(admin, 'POST', '/api/admin/topup', { user: id, amount: -500, ref: 'BANK-1' })).s, 400);
    assert.equal((await call(admin, 'POST', '/api/admin/topup', { user: id, amount: 500, ref: 'BANK-1' })).s, 200);
    assert.equal((await call(c, 'GET', '/api/state')).d.wallet, 500);
  });
  await t('نقل حالة الطلب واعتماد التحويل وتبديل ظهور المحطة', async () => {
    const st = (await call(admin, 'GET', '/api/state')).d, o = st.orders.find((x) => x.s === 0);
    await call(admin, 'POST', '/api/admin/order-advance', { id: o.id });
    assert.equal((await call(admin, 'GET', '/api/state')).d.orders.find((x) => x.id === o.id).s, 1);
    const p = st.payouts.find((x) => x.s === 0); await call(admin, 'POST', '/api/admin/payout-approve', { id: p.id });
    assert.equal((await call(admin, 'GET', '/api/state')).d.payouts.find((x) => x.id === p.id).s, 1);
    await call(admin, 'POST', '/api/admin/toggle', { id: 2 }); assert.equal((await call(admin, 'GET', '/api/state')).d.stations[2].on, 0);
    assert.equal((await call(me, 'POST', '/api/booking', { station: 2, service: 'مواقف', time: 'الآن', people: 1 })).s, 400, 'hidden station not bookable');
  });
  await t('الاسم الخبيث يُخزَّن كنص كما هو (والواجهة تهرّبه عند العرض)', async () => {
    const x = '<img src=x onerror=alert(1)>';
    const j = jar(); assert.equal((await call(j, 'POST', '/api/signup', { name: x, email: 'xss@x.com', password: 'LongPassword1', role: 'CAMPAIGN' })).s, 200);
    const html = fs.readFileSync(path.join(__dirname, 'public/index.html'), 'utf8');
    assert.ok(html.includes('esc(x.camp)') && html.includes('esc(a.name)') && html.includes('esc(S.me.name)') && html.includes('esc(r.name)') && html.includes('esc(r.text)'));
    assert.ok(!/'<td>'\+x\.camp\+/.test(html) && !/\+a\.name\+/.test(html));
  });

  console.log('تحديد المحاولات');
  await t('تخمين كلمة المرور يُحظر بعد 8 محاولات', async () => {
    let last; for (let i = 0; i < 10; i++) last = await call(jar(), 'POST', '/api/login', { email: 'victim@x.com', password: 'guess' + i });
    assert.equal(last.s, 429);
  });
  await t('الخروج يلغي الجلسة في المتصفح', async () => { const r = await call(guest, 'POST', '/api/logout', {}); assert.equal(r.s, 200); assert.ok(/Max-Age=0/.test(r.raw)); });

  console.log(`\n${pass} نجح، ${fail} فشل`);
  server.close(); fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})();
